# FITZONE GYM - Membership Management System (C# WinForms, Designer version)

Every screen is its own Form with a `.cs` file (logic) and a `.Designer.cs` file (layout you can open in the Visual Studio Designer).

## Open and run
1. Visual Studio 2022 or newer with the **.NET desktop development** workload.
2. Unzip, then **File > Open > Project/Solution** and choose `FitZoneGym.csproj`.
3. Right-click the project > **Restore NuGet Packages** (needs internet once), then press **F5**.
   The SQLite database is created on first run at `%LocalAppData%\FitZoneGym\fitzone.db`.

## Logins (change after first sign-in)
Administrator `admin` / `Admin@123` - Staff `staff1` / `Staff@123` - Cashier `cashier1` / `Cashier@123`

## The 16 screens (Forms/)
| # | Screen | Form |
|---|---|---|
| 1 | Login | LoginForm |
| 2 | Dashboard | DashboardForm |
| 3 | Member Management | MembersForm |
| 4 | Add / Edit Member | MemberEditForm |
| 5 | Membership Plans | PlansForm (+ PlanEditForm dialog) |
| 6 | Registration & Renewal | RegistrationForm |
| 7 | Freeze Management | FreezeForm (+ FreezeRequestForm dialog) |
| 8 | Reactivation | ReactivationForm |
| 9 | Prorated Billing | ProratedForm |
| 10 | Payments | PaymentsForm |
| 11 | Invoice & Billing | InvoicesForm |
| 12 | Reports | ReportsForm |
| 13 | Users & Staff | StaffForm (+ StaffEditForm dialog) |
| 14 | Settings | SettingsForm |
| 15 | Database & Backup | BackupForm |
| 16 | Logout confirmation | LogoutDialog |

`ShellForm` is the base form for screens 2-15: the dark sidebar, user strip and title bar are designed once in
`ShellForm.Designer.cs` and inherited (Visual Inheritance). Each screen puts its own controls in `contentPanel`.
`Nav.cs` switches between screens. Business rules live in `Services/`, so the forms contain only UI code.

## Editing in the Designer
- Open any `XxxForm.cs` and choose **View Designer**. Inherited sidebar controls from ShellForm appear locked - that is normal.
- Grids are styled at runtime by `Ui.StyleGrid(grid)` and filled in code, so they look empty in the Designer.
- Combo boxes that show lists (plans, members) are filled at runtime from the database.
- If the Designer ever shows an error after a rebuild, close the designer tab and use **Build > Rebuild Solution**.

## Policies chosen (the spec leaves these to the gym)
- Term end = start + N months - 1 day. Chargeable days count first and last date.
- Prorated fee = round(monthly fee / 30, 2) x chargeable days.
- Renewal on/before (expiry + grace days) continues from the day after expiry; later renewals start on the renewal date.
- Freeze approval takes effect immediately and extends the expiration by the freeze days (if enabled); early reactivation returns unused days.
- Revenue = payments received in the period. Invoices are voided (admin, no payments), never deleted.
- No online payment gateway: payments are recorded by staff only.

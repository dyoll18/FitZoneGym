using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>New freeze request dialog (opened from the Freeze Management screen).</summary>
    public partial class FreezeRequestForm : Form
    {
        private Membership _ms;

        public FreezeRequestForm()
        {
            InitializeComponent();
            dtpFrom.Value = DateTime.Today;
            dtpTo.Value = DateTime.Today.AddDays(9);
        }

        private void memberPicker_MemberChanged(object sender, EventArgs e)
        {
            _ms = null;
            string id = memberPicker.SelectedMemberId;
            if (id == null) { lblInfo.Text = "Search and select a member."; return; }
            _ms = MembershipService.Latest(id);
            if (_ms == null) { lblInfo.Text = "This member has no membership."; return; }
            int max = Settings.GetInt("MaxFreezeDays", 30);
            lblInfo.Text = "Membership status: " + _ms.State + "  |  Expires: " + Ui.Date(_ms.ExpirationDate) +
                           "\nPolicy: maximum freeze " + max + " days; only active memberships can be frozen.";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (_ms == null) { Ui.Warn("Select a member with a membership first."); return; }
            if (Ui.Run(() => MembershipService.RequestFreeze(_ms.MembershipId, dtpFrom.Value.Date, dtpTo.Value.Date, txtReason.Text)))
            {
                Ui.Info("Freeze request submitted and is now Pending.");
                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}

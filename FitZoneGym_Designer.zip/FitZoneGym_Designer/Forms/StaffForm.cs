using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 13 - Users and Staff Management (accounts, role permissions, activity log).</summary>
    public partial class StaffForm : ShellForm
    {
        protected override string NavKey { get { return "staff"; } }

        public StaffForm()
        {
            InitializeComponent();
            cboRole.SelectedIndex = 0;
            Ui.StyleGrid(dgvStaff);
            Ui.StyleGrid(dgvLog);
            foreach (var g in Perm.Grantable) clbPerms.Items.Add(g.Label);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            LoadStaff();
            LoadPerms();
        }

        private DataGridViewRow SelectedRow { get { return dgvStaff.CurrentRow; } }

        private void LoadStaff()
        {
            Ui.Run(() =>
            {
                Ui.Bind(dgvStaff, StaffService.List(), new[] { "UserID" });
                dgvStaff.Columns["FullName"].HeaderText = "Name";
            });
        }

        private void LoadLog() { Ui.Run(() => Ui.Bind(dgvLog, StaffService.ActivityLog())); }

        private void LoadPerms()
        {
            var granted = StaffService.GetPermissions((string)cboRole.SelectedItem);
            for (int i = 0; i < Perm.Grantable.Length; i++) clbPerms.SetItemChecked(i, granted.Contains(Perm.Grantable[i].Key));
        }

        private void tabs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabs.SelectedTab == tabLog && IsHandleCreated) LoadLog();
        }

        private void cboRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (IsHandleCreated) LoadPerms();
        }

        private void btnSavePerms_Click(object sender, EventArgs e)
        {
            var chosen = new List<string>();
            for (int i = 0; i < Perm.Grantable.Length; i++)
                if (clbPerms.GetItemChecked(i)) chosen.Add(Perm.Grantable[i].Key);
            if (Ui.Run(() => StaffService.SavePermissions((string)cboRole.SelectedItem, chosen)))
                Ui.Info("Permissions saved. Users must sign in again for changes to apply to their session.");
        }

        private void btnAdd_Click(object sender, EventArgs e) { OpenEditor(null); }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (SelectedRow == null) { Ui.Info("Select an account first."); return; }
            OpenEditor(SelectedRow);
        }

        private void dgvStaff_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) OpenEditor(SelectedRow);
        }

        private void OpenEditor(DataGridViewRow row)
        {
            StaffEditForm f = row == null
                ? new StaffEditForm()
                : new StaffEditForm(Db.I(row.Cells["UserID"].Value), Db.S(row.Cells["Username"].Value), Db.S(row.Cells["FullName"].Value),
                                    Db.S(row.Cells["Role"].Value), Db.S(row.Cells["Status"].Value) == "Active");
            using (f)
                if (f.ShowDialog(this) == DialogResult.OK) LoadStaff();
        }
    }
}

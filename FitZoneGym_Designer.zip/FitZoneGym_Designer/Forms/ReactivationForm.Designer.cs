namespace FitZoneGym.Forms
{
    partial class ReactivationForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.pnlCard = new System.Windows.Forms.Panel();
            this.lblDetailsCaption = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblDateCaption = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.lblNewExpCaption = new System.Windows.Forms.Label();
            this.lblNewExp = new System.Windows.Forms.Label();
            this.lblFeeCaption = new System.Windows.Forms.Label();
            this.numFee = new System.Windows.Forms.NumericUpDown();
            this.lblNotesCaption = new System.Windows.Forms.Label();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.btnReactivate = new System.Windows.Forms.Button();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblMember = new System.Windows.Forms.Label();
            this.memberPicker = new FitZoneGym.Controls.MemberPicker();
            this.lblHint = new System.Windows.Forms.Label();
            this.pnlCard.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCard
            // 
            this.pnlCard.Name = "pnlCard";
            this.pnlCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCard.BackColor = System.Drawing.Color.White;
            this.pnlCard.Padding = new System.Windows.Forms.Padding(16, 16, 16, 16);
            this.pnlCard.Controls.Add(this.lblDetailsCaption);
            this.pnlCard.Controls.Add(this.lblDetails);
            this.pnlCard.Controls.Add(this.lblDateCaption);
            this.pnlCard.Controls.Add(this.dtpDate);
            this.pnlCard.Controls.Add(this.lblNewExpCaption);
            this.pnlCard.Controls.Add(this.lblNewExp);
            this.pnlCard.Controls.Add(this.lblFeeCaption);
            this.pnlCard.Controls.Add(this.numFee);
            this.pnlCard.Controls.Add(this.lblNotesCaption);
            this.pnlCard.Controls.Add(this.txtNotes);
            this.pnlCard.Controls.Add(this.btnReactivate);
            this.pnlCard.TabIndex = 0;
            // 
            // lblDetailsCaption
            // 
            this.lblDetailsCaption.Name = "lblDetailsCaption";
            this.lblDetailsCaption.AutoSize = true;
            this.lblDetailsCaption.Text = "Frozen membership";
            this.lblDetailsCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDetailsCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDetailsCaption.Location = new System.Drawing.Point(16, 22);
            this.lblDetailsCaption.TabIndex = 0;
            // 
            // lblDetails
            // 
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.AutoSize = false;
            this.lblDetails.Text = "Search for a member with a frozen membership.";
            this.lblDetails.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDetails.Font = new System.Drawing.Font("Segoe UI", 10.0F);
            this.lblDetails.Size = new System.Drawing.Size(760, 70);
            this.lblDetails.Location = new System.Drawing.Point(220, 22);
            this.lblDetails.TabIndex = 1;
            // 
            // lblDateCaption
            // 
            this.lblDateCaption.Name = "lblDateCaption";
            this.lblDateCaption.AutoSize = true;
            this.lblDateCaption.Text = "Reactivation date";
            this.lblDateCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDateCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDateCaption.Location = new System.Drawing.Point(16, 106);
            this.lblDateCaption.TabIndex = 2;
            // 
            // dtpDate
            // 
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpDate.Size = new System.Drawing.Size(160, 25);
            this.dtpDate.Location = new System.Drawing.Point(220, 102);
            this.dtpDate.TabIndex = 3;
            this.dtpDate.ValueChanged += new System.EventHandler(this.dtpDate_ValueChanged);
            // 
            // lblNewExpCaption
            // 
            this.lblNewExpCaption.Name = "lblNewExpCaption";
            this.lblNewExpCaption.AutoSize = true;
            this.lblNewExpCaption.Text = "New expiration date";
            this.lblNewExpCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblNewExpCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNewExpCaption.Location = new System.Drawing.Point(16, 144);
            this.lblNewExpCaption.TabIndex = 4;
            // 
            // lblNewExp
            // 
            this.lblNewExp.Name = "lblNewExp";
            this.lblNewExp.AutoSize = true;
            this.lblNewExp.Text = "-";
            this.lblNewExp.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblNewExp.Font = new System.Drawing.Font("Segoe UI", 10.0F, System.Drawing.FontStyle.Bold);
            this.lblNewExp.Location = new System.Drawing.Point(220, 144);
            this.lblNewExp.TabIndex = 5;
            // 
            // lblFeeCaption
            // 
            this.lblFeeCaption.Name = "lblFeeCaption";
            this.lblFeeCaption.AutoSize = true;
            this.lblFeeCaption.Text = "Reactivation fee (optional)";
            this.lblFeeCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblFeeCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblFeeCaption.Location = new System.Drawing.Point(16, 182);
            this.lblFeeCaption.TabIndex = 6;
            // 
            // numFee
            // 
            this.numFee.Name = "numFee";
            this.numFee.Minimum = new decimal(new int[] {0, 0, 0, 0});
            this.numFee.Maximum = new decimal(new int[] {1000000, 0, 0, 0});
            this.numFee.Value = new decimal(new int[] {0, 0, 0, 0});
            this.numFee.DecimalPlaces = 2;
            this.numFee.ThousandsSeparator = true;
            this.numFee.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numFee.Size = new System.Drawing.Size(140, 25);
            this.numFee.Location = new System.Drawing.Point(220, 178);
            this.numFee.TabIndex = 7;
            // 
            // lblNotesCaption
            // 
            this.lblNotesCaption.Name = "lblNotesCaption";
            this.lblNotesCaption.AutoSize = true;
            this.lblNotesCaption.Text = "Reason / notes";
            this.lblNotesCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblNotesCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNotesCaption.Location = new System.Drawing.Point(16, 220);
            this.lblNotesCaption.TabIndex = 8;
            // 
            // txtNotes
            // 
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNotes.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNotes.Size = new System.Drawing.Size(520, 70);
            this.txtNotes.Multiline = true;
            this.txtNotes.Location = new System.Drawing.Point(220, 216);
            this.txtNotes.TabIndex = 9;
            // 
            // btnReactivate
            // 
            this.btnReactivate.Name = "btnReactivate";
            this.btnReactivate.Text = "Reactivate Membership";
            this.btnReactivate.Size = new System.Drawing.Size(220, 40);
            this.btnReactivate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReactivate.BackColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnReactivate.ForeColor = System.Drawing.Color.White;
            this.btnReactivate.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnReactivate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReactivate.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnReactivate.UseVisualStyleBackColor = false;
            this.btnReactivate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnReactivate.Location = new System.Drawing.Point(220, 304);
            this.btnReactivate.Enabled = false;
            this.btnReactivate.TabIndex = 10;
            this.btnReactivate.Click += new System.EventHandler(this.btnReactivate_Click);
            // 
            // pnlTop
            // 
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Height = 94;
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlTop.Controls.Add(this.lblMember);
            this.pnlTop.Controls.Add(this.memberPicker);
            this.pnlTop.Controls.Add(this.lblHint);
            this.pnlTop.TabIndex = 1;
            // 
            // lblMember
            // 
            this.lblMember.Name = "lblMember";
            this.lblMember.AutoSize = true;
            this.lblMember.Text = "Member search";
            this.lblMember.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblMember.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblMember.Location = new System.Drawing.Point(0, 0);
            this.lblMember.TabIndex = 0;
            // 
            // memberPicker
            // 
            this.memberPicker.Name = "memberPicker";
            this.memberPicker.Location = new System.Drawing.Point(0, 20);
            this.memberPicker.TabIndex = 1;
            this.memberPicker.MemberChanged += new System.EventHandler(this.memberPicker_MemberChanged);
            // 
            // lblHint
            // 
            this.lblHint.Name = "lblHint";
            this.lblHint.AutoSize = true;
            this.lblHint.Text = "Only frozen memberships with an approved freeze can be reactivated. Unused extension days are returned.";
            this.lblHint.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblHint.Font = new System.Drawing.Font("Segoe UI", 9.0F);
            this.lblHint.Location = new System.Drawing.Point(0, 64);
            this.lblHint.TabIndex = 2;
            // 
            // ReactivationForm
            // 
            this.PageTitle = "Reactivation";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.pnlCard);
            this.contentPanel.Controls.Add(this.pnlTop);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlCard.ResumeLayout(false);
            this.pnlCard.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel pnlCard;
        private System.Windows.Forms.Label lblDetailsCaption;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label lblDateCaption;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblNewExpCaption;
        private System.Windows.Forms.Label lblNewExp;
        private System.Windows.Forms.Label lblFeeCaption;
        private System.Windows.Forms.NumericUpDown numFee;
        private System.Windows.Forms.Label lblNotesCaption;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.Button btnReactivate;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblMember;
        private FitZoneGym.Controls.MemberPicker memberPicker;
        private System.Windows.Forms.Label lblHint;
    }
}

using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 8 - Reactivation.</summary>
    public partial class ReactivationForm : ShellForm
    {
        private MembershipService.ReactivationInfo _info;

        protected override string NavKey { get { return "react"; } }

        public ReactivationForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            numFee.Value = Math.Min(Settings.GetDecimal("ReactivationFee", 0m), numFee.Maximum);
        }

        private void memberPicker_MemberChanged(object sender, EventArgs e)
        {
            _info = null;
            btnReactivate.Enabled = false;
            lblNewExp.Text = "-";
            string id = memberPicker.SelectedMemberId;
            if (id == null) { lblDetails.Text = "Search for a member with a frozen membership."; return; }
            try
            {
                _info = MembershipService.FindReactivatable(id);
                var m = MemberService.Get(id);
                var plan = PlanService.Get(_info.Membership.PlanId);
                lblDetails.Text = m.FullName + " (" + id + ") - " + plan.PlanName +
                                  "\nFreeze period: " + Ui.Date(_info.FreezeStart) + " to " + Ui.Date(_info.FreezeEnd) +
                                  " (" + _info.ExtensionDays + " extension day(s) granted)" +
                                  "\nCurrent expiration: " + Ui.Date(_info.Membership.ExpirationDate);
                btnReactivate.Enabled = Session.Current.Can(Perm.Reactivate);
                Recalc();
            }
            catch (ValidationException ex) { lblDetails.Text = ex.Message; }
            catch (Exception ex) { lblDetails.Text = "Could not load: " + ex.Message; }
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e) { Recalc(); }

        private void Recalc()
        {
            if (_info == null) return;
            lblNewExp.Text = Ui.Date(MembershipService.NewExpirationOnReactivation(_info, dtpDate.Value.Date));
        }

        private void btnReactivate_Click(object sender, EventArgs e)
        {
            string id = memberPicker.SelectedMemberId;
            if (id == null || _info == null) { Ui.Warn("Select a member with a frozen membership."); return; }
            if (!Ui.Confirm("Reactivate this membership?\nNew expiration date: " + lblNewExp.Text)) return;
            if (!Ui.Run(() => MembershipService.Reactivate(id, dtpDate.Value.Date, numFee.Value, txtNotes.Text))) return;
            Ui.Info("Membership reactivated." + (numFee.Value > 0 ? "\nA reactivation invoice for " + Ui.Money(numFee.Value) + " was created (see Payments)." : ""));
            txtNotes.Clear();
            memberPicker.Reload(id);
            memberPicker_MemberChanged(this, EventArgs.Empty);
        }
    }
}

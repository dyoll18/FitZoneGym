namespace FitZoneGym.Forms
{
    partial class SettingsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.pnlBody = new System.Windows.Forms.Panel();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.cardPolicies = new System.Windows.Forms.Panel();
            this.lblMaxFreeze = new System.Windows.Forms.Label();
            this.numMaxFreeze = new System.Windows.Forms.NumericUpDown();
            this.lblMinFreeze = new System.Windows.Forms.Label();
            this.numMinFreeze = new System.Windows.Forms.NumericUpDown();
            this.lblNotice = new System.Windows.Forms.Label();
            this.numNotice = new System.Windows.Forms.NumericUpDown();
            this.lblGrace = new System.Windows.Forms.Label();
            this.numGrace = new System.Windows.Forms.NumericUpDown();
            this.lblReactFee = new System.Windows.Forms.Label();
            this.numReactFee = new System.Windows.Forms.NumericUpDown();
            this.lblMaxDisc = new System.Windows.Forms.Label();
            this.numMaxDisc = new System.Windows.Forms.NumericUpDown();
            this.chkFullExt = new System.Windows.Forms.CheckBox();
            this.chkRefReq = new System.Windows.Forms.CheckBox();
            this.lblPolTitle = new System.Windows.Forms.Label();
            this.cardGym = new System.Windows.Forms.Panel();
            this.lblGymName = new System.Windows.Forms.Label();
            this.txtGymName = new System.Windows.Forms.TextBox();
            this.lblGymAddress = new System.Windows.Forms.Label();
            this.txtGymAddress = new System.Windows.Forms.TextBox();
            this.lblGymContact = new System.Windows.Forms.Label();
            this.txtGymContact = new System.Windows.Forms.TextBox();
            this.lblGymEmail = new System.Windows.Forms.Label();
            this.txtGymEmail = new System.Windows.Forms.TextBox();
            this.lblGymTitle = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlBody.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.cardPolicies.SuspendLayout();
            this.cardGym.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBody
            // 
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlBody.Controls.Add(this.pnlRight);
            this.pnlBody.Controls.Add(this.cardGym);
            this.pnlBody.TabIndex = 0;
            // 
            // pnlRight
            // 
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRight.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlRight.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlRight.Controls.Add(this.cardPolicies);
            this.pnlRight.TabIndex = 0;
            // 
            // cardPolicies
            // 
            this.cardPolicies.Name = "cardPolicies";
            this.cardPolicies.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardPolicies.BackColor = System.Drawing.Color.White;
            this.cardPolicies.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardPolicies.Controls.Add(this.lblMaxFreeze);
            this.cardPolicies.Controls.Add(this.numMaxFreeze);
            this.cardPolicies.Controls.Add(this.lblMinFreeze);
            this.cardPolicies.Controls.Add(this.numMinFreeze);
            this.cardPolicies.Controls.Add(this.lblNotice);
            this.cardPolicies.Controls.Add(this.numNotice);
            this.cardPolicies.Controls.Add(this.lblGrace);
            this.cardPolicies.Controls.Add(this.numGrace);
            this.cardPolicies.Controls.Add(this.lblReactFee);
            this.cardPolicies.Controls.Add(this.numReactFee);
            this.cardPolicies.Controls.Add(this.lblMaxDisc);
            this.cardPolicies.Controls.Add(this.numMaxDisc);
            this.cardPolicies.Controls.Add(this.chkFullExt);
            this.cardPolicies.Controls.Add(this.chkRefReq);
            this.cardPolicies.Controls.Add(this.lblPolTitle);
            this.cardPolicies.TabIndex = 0;
            // 
            // lblMaxFreeze
            // 
            this.lblMaxFreeze.Name = "lblMaxFreeze";
            this.lblMaxFreeze.AutoSize = true;
            this.lblMaxFreeze.Text = "Maximum freeze days";
            this.lblMaxFreeze.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblMaxFreeze.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaxFreeze.Location = new System.Drawing.Point(16, 52);
            this.lblMaxFreeze.TabIndex = 0;
            // 
            // numMaxFreeze
            // 
            this.numMaxFreeze.Name = "numMaxFreeze";
            this.numMaxFreeze.Minimum = new decimal(new int[] {1, 0, 0, 0});
            this.numMaxFreeze.Maximum = new decimal(new int[] {365, 0, 0, 0});
            this.numMaxFreeze.Value = new decimal(new int[] {30, 0, 0, 0});
            this.numMaxFreeze.DecimalPlaces = 0;
            this.numMaxFreeze.ThousandsSeparator = true;
            this.numMaxFreeze.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numMaxFreeze.Size = new System.Drawing.Size(100, 25);
            this.numMaxFreeze.Location = new System.Drawing.Point(300, 48);
            this.numMaxFreeze.TabIndex = 1;
            // 
            // lblMinFreeze
            // 
            this.lblMinFreeze.Name = "lblMinFreeze";
            this.lblMinFreeze.AutoSize = true;
            this.lblMinFreeze.Text = "Minimum freeze days";
            this.lblMinFreeze.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblMinFreeze.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMinFreeze.Location = new System.Drawing.Point(16, 90);
            this.lblMinFreeze.TabIndex = 2;
            // 
            // numMinFreeze
            // 
            this.numMinFreeze.Name = "numMinFreeze";
            this.numMinFreeze.Minimum = new decimal(new int[] {1, 0, 0, 0});
            this.numMinFreeze.Maximum = new decimal(new int[] {365, 0, 0, 0});
            this.numMinFreeze.Value = new decimal(new int[] {1, 0, 0, 0});
            this.numMinFreeze.DecimalPlaces = 0;
            this.numMinFreeze.ThousandsSeparator = true;
            this.numMinFreeze.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numMinFreeze.Size = new System.Drawing.Size(100, 25);
            this.numMinFreeze.Location = new System.Drawing.Point(300, 86);
            this.numMinFreeze.TabIndex = 3;
            // 
            // lblNotice
            // 
            this.lblNotice.Name = "lblNotice";
            this.lblNotice.AutoSize = true;
            this.lblNotice.Text = "Renewal notice (days before expiry)";
            this.lblNotice.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblNotice.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNotice.Location = new System.Drawing.Point(16, 128);
            this.lblNotice.TabIndex = 4;
            // 
            // numNotice
            // 
            this.numNotice.Name = "numNotice";
            this.numNotice.Minimum = new decimal(new int[] {1, 0, 0, 0});
            this.numNotice.Maximum = new decimal(new int[] {90, 0, 0, 0});
            this.numNotice.Value = new decimal(new int[] {7, 0, 0, 0});
            this.numNotice.DecimalPlaces = 0;
            this.numNotice.ThousandsSeparator = true;
            this.numNotice.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numNotice.Size = new System.Drawing.Size(100, 25);
            this.numNotice.Location = new System.Drawing.Point(300, 124);
            this.numNotice.TabIndex = 5;
            // 
            // lblGrace
            // 
            this.lblGrace.Name = "lblGrace";
            this.lblGrace.AutoSize = true;
            this.lblGrace.Text = "Renewal grace period (days)";
            this.lblGrace.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblGrace.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGrace.Location = new System.Drawing.Point(16, 166);
            this.lblGrace.TabIndex = 6;
            // 
            // numGrace
            // 
            this.numGrace.Name = "numGrace";
            this.numGrace.Minimum = new decimal(new int[] {0, 0, 0, 0});
            this.numGrace.Maximum = new decimal(new int[] {90, 0, 0, 0});
            this.numGrace.Value = new decimal(new int[] {3, 0, 0, 0});
            this.numGrace.DecimalPlaces = 0;
            this.numGrace.ThousandsSeparator = true;
            this.numGrace.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numGrace.Size = new System.Drawing.Size(100, 25);
            this.numGrace.Location = new System.Drawing.Point(300, 162);
            this.numGrace.TabIndex = 7;
            // 
            // lblReactFee
            // 
            this.lblReactFee.Name = "lblReactFee";
            this.lblReactFee.AutoSize = true;
            this.lblReactFee.Text = "Default reactivation fee";
            this.lblReactFee.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblReactFee.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblReactFee.Location = new System.Drawing.Point(16, 204);
            this.lblReactFee.TabIndex = 8;
            // 
            // numReactFee
            // 
            this.numReactFee.Name = "numReactFee";
            this.numReactFee.Minimum = new decimal(new int[] {0, 0, 0, 0});
            this.numReactFee.Maximum = new decimal(new int[] {100000, 0, 0, 0});
            this.numReactFee.Value = new decimal(new int[] {0, 0, 0, 0});
            this.numReactFee.DecimalPlaces = 2;
            this.numReactFee.ThousandsSeparator = true;
            this.numReactFee.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numReactFee.Size = new System.Drawing.Size(140, 25);
            this.numReactFee.Location = new System.Drawing.Point(300, 200);
            this.numReactFee.TabIndex = 9;
            // 
            // lblMaxDisc
            // 
            this.lblMaxDisc.Name = "lblMaxDisc";
            this.lblMaxDisc.AutoSize = true;
            this.lblMaxDisc.Text = "Max discount without admin (%)";
            this.lblMaxDisc.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblMaxDisc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaxDisc.Location = new System.Drawing.Point(16, 242);
            this.lblMaxDisc.TabIndex = 10;
            // 
            // numMaxDisc
            // 
            this.numMaxDisc.Name = "numMaxDisc";
            this.numMaxDisc.Minimum = new decimal(new int[] {0, 0, 0, 0});
            this.numMaxDisc.Maximum = new decimal(new int[] {100, 0, 0, 0});
            this.numMaxDisc.Value = new decimal(new int[] {20, 0, 0, 0});
            this.numMaxDisc.DecimalPlaces = 0;
            this.numMaxDisc.ThousandsSeparator = true;
            this.numMaxDisc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numMaxDisc.Size = new System.Drawing.Size(100, 25);
            this.numMaxDisc.Location = new System.Drawing.Point(300, 238);
            this.numMaxDisc.TabIndex = 11;
            // 
            // chkFullExt
            // 
            this.chkFullExt.Name = "chkFullExt";
            this.chkFullExt.AutoSize = true;
            this.chkFullExt.Text = "Approved freezes extend the expiration date by the full freeze days";
            this.chkFullExt.Location = new System.Drawing.Point(16, 286);
            this.chkFullExt.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.chkFullExt.TabIndex = 12;
            // 
            // chkRefReq
            // 
            this.chkRefReq.Name = "chkRefReq";
            this.chkRefReq.AutoSize = true;
            this.chkRefReq.Text = "Require a reference number for non-cash payments";
            this.chkRefReq.Location = new System.Drawing.Point(16, 316);
            this.chkRefReq.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.chkRefReq.TabIndex = 13;
            // 
            // lblPolTitle
            // 
            this.lblPolTitle.Name = "lblPolTitle";
            this.lblPolTitle.AutoSize = false;
            this.lblPolTitle.Text = "Membership & Billing Policies";
            this.lblPolTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblPolTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblPolTitle.Size = new System.Drawing.Size(100, 30);
            this.lblPolTitle.Location = new System.Drawing.Point(0, 0);
            this.lblPolTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPolTitle.TabIndex = 14;
            // 
            // cardGym
            // 
            this.cardGym.Name = "cardGym";
            this.cardGym.Dock = System.Windows.Forms.DockStyle.Left;
            this.cardGym.Width = 480;
            this.cardGym.BackColor = System.Drawing.Color.White;
            this.cardGym.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardGym.Controls.Add(this.lblGymName);
            this.cardGym.Controls.Add(this.txtGymName);
            this.cardGym.Controls.Add(this.lblGymAddress);
            this.cardGym.Controls.Add(this.txtGymAddress);
            this.cardGym.Controls.Add(this.lblGymContact);
            this.cardGym.Controls.Add(this.txtGymContact);
            this.cardGym.Controls.Add(this.lblGymEmail);
            this.cardGym.Controls.Add(this.txtGymEmail);
            this.cardGym.Controls.Add(this.lblGymTitle);
            this.cardGym.TabIndex = 1;
            // 
            // lblGymName
            // 
            this.lblGymName.Name = "lblGymName";
            this.lblGymName.AutoSize = true;
            this.lblGymName.Text = "Gym name";
            this.lblGymName.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblGymName.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGymName.Location = new System.Drawing.Point(16, 52);
            this.lblGymName.TabIndex = 0;
            // 
            // txtGymName
            // 
            this.txtGymName.Name = "txtGymName";
            this.txtGymName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGymName.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtGymName.Size = new System.Drawing.Size(270, 25);
            this.txtGymName.Location = new System.Drawing.Point(170, 48);
            this.txtGymName.TabIndex = 1;
            // 
            // lblGymAddress
            // 
            this.lblGymAddress.Name = "lblGymAddress";
            this.lblGymAddress.AutoSize = true;
            this.lblGymAddress.Text = "Address";
            this.lblGymAddress.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblGymAddress.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGymAddress.Location = new System.Drawing.Point(16, 90);
            this.lblGymAddress.TabIndex = 2;
            // 
            // txtGymAddress
            // 
            this.txtGymAddress.Name = "txtGymAddress";
            this.txtGymAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGymAddress.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtGymAddress.Size = new System.Drawing.Size(270, 25);
            this.txtGymAddress.Location = new System.Drawing.Point(170, 86);
            this.txtGymAddress.TabIndex = 3;
            // 
            // lblGymContact
            // 
            this.lblGymContact.Name = "lblGymContact";
            this.lblGymContact.AutoSize = true;
            this.lblGymContact.Text = "Contact number";
            this.lblGymContact.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblGymContact.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGymContact.Location = new System.Drawing.Point(16, 128);
            this.lblGymContact.TabIndex = 4;
            // 
            // txtGymContact
            // 
            this.txtGymContact.Name = "txtGymContact";
            this.txtGymContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGymContact.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtGymContact.Size = new System.Drawing.Size(270, 25);
            this.txtGymContact.Location = new System.Drawing.Point(170, 124);
            this.txtGymContact.TabIndex = 5;
            // 
            // lblGymEmail
            // 
            this.lblGymEmail.Name = "lblGymEmail";
            this.lblGymEmail.AutoSize = true;
            this.lblGymEmail.Text = "Email";
            this.lblGymEmail.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblGymEmail.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGymEmail.Location = new System.Drawing.Point(16, 166);
            this.lblGymEmail.TabIndex = 6;
            // 
            // txtGymEmail
            // 
            this.txtGymEmail.Name = "txtGymEmail";
            this.txtGymEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGymEmail.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtGymEmail.Size = new System.Drawing.Size(270, 25);
            this.txtGymEmail.Location = new System.Drawing.Point(170, 162);
            this.txtGymEmail.TabIndex = 7;
            // 
            // lblGymTitle
            // 
            this.lblGymTitle.Name = "lblGymTitle";
            this.lblGymTitle.AutoSize = false;
            this.lblGymTitle.Text = "Gym Information";
            this.lblGymTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblGymTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblGymTitle.Size = new System.Drawing.Size(100, 30);
            this.lblGymTitle.Location = new System.Drawing.Point(0, 0);
            this.lblGymTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblGymTitle.TabIndex = 8;
            // 
            // pnlBottom
            // 
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Height = 64;
            this.pnlBottom.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlBottom.Controls.Add(this.btnSave);
            this.pnlBottom.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.Name = "btnSave";
            this.btnSave.Text = "Save Settings";
            this.btnSave.Size = new System.Drawing.Size(160, 40);
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnSave.Location = new System.Drawing.Point(0, 12);
            this.btnSave.TabIndex = 0;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // SettingsForm
            // 
            this.PageTitle = "Settings";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.pnlBody);
            this.contentPanel.Controls.Add(this.pnlBottom);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.cardGym.ResumeLayout(false);
            this.cardGym.PerformLayout();
            this.cardPolicies.ResumeLayout(false);
            this.cardPolicies.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.pnlBody.ResumeLayout(false);
            this.pnlBody.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel cardPolicies;
        private System.Windows.Forms.Label lblMaxFreeze;
        private System.Windows.Forms.NumericUpDown numMaxFreeze;
        private System.Windows.Forms.Label lblMinFreeze;
        private System.Windows.Forms.NumericUpDown numMinFreeze;
        private System.Windows.Forms.Label lblNotice;
        private System.Windows.Forms.NumericUpDown numNotice;
        private System.Windows.Forms.Label lblGrace;
        private System.Windows.Forms.NumericUpDown numGrace;
        private System.Windows.Forms.Label lblReactFee;
        private System.Windows.Forms.NumericUpDown numReactFee;
        private System.Windows.Forms.Label lblMaxDisc;
        private System.Windows.Forms.NumericUpDown numMaxDisc;
        private System.Windows.Forms.CheckBox chkFullExt;
        private System.Windows.Forms.CheckBox chkRefReq;
        private System.Windows.Forms.Label lblPolTitle;
        private System.Windows.Forms.Panel cardGym;
        private System.Windows.Forms.Label lblGymName;
        private System.Windows.Forms.TextBox txtGymName;
        private System.Windows.Forms.Label lblGymAddress;
        private System.Windows.Forms.TextBox txtGymAddress;
        private System.Windows.Forms.Label lblGymContact;
        private System.Windows.Forms.TextBox txtGymContact;
        private System.Windows.Forms.Label lblGymEmail;
        private System.Windows.Forms.TextBox txtGymEmail;
        private System.Windows.Forms.Label lblGymTitle;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnSave;
    }
}

using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 7 - Freeze Management (review, approve and reject; new requests via dialog).</summary>
    public partial class FreezeForm : ShellForm
    {
        private static readonly string[] Statuses = { "Pending", "Approved", "Completed", "Rejected" };
        private string _status = "Pending";

        protected override string NavKey { get { return "freeze"; } }

        public FreezeForm()
        {
            InitializeComponent();
            Ui.StyleGrid(dgvFreeze);
            if (Ui.IsDesignTime) return;

            btnNewRequest.Visible = Session.Current.Can(Perm.SubmitFreeze);
            bool canDecide = Session.Current.Can(Perm.ApproveFreeze);
            btnApprove.Enabled = canDecide;
            btnReject.Enabled = canDecide;
            lblNote.Text = canDecide
                ? "Approval takes effect immediately: the membership becomes Frozen and the expiration date moves by the freeze days (policy)."
                : "Only authorized users can approve or reject requests.";
            StyleTabs();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            Reload();
        }

        private RadioButton[] Tabs { get { return new[] { rbPending, rbApproved, rbCompleted, rbRejected }; } }

        private void StyleTabs()
        {
            foreach (var b in Tabs)
            {
                b.BackColor = b.Checked ? Ui.Blue : Color.White;
                b.ForeColor = b.Checked ? Color.White : Ui.Text;
            }
        }

        private void rbTab_CheckedChanged(object sender, EventArgs e)
        {
            if (Ui.IsDesignTime || !IsHandleCreated) return;
            StyleTabs();
            var rb = (RadioButton)sender;
            if (rb.Checked) { _status = (string)rb.Tag; Reload(); }
        }

        private void UpdateButtons()
        {
            bool pending = _status == "Pending" && dgvFreeze.CurrentRow != null && Session.Current.Can(Perm.ApproveFreeze);
            btnApprove.Visible = pending;
            btnReject.Visible = pending;
        }

        private void Reload()
        {
            Ui.Run(() =>
            {
                var tabs = Tabs;
                for (int i = 0; i < Statuses.Length; i++)
                    tabs[i].Text = Statuses[i] + " (" + MembershipService.FreezeList(Statuses[i]).Rows.Count + ")";
                var t = MembershipService.FreezeList(_status);
                Ui.Bind(dgvFreeze, t, new[] { "FreezeID" }, null, new[] { "RequestDate", "StartDate", "EndDate" });
                dgvFreeze.Columns["MemberID"].HeaderText = "Member ID";
                dgvFreeze.Columns["FullName"].HeaderText = "Name";
                dgvFreeze.Columns["RequestDate"].HeaderText = "Requested";
                dgvFreeze.Columns["StartDate"].HeaderText = "From";
                dgvFreeze.Columns["EndDate"].HeaderText = "To";
                UpdateButtons();
            });
        }

        private void dgvFreeze_SelectionChanged(object sender, EventArgs e) { UpdateButtons(); }

        private int SelectedId
        {
            get { return dgvFreeze.CurrentRow == null ? 0 : Db.I(dgvFreeze.CurrentRow.Cells["FreezeID"].Value); }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            int id = SelectedId;
            if (id == 0) { Ui.Info("Select a request first."); return; }
            if (!Ui.Confirm("Approve this freeze request?\nThe membership will be frozen and its expiration date adjusted per policy.")) return;
            if (Ui.Run(() => MembershipService.ApproveFreeze(id, null))) Reload();
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            int id = SelectedId;
            if (id == 0) { Ui.Info("Select a request first."); return; }
            string reason = Ui.Prompt("Reject freeze request", "Reason for rejecting (required):");
            if (reason == null) return;
            if (Ui.Run(() => MembershipService.RejectFreeze(id, reason))) Reload();
        }

        private void btnNewRequest_Click(object sender, EventArgs e)
        {
            using (var f = new FreezeRequestForm())
                if (f.ShowDialog(this) == DialogResult.OK) { rbPending.Checked = true; Reload(); }
        }
    }
}

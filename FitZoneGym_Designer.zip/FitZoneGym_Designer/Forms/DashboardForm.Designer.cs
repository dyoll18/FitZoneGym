namespace FitZoneGym.Forms
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.mainLayout = new System.Windows.Forms.TableLayoutPanel();
            this.cardsLayout = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTotal = new System.Windows.Forms.Panel();
            this.lblTotalValue = new System.Windows.Forms.Label();
            this.lblTotalCaption = new System.Windows.Forms.Label();
            this.pnlActive = new System.Windows.Forms.Panel();
            this.lblActiveValue = new System.Windows.Forms.Label();
            this.lblActiveCaption = new System.Windows.Forms.Label();
            this.pnlFrozen = new System.Windows.Forms.Panel();
            this.lblFrozenValue = new System.Windows.Forms.Label();
            this.lblFrozenCaption = new System.Windows.Forms.Label();
            this.pnlExpired = new System.Windows.Forms.Panel();
            this.lblExpiredValue = new System.Windows.Forms.Label();
            this.lblExpiredCaption = new System.Windows.Forms.Label();
            this.cardChart = new System.Windows.Forms.Panel();
            this.donutChart = new FitZoneGym.Controls.DonutChart();
            this.lblChartTitle = new System.Windows.Forms.Label();
            this.cardExpiring = new System.Windows.Forms.Panel();
            this.dgvExpiring = new System.Windows.Forms.DataGridView();
            this.lnkViewAll = new System.Windows.Forms.LinkLabel();
            this.lblExpiringTitle = new System.Windows.Forms.Label();
            this.cardActivity = new System.Windows.Forms.Panel();
            this.dgvActivity = new System.Windows.Forms.DataGridView();
            this.lblActivityTitle = new System.Windows.Forms.Label();
            this.mainLayout.SuspendLayout();
            this.cardsLayout.SuspendLayout();
            this.pnlTotal.SuspendLayout();
            this.pnlActive.SuspendLayout();
            this.pnlFrozen.SuspendLayout();
            this.pnlExpired.SuspendLayout();
            this.cardChart.SuspendLayout();
            this.cardExpiring.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExpiring)).BeginInit();
            this.cardActivity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvActivity)).BeginInit();
            this.SuspendLayout();
            // 
            // mainLayout
            // 
            this.mainLayout.Name = "mainLayout";
            this.mainLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainLayout.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.mainLayout.ColumnCount = 2;
            this.mainLayout.RowCount = 3;
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62F));
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.mainLayout.Controls.Add(this.cardsLayout, 0, 0);
            this.mainLayout.SetColumnSpan(this.cardsLayout, 2);
            this.mainLayout.Controls.Add(this.cardChart, 0, 1);
            this.mainLayout.Controls.Add(this.cardExpiring, 1, 1);
            this.mainLayout.Controls.Add(this.cardActivity, 0, 2);
            this.mainLayout.SetColumnSpan(this.cardActivity, 2);
            this.mainLayout.TabIndex = 0;
            // 
            // cardsLayout
            // 
            this.cardsLayout.Name = "cardsLayout";
            this.cardsLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardsLayout.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.cardsLayout.Margin = new System.Windows.Forms.Padding(0, 0, 0, 12);
            this.cardsLayout.ColumnCount = 4;
            this.cardsLayout.RowCount = 1;
            this.cardsLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.cardsLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.cardsLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.cardsLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.cardsLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.cardsLayout.Controls.Add(this.pnlTotal, 0, 0);
            this.cardsLayout.Controls.Add(this.pnlActive, 1, 0);
            this.cardsLayout.Controls.Add(this.pnlFrozen, 2, 0);
            this.cardsLayout.Controls.Add(this.pnlExpired, 3, 0);
            this.cardsLayout.TabIndex = 0;
            // 
            // pnlTotal
            // 
            this.pnlTotal.Name = "pnlTotal";
            this.pnlTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTotal.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.pnlTotal.Margin = new System.Windows.Forms.Padding(0, 0, 12, 0);
            this.pnlTotal.Padding = new System.Windows.Forms.Padding(16, 12, 8, 8);
            this.pnlTotal.Controls.Add(this.lblTotalValue);
            this.pnlTotal.Controls.Add(this.lblTotalCaption);
            this.pnlTotal.TabIndex = 0;
            // 
            // lblTotalValue
            // 
            this.lblTotalValue.Name = "lblTotalValue";
            this.lblTotalValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalValue.Text = "0";
            this.lblTotalValue.Font = new System.Drawing.Font("Segoe UI", 28.0F, System.Drawing.FontStyle.Bold);
            this.lblTotalValue.ForeColor = System.Drawing.Color.White;
            this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTotalValue.TabIndex = 0;
            // 
            // lblTotalCaption
            // 
            this.lblTotalCaption.Name = "lblTotalCaption";
            this.lblTotalCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTotalCaption.Height = 24;
            this.lblTotalCaption.Text = "Total Members";
            this.lblTotalCaption.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblTotalCaption.ForeColor = System.Drawing.Color.White;
            this.lblTotalCaption.TabIndex = 1;
            // 
            // pnlActive
            // 
            this.pnlActive.Name = "pnlActive";
            this.pnlActive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlActive.BackColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.pnlActive.Margin = new System.Windows.Forms.Padding(0, 0, 12, 0);
            this.pnlActive.Padding = new System.Windows.Forms.Padding(16, 12, 8, 8);
            this.pnlActive.Controls.Add(this.lblActiveValue);
            this.pnlActive.Controls.Add(this.lblActiveCaption);
            this.pnlActive.TabIndex = 1;
            // 
            // lblActiveValue
            // 
            this.lblActiveValue.Name = "lblActiveValue";
            this.lblActiveValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblActiveValue.Text = "0";
            this.lblActiveValue.Font = new System.Drawing.Font("Segoe UI", 28.0F, System.Drawing.FontStyle.Bold);
            this.lblActiveValue.ForeColor = System.Drawing.Color.White;
            this.lblActiveValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblActiveValue.TabIndex = 0;
            // 
            // lblActiveCaption
            // 
            this.lblActiveCaption.Name = "lblActiveCaption";
            this.lblActiveCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblActiveCaption.Height = 24;
            this.lblActiveCaption.Text = "Active";
            this.lblActiveCaption.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblActiveCaption.ForeColor = System.Drawing.Color.White;
            this.lblActiveCaption.TabIndex = 1;
            // 
            // pnlFrozen
            // 
            this.pnlFrozen.Name = "pnlFrozen";
            this.pnlFrozen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFrozen.BackColor = System.Drawing.Color.FromArgb(245, 158, 11);
            this.pnlFrozen.Margin = new System.Windows.Forms.Padding(0, 0, 12, 0);
            this.pnlFrozen.Padding = new System.Windows.Forms.Padding(16, 12, 8, 8);
            this.pnlFrozen.Controls.Add(this.lblFrozenValue);
            this.pnlFrozen.Controls.Add(this.lblFrozenCaption);
            this.pnlFrozen.TabIndex = 2;
            // 
            // lblFrozenValue
            // 
            this.lblFrozenValue.Name = "lblFrozenValue";
            this.lblFrozenValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFrozenValue.Text = "0";
            this.lblFrozenValue.Font = new System.Drawing.Font("Segoe UI", 28.0F, System.Drawing.FontStyle.Bold);
            this.lblFrozenValue.ForeColor = System.Drawing.Color.White;
            this.lblFrozenValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFrozenValue.TabIndex = 0;
            // 
            // lblFrozenCaption
            // 
            this.lblFrozenCaption.Name = "lblFrozenCaption";
            this.lblFrozenCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblFrozenCaption.Height = 24;
            this.lblFrozenCaption.Text = "Frozen";
            this.lblFrozenCaption.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblFrozenCaption.ForeColor = System.Drawing.Color.White;
            this.lblFrozenCaption.TabIndex = 1;
            // 
            // pnlExpired
            // 
            this.pnlExpired.Name = "pnlExpired";
            this.pnlExpired.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlExpired.BackColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.pnlExpired.Margin = new System.Windows.Forms.Padding(0, 0, 12, 0);
            this.pnlExpired.Padding = new System.Windows.Forms.Padding(16, 12, 8, 8);
            this.pnlExpired.Controls.Add(this.lblExpiredValue);
            this.pnlExpired.Controls.Add(this.lblExpiredCaption);
            this.pnlExpired.TabIndex = 3;
            // 
            // lblExpiredValue
            // 
            this.lblExpiredValue.Name = "lblExpiredValue";
            this.lblExpiredValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExpiredValue.Text = "0";
            this.lblExpiredValue.Font = new System.Drawing.Font("Segoe UI", 28.0F, System.Drawing.FontStyle.Bold);
            this.lblExpiredValue.ForeColor = System.Drawing.Color.White;
            this.lblExpiredValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblExpiredValue.TabIndex = 0;
            // 
            // lblExpiredCaption
            // 
            this.lblExpiredCaption.Name = "lblExpiredCaption";
            this.lblExpiredCaption.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblExpiredCaption.Height = 24;
            this.lblExpiredCaption.Text = "Expired";
            this.lblExpiredCaption.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblExpiredCaption.ForeColor = System.Drawing.Color.White;
            this.lblExpiredCaption.TabIndex = 1;
            // 
            // cardChart
            // 
            this.cardChart.Name = "cardChart";
            this.cardChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardChart.BackColor = System.Drawing.Color.White;
            this.cardChart.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardChart.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.cardChart.Controls.Add(this.donutChart);
            this.cardChart.Controls.Add(this.lblChartTitle);
            this.cardChart.TabIndex = 1;
            // 
            // donutChart
            // 
            this.donutChart.Name = "donutChart";
            this.donutChart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.donutChart.TabIndex = 0;
            // 
            // lblChartTitle
            // 
            this.lblChartTitle.Name = "lblChartTitle";
            this.lblChartTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblChartTitle.Height = 30;
            this.lblChartTitle.Text = "Membership Status";
            this.lblChartTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblChartTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblChartTitle.TabIndex = 1;
            // 
            // cardExpiring
            // 
            this.cardExpiring.Name = "cardExpiring";
            this.cardExpiring.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardExpiring.BackColor = System.Drawing.Color.White;
            this.cardExpiring.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardExpiring.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.cardExpiring.Controls.Add(this.dgvExpiring);
            this.cardExpiring.Controls.Add(this.lnkViewAll);
            this.cardExpiring.Controls.Add(this.lblExpiringTitle);
            this.cardExpiring.TabIndex = 2;
            // 
            // dgvExpiring
            // 
            this.dgvExpiring.Name = "dgvExpiring";
            this.dgvExpiring.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvExpiring.TabIndex = 0;
            // 
            // lnkViewAll
            // 
            this.lnkViewAll.Name = "lnkViewAll";
            this.lnkViewAll.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lnkViewAll.Height = 22;
            this.lnkViewAll.Text = "View all members";
            this.lnkViewAll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkViewAll.TabIndex = 1;
            this.lnkViewAll.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAll_LinkClicked);
            // 
            // lblExpiringTitle
            // 
            this.lblExpiringTitle.Name = "lblExpiringTitle";
            this.lblExpiringTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblExpiringTitle.Height = 30;
            this.lblExpiringTitle.Text = "Upcoming Expirations";
            this.lblExpiringTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblExpiringTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblExpiringTitle.TabIndex = 2;
            // 
            // cardActivity
            // 
            this.cardActivity.Name = "cardActivity";
            this.cardActivity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardActivity.BackColor = System.Drawing.Color.White;
            this.cardActivity.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardActivity.Margin = new System.Windows.Forms.Padding(0, 0, 12, 12);
            this.cardActivity.Controls.Add(this.dgvActivity);
            this.cardActivity.Controls.Add(this.lblActivityTitle);
            this.cardActivity.TabIndex = 3;
            // 
            // dgvActivity
            // 
            this.dgvActivity.Name = "dgvActivity";
            this.dgvActivity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvActivity.TabIndex = 0;
            // 
            // lblActivityTitle
            // 
            this.lblActivityTitle.Name = "lblActivityTitle";
            this.lblActivityTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblActivityTitle.Height = 30;
            this.lblActivityTitle.Text = "Recent Activity";
            this.lblActivityTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblActivityTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblActivityTitle.TabIndex = 1;
            // 
            // DashboardForm
            // 
            this.PageTitle = "Dashboard";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.mainLayout);
            ((System.ComponentModel.ISupportInitialize)(this.dgvActivity)).EndInit();
            this.cardActivity.ResumeLayout(false);
            this.cardActivity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExpiring)).EndInit();
            this.cardExpiring.ResumeLayout(false);
            this.cardExpiring.PerformLayout();
            this.cardChart.ResumeLayout(false);
            this.cardChart.PerformLayout();
            this.pnlExpired.ResumeLayout(false);
            this.pnlExpired.PerformLayout();
            this.pnlFrozen.ResumeLayout(false);
            this.pnlFrozen.PerformLayout();
            this.pnlActive.ResumeLayout(false);
            this.pnlActive.PerformLayout();
            this.pnlTotal.ResumeLayout(false);
            this.pnlTotal.PerformLayout();
            this.cardsLayout.ResumeLayout(false);
            this.cardsLayout.PerformLayout();
            this.mainLayout.ResumeLayout(false);
            this.mainLayout.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel mainLayout;
        private System.Windows.Forms.TableLayoutPanel cardsLayout;
        private System.Windows.Forms.Panel pnlTotal;
        private System.Windows.Forms.Label lblTotalValue;
        private System.Windows.Forms.Label lblTotalCaption;
        private System.Windows.Forms.Panel pnlActive;
        private System.Windows.Forms.Label lblActiveValue;
        private System.Windows.Forms.Label lblActiveCaption;
        private System.Windows.Forms.Panel pnlFrozen;
        private System.Windows.Forms.Label lblFrozenValue;
        private System.Windows.Forms.Label lblFrozenCaption;
        private System.Windows.Forms.Panel pnlExpired;
        private System.Windows.Forms.Label lblExpiredValue;
        private System.Windows.Forms.Label lblExpiredCaption;
        private System.Windows.Forms.Panel cardChart;
        private FitZoneGym.Controls.DonutChart donutChart;
        private System.Windows.Forms.Label lblChartTitle;
        private System.Windows.Forms.Panel cardExpiring;
        private System.Windows.Forms.DataGridView dgvExpiring;
        private System.Windows.Forms.LinkLabel lnkViewAll;
        private System.Windows.Forms.Label lblExpiringTitle;
        private System.Windows.Forms.Panel cardActivity;
        private System.Windows.Forms.DataGridView dgvActivity;
        private System.Windows.Forms.Label lblActivityTitle;
    }
}

using System.Globalization;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 14 - Settings (gym information and policies).</summary>
    public partial class SettingsForm : ShellForm
    {
        protected override string NavKey { get { return "settings"; } }

        public SettingsForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            LoadValues();
        }

        private static decimal Clamp(int v, NumericUpDown n)
        {
            return Math.Max(n.Minimum, Math.Min(n.Maximum, v));
        }

        private void LoadValues()
        {
            txtGymName.Text = Settings.Get("GymName");
            txtGymAddress.Text = Settings.Get("GymAddress");
            txtGymContact.Text = Settings.Get("GymContact");
            txtGymEmail.Text = Settings.Get("GymEmail");
            numMaxFreeze.Value = Clamp(Settings.GetInt("MaxFreezeDays", 30), numMaxFreeze);
            numMinFreeze.Value = Clamp(Settings.GetInt("MinFreezeDays", 1), numMinFreeze);
            numNotice.Value = Clamp(Settings.GetInt("RenewalNoticeDays", 7), numNotice);
            numGrace.Value = Clamp(Settings.GetInt("GracePeriodDays", 3), numGrace);
            numReactFee.Value = Math.Min(Settings.GetDecimal("ReactivationFee", 0m), numReactFee.Maximum);
            numMaxDisc.Value = Math.Min(Settings.GetDecimal("MaxStaffDiscountPercent", 20m), numMaxDisc.Maximum);
            chkFullExt.Checked = Settings.GetBool("FullFreezeExtension", true);
            chkRefReq.Checked = Settings.GetBool("RequireReferenceForNonCash", true);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bool ok = Ui.Run(() =>
            {
                Session.Require(Perm.ManageSettings);
                if (string.IsNullOrWhiteSpace(txtGymName.Text)) throw new ValidationException("Gym name is required.");
                if (numMinFreeze.Value > numMaxFreeze.Value) throw new ValidationException("Minimum freeze days cannot exceed the maximum.");

                using (var s = new DbSession(true))
                {
                    Settings.Set(s, "GymName", txtGymName.Text.Trim());
                    Settings.Set(s, "GymAddress", txtGymAddress.Text.Trim());
                    Settings.Set(s, "GymContact", txtGymContact.Text.Trim());
                    Settings.Set(s, "GymEmail", txtGymEmail.Text.Trim());
                    Settings.Set(s, "MaxFreezeDays", ((int)numMaxFreeze.Value).ToString());
                    Settings.Set(s, "MinFreezeDays", ((int)numMinFreeze.Value).ToString());
                    Settings.Set(s, "RenewalNoticeDays", ((int)numNotice.Value).ToString());
                    Settings.Set(s, "GracePeriodDays", ((int)numGrace.Value).ToString());
                    Settings.Set(s, "ReactivationFee", numReactFee.Value.ToString(CultureInfo.InvariantCulture));
                    Settings.Set(s, "MaxStaffDiscountPercent", numMaxDisc.Value.ToString(CultureInfo.InvariantCulture));
                    Settings.Set(s, "FullFreezeExtension", chkFullExt.Checked ? "true" : "false");
                    Settings.Set(s, "RequireReferenceForNonCash", chkRefReq.Checked ? "true" : "false");
                    Audit.Log(s, "Settings updated");
                    s.Commit();
                }
            });
            if (ok) Ui.Info("Settings saved.");
        }
    }
}

using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 15 - Database &amp; Backup (backup, restore, validation and error logs).</summary>
    public partial class BackupForm : ShellForm
    {
        protected override string NavKey { get { return "backup"; } }

        public BackupForm()
        {
            InitializeComponent();
            Ui.StyleGrid(dgvHistory);
            Ui.StyleGrid(dgvValidation);
            Ui.StyleGrid(dgvErrors);
            if (Ui.IsDesignTime) return;

            lblDbPath.Text = Db.FilePath;
            txtBackupPath.Text = Path.Combine(BackupService.DefaultFolder, BackupService.SuggestFileName());
            btnBackupNow.Enabled = Session.Current.Can(Perm.Backup);
            btnRestore.Enabled = Session.Current.Can(Perm.Restore);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            LoadLogs();
        }

        private void LoadLogs()
        {
            Ui.Run(() =>
            {
                Ui.Bind(dgvHistory, BackupService.BackupLog());
                Ui.Bind(dgvValidation, BackupService.ErrorLog("Validation"));
                Ui.Bind(dgvErrors, BackupService.ErrorLog("Error"));
            });
        }

        private void tabs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (IsHandleCreated) LoadLogs();
        }

        private void btnBrowseBackup_Click(object sender, EventArgs e)
        {
            using (var dlg = new SaveFileDialog
            {
                Filter = "FITZONE backup (*.db)|*.db",
                FileName = Path.GetFileName(txtBackupPath.Text),
                InitialDirectory = BackupService.DefaultFolder,
            })
                if (dlg.ShowDialog() == DialogResult.OK) txtBackupPath.Text = dlg.FileName;
        }

        private void btnBrowseRestore_Click(object sender, EventArgs e)
        {
            using (var dlg = new OpenFileDialog
            {
                Filter = "FITZONE backup (*.db)|*.db|All files (*.*)|*.*",
                InitialDirectory = BackupService.DefaultFolder,
            })
                if (dlg.ShowDialog() == DialogResult.OK) txtRestorePath.Text = dlg.FileName;
        }

        private void btnBackupNow_Click(object sender, EventArgs e)
        {
            if (Ui.Run(() => BackupService.Backup(txtBackupPath.Text)))
            {
                Ui.Info("Backup created:\n" + txtBackupPath.Text);
                txtBackupPath.Text = Path.Combine(BackupService.DefaultFolder, BackupService.SuggestFileName());
                LoadLogs();
            }
        }

        private void btnRestore_Click(object sender, EventArgs e)
        {
            if (!Ui.Run(() => BackupService.ValidateBackup(txtRestorePath.Text))) return;   // stop and show the problem
            if (!Ui.Confirm("Restore this backup?\n\n" + txtRestorePath.Text + "\n\nAll current data will be replaced. You will be signed out.")) return;
            if (Ui.Run(() => BackupService.Restore(txtRestorePath.Text)))
            {
                Ui.Info("The database was restored. Please sign in again.");
                Nav.ForceLogout(this);
            }
        }
    }
}

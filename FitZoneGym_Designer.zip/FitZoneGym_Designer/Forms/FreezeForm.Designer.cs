namespace FitZoneGym.Forms
{
    partial class FreezeForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.mainLayout = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTabs = new System.Windows.Forms.Panel();
            this.rbPending = new System.Windows.Forms.RadioButton();
            this.rbApproved = new System.Windows.Forms.RadioButton();
            this.rbCompleted = new System.Windows.Forms.RadioButton();
            this.rbRejected = new System.Windows.Forms.RadioButton();
            this.dgvFreeze = new System.Windows.Forms.DataGridView();
            this.footerPanel = new System.Windows.Forms.Panel();
            this.btnApprove = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.lblNote = new System.Windows.Forms.Label();
            this.btnNewRequest = new System.Windows.Forms.Button();
            this.mainLayout.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreeze)).BeginInit();
            this.footerPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainLayout
            // 
            this.mainLayout.Name = "mainLayout";
            this.mainLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainLayout.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.mainLayout.ColumnCount = 1;
            this.mainLayout.RowCount = 3;
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.mainLayout.Controls.Add(this.pnlTabs, 0, 0);
            this.mainLayout.Controls.Add(this.dgvFreeze, 0, 1);
            this.mainLayout.Controls.Add(this.footerPanel, 0, 2);
            this.mainLayout.TabIndex = 0;
            // 
            // pnlTabs
            // 
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlTabs.Controls.Add(this.rbPending);
            this.pnlTabs.Controls.Add(this.rbApproved);
            this.pnlTabs.Controls.Add(this.rbCompleted);
            this.pnlTabs.Controls.Add(this.rbRejected);
            this.pnlTabs.TabIndex = 0;
            // 
            // rbPending
            // 
            this.rbPending.Name = "rbPending";
            this.rbPending.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbPending.AutoSize = false;
            this.rbPending.Size = new System.Drawing.Size(140, 32);
            this.rbPending.Location = new System.Drawing.Point(0, 4);
            this.rbPending.Text = "Pending";
            this.rbPending.Tag = "Pending";
            this.rbPending.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbPending.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbPending.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rbPending.TabStop = true;
            this.rbPending.Checked = true;
            this.rbPending.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.rbPending.TabIndex = 0;
            this.rbPending.CheckedChanged += new System.EventHandler(this.rbTab_CheckedChanged);
            // 
            // rbApproved
            // 
            this.rbApproved.Name = "rbApproved";
            this.rbApproved.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbApproved.AutoSize = false;
            this.rbApproved.Size = new System.Drawing.Size(140, 32);
            this.rbApproved.Location = new System.Drawing.Point(150, 4);
            this.rbApproved.Text = "Approved";
            this.rbApproved.Tag = "Approved";
            this.rbApproved.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbApproved.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbApproved.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rbApproved.TabStop = true;
            this.rbApproved.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.rbApproved.TabIndex = 1;
            this.rbApproved.CheckedChanged += new System.EventHandler(this.rbTab_CheckedChanged);
            // 
            // rbCompleted
            // 
            this.rbCompleted.Name = "rbCompleted";
            this.rbCompleted.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbCompleted.AutoSize = false;
            this.rbCompleted.Size = new System.Drawing.Size(140, 32);
            this.rbCompleted.Location = new System.Drawing.Point(300, 4);
            this.rbCompleted.Text = "Completed";
            this.rbCompleted.Tag = "Completed";
            this.rbCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbCompleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbCompleted.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rbCompleted.TabStop = true;
            this.rbCompleted.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.rbCompleted.TabIndex = 2;
            this.rbCompleted.CheckedChanged += new System.EventHandler(this.rbTab_CheckedChanged);
            // 
            // rbRejected
            // 
            this.rbRejected.Name = "rbRejected";
            this.rbRejected.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbRejected.AutoSize = false;
            this.rbRejected.Size = new System.Drawing.Size(140, 32);
            this.rbRejected.Location = new System.Drawing.Point(450, 4);
            this.rbRejected.Text = "Rejected";
            this.rbRejected.Tag = "Rejected";
            this.rbRejected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbRejected.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbRejected.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rbRejected.TabStop = true;
            this.rbRejected.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.rbRejected.TabIndex = 3;
            this.rbRejected.CheckedChanged += new System.EventHandler(this.rbTab_CheckedChanged);
            // 
            // dgvFreeze
            // 
            this.dgvFreeze.Name = "dgvFreeze";
            this.dgvFreeze.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFreeze.TabIndex = 1;
            this.dgvFreeze.SelectionChanged += new System.EventHandler(this.dgvFreeze_SelectionChanged);
            // 
            // footerPanel
            // 
            this.footerPanel.Name = "footerPanel";
            this.footerPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.footerPanel.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.footerPanel.Controls.Add(this.btnApprove);
            this.footerPanel.Controls.Add(this.btnReject);
            this.footerPanel.Controls.Add(this.lblNote);
            this.footerPanel.TabIndex = 2;
            // 
            // btnApprove
            // 
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Text = "Approve";
            this.btnApprove.Size = new System.Drawing.Size(110, 34);
            this.btnApprove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApprove.BackColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnApprove.ForeColor = System.Drawing.Color.White;
            this.btnApprove.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnApprove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnApprove.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnApprove.Location = new System.Drawing.Point(0, 8);
            this.btnApprove.TabIndex = 0;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // btnReject
            // 
            this.btnReject.Name = "btnReject";
            this.btnReject.Text = "Reject";
            this.btnReject.Size = new System.Drawing.Size(110, 34);
            this.btnReject.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReject.BackColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.btnReject.ForeColor = System.Drawing.Color.White;
            this.btnReject.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnReject.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReject.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.btnReject.Location = new System.Drawing.Point(120, 8);
            this.btnReject.TabIndex = 1;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // lblNote
            // 
            this.lblNote.Name = "lblNote";
            this.lblNote.AutoSize = true;
            this.lblNote.Text = "";
            this.lblNote.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblNote.Font = new System.Drawing.Font("Segoe UI", 9.0F);
            this.lblNote.Location = new System.Drawing.Point(250, 16);
            this.lblNote.TabIndex = 2;
            // 
            // btnNewRequest
            // 
            this.btnNewRequest.Name = "btnNewRequest";
            this.btnNewRequest.Text = "+ New Freeze Request";
            this.btnNewRequest.Size = new System.Drawing.Size(180, 34);
            this.btnNewRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewRequest.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnNewRequest.ForeColor = System.Drawing.Color.White;
            this.btnNewRequest.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnNewRequest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewRequest.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnNewRequest.UseVisualStyleBackColor = false;
            this.btnNewRequest.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnNewRequest.TabIndex = 1;
            this.btnNewRequest.Click += new System.EventHandler(this.btnNewRequest_Click);
            // 
            // FreezeForm
            // 
            this.PageTitle = "Freeze Management";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.mainLayout);
            this.actionsFlow.Controls.Add(this.btnNewRequest);
            this.footerPanel.ResumeLayout(false);
            this.footerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreeze)).EndInit();
            this.pnlTabs.ResumeLayout(false);
            this.pnlTabs.PerformLayout();
            this.mainLayout.ResumeLayout(false);
            this.mainLayout.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel mainLayout;
        private System.Windows.Forms.Panel pnlTabs;
        private System.Windows.Forms.RadioButton rbPending;
        private System.Windows.Forms.RadioButton rbApproved;
        private System.Windows.Forms.RadioButton rbCompleted;
        private System.Windows.Forms.RadioButton rbRejected;
        private System.Windows.Forms.DataGridView dgvFreeze;
        private System.Windows.Forms.Panel footerPanel;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnNewRequest;
    }
}

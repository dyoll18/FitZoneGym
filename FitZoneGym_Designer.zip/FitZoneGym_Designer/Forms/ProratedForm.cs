using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 9 - Prorated Billing and Fee Calculation.</summary>
    public partial class ProratedForm : ShellForm
    {
        private DataTable _plans = new DataTable();
        private ProratedResult _last;

        protected override string NavKey { get { return "prorate"; } }

        public ProratedForm()
        {
            InitializeComponent();
            dtpFrom.Value = DateTime.Today;
            dtpTo.Value = DateTime.Today.AddDays(9);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            Ui.Run(() =>
            {
                _plans = PlanService.List(true);
                foreach (DataRow r in _plans.Rows)
                    cboPlan.Items.Add(Db.S(r["PlanName"]) + "  (" + Ui.Money(Db.ToDec(r["Fee"])) + " / " + Db.I(r["DurationMonths"]) + " mo)");
                if (cboPlan.Items.Count > 0) cboPlan.SelectedIndex = 0;
            });
        }

        private void memberPicker_MemberChanged(object sender, EventArgs e)
        {
            string id = memberPicker.SelectedMemberId;
            if (id == null) return;
            var cur = MembershipService.Latest(id);
            if (cur == null) return;
            for (int i = 0; i < _plans.Rows.Count; i++)
                if (Db.I(_plans.Rows[i]["PlanID"]) == cur.PlanId) { cboPlan.SelectedIndex = i; break; }
        }

        private void Input_Changed(object sender, EventArgs e) { if (IsHandleCreated) ResetResult(); }

        private void ResetResult()
        {
            _last = null;
            btnCreate.Enabled = false;
            foreach (var l in new[] { lblMonthly, lblDaily, lblDays, lblProrated, lblDisc, lblFees, lblTotal }) l.Text = "-";
        }

        private MembershipPlan Plan()
        {
            return cboPlan.SelectedIndex < 0 || cboPlan.SelectedIndex >= _plans.Rows.Count ? null : PlanService.FromRow(_plans.Rows[cboPlan.SelectedIndex]);
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            var plan = Plan();
            if (plan == null) { Ui.Warn("Select a plan."); return; }
            ProratedResult r = null;
            if (!Ui.Run(() => r = BillingService.Calculate(plan.MonthlyEquivalent, dtpFrom.Value.Date, dtpTo.Value.Date, numDiscount.Value, numExtra.Value))) return;
            _last = r;
            lblMonthly.Text = Ui.Money(r.MonthlyFee);
            lblDaily.Text = Ui.Money(r.DailyRate);
            lblDays.Text = r.ChargeableDays + " day(s)";
            lblProrated.Text = Ui.Money(r.ProratedAmount);
            lblDisc.Text = "-" + Ui.Money(r.Discount);
            lblFees.Text = Ui.Money(r.AdditionalFees);
            lblTotal.Text = Ui.Money(r.Total);
            btnCreate.Enabled = Session.Current.Can(Perm.RecordPayments);
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (_last == null) { Ui.Warn("Calculate first."); return; }
            string id = memberPicker.SelectedMemberId;
            if (id == null) { Ui.Warn("Select the member to bill."); return; }
            var plan = Plan();
            if (!Ui.Confirm("Create an invoice for " + Ui.Money(_last.Total) + " for member " + id + "?")) return;
            string no = null;
            if (!Ui.Run(() => no = BillingService.CreateProratedInvoice(id, plan.MonthlyEquivalent, dtpFrom.Value.Date, dtpTo.Value.Date, numDiscount.Value, numExtra.Value, plan.PlanName))) return;
            Ui.Info("Invoice " + no + " created. Record payments on the Payments screen.");
            ResetResult();
        }
    }
}

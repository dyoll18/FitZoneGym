using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 11 - Invoice and Billing.</summary>
    public partial class InvoicesForm : ShellForm
    {
        private BillingService.InvoiceDetail _detail;

        protected override string NavKey { get { return "inv"; } }

        public InvoicesForm()
        {
            InitializeComponent();
            Ui.StyleGrid(dgvInvoices);
            Ui.StyleGrid(dgvItems);
            Ui.StyleGrid(dgvPayments);
            if (Ui.IsDesignTime) return;
            btnVoid.Visible = Session.Current.Can(Perm.ManageSettings);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (Ui.IsDesignTime) return;
            Reload();
        }

        private int SelectedId
        {
            get { return dgvInvoices.CurrentRow == null ? 0 : Db.I(dgvInvoices.CurrentRow.Cells["InvoiceID"].Value); }
        }

        private void Reload()
        {
            int keep = SelectedId;
            Ui.Run(() =>
            {
                var t = BillingService.ListInvoices(txtSearch.Text);
                Ui.Bind(dgvInvoices, t, new[] { "InvoiceID", "MemberID", "Kind" }, new[] { "TotalDue", "Paid" }, new[] { "InvoiceDate" });
                dgvInvoices.Columns["InvoiceNo"].HeaderText = "Invoice";
                dgvInvoices.Columns["FullName"].HeaderText = "Member";
                dgvInvoices.Columns["InvoiceDate"].HeaderText = "Date";
                dgvInvoices.Columns["TotalDue"].HeaderText = "Total";
                if (keep != 0)
                    foreach (DataGridViewRow r in dgvInvoices.Rows)
                        if (Db.I(r.Cells["InvoiceID"].Value) == keep) { dgvInvoices.CurrentCell = r.Cells["InvoiceNo"]; break; }
                ShowDetail();
            });
        }

        private void SetButtons(bool enabled)
        {
            btnPrint.Enabled = enabled;
            btnPreview.Enabled = enabled;
            btnSave.Enabled = enabled;
            btnVoid.Enabled = false;
        }

        private void ShowDetail()
        {
            _detail = null;
            SetButtons(false);
            dgvItems.DataSource = null;
            dgvPayments.DataSource = null;
            lblTotals.Text = "";
            if (SelectedId == 0) { lblHead.Text = "Select an invoice to see its details."; return; }
            Ui.Run(() =>
            {
                _detail = BillingService.GetDetail(SelectedId);
                var h = _detail.Header;
                lblHead.Text = "Invoice " + Db.S(h["InvoiceNo"]) + "  |  " + Db.S(h["FullName"]) + " (" + Db.S(h["MemberID"]) + ")\n" +
                               Db.S(h["Kind"]) + "  |  " + Ui.Date(Db.ToDate(h["InvoiceDate"])) + "  |  Status: " + _detail.Status();
                Ui.Bind(dgvItems, _detail.Items, null, new[] { "UnitPrice", "Discount" });
                Ui.Bind(dgvPayments, _detail.Payments, null, new[] { "Amount" }, new[] { "PaymentDate" });
                lblTotals.Text = "Total " + Ui.Money(_detail.Total) + "    Paid " + Ui.Money(_detail.Paid) + "    Balance " + Ui.Money(_detail.Balance);
                SetButtons(true);
                btnVoid.Enabled = _detail.Status() == "Unpaid";
            });
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Reload(); }
        }

        private void btnSearch_Click(object sender, EventArgs e) { Reload(); }
        private void dgvInvoices_SelectionChanged(object sender, EventArgs e) { if (IsHandleCreated) ShowDetail(); }

        private void Output(int mode)
        {
            if (_detail == null) return;
            Ui.Run(() =>
            {
                string text = InvoicePrinter.BuildText(_detail);
                if (mode == 2)
                {
                    using (var dlg = new SaveFileDialog { Filter = "Text file (*.txt)|*.txt", FileName = Db.S(_detail.Header["InvoiceNo"]) + ".txt" })
                        if (dlg.ShowDialog() == DialogResult.OK) { File.WriteAllText(dlg.FileName, text); Ui.Info("Saved to " + dlg.FileName); }
                }
                else InvoicePrinter.Print(text, mode == 1);
            });
        }

        private void btnPrint_Click(object sender, EventArgs e) { Output(0); }
        private void btnPreview_Click(object sender, EventArgs e) { Output(1); }
        private void btnSave_Click(object sender, EventArgs e) { Output(2); }

        private void btnVoid_Click(object sender, EventArgs e)
        {
            if (_detail == null) return;
            string reason = Ui.Prompt("Void invoice", "Reason for voiding invoice " + Db.S(_detail.Header["InvoiceNo"]) + " (required):");
            if (reason == null) return;
            if (Ui.Run(() => BillingService.Void(SelectedId, reason))) Reload();
        }
    }
}

namespace FitZoneGym.Forms
{
    partial class ProratedForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.pnlBody = new System.Windows.Forms.Panel();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.cardResult = new System.Windows.Forms.Panel();
            this.lblMonthlyCaption = new System.Windows.Forms.Label();
            this.lblMonthly = new System.Windows.Forms.Label();
            this.lblDailyCaption = new System.Windows.Forms.Label();
            this.lblDaily = new System.Windows.Forms.Label();
            this.lblDaysCaption = new System.Windows.Forms.Label();
            this.lblDays = new System.Windows.Forms.Label();
            this.lblProratedCaption = new System.Windows.Forms.Label();
            this.lblProrated = new System.Windows.Forms.Label();
            this.lblDiscCaption = new System.Windows.Forms.Label();
            this.lblDisc = new System.Windows.Forms.Label();
            this.lblFeesCaption = new System.Windows.Forms.Label();
            this.lblFees = new System.Windows.Forms.Label();
            this.lblTotalCaption = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblResultTitle = new System.Windows.Forms.Label();
            this.lblRules = new System.Windows.Forms.Label();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.lblFrom = new System.Windows.Forms.Label();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.lblTo = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.lblPlan = new System.Windows.Forms.Label();
            this.cboPlan = new System.Windows.Forms.ComboBox();
            this.lblDiscount = new System.Windows.Forms.Label();
            this.numDiscount = new System.Windows.Forms.NumericUpDown();
            this.lblExtra = new System.Windows.Forms.Label();
            this.numExtra = new System.Windows.Forms.NumericUpDown();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblMember = new System.Windows.Forms.Label();
            this.memberPicker = new FitZoneGym.Controls.MemberPicker();
            this.pnlBody.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.cardResult.SuspendLayout();
            this.pnlLeft.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBody
            // 
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlBody.Controls.Add(this.pnlRight);
            this.pnlBody.Controls.Add(this.pnlLeft);
            this.pnlBody.TabIndex = 0;
            // 
            // pnlRight
            // 
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRight.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlRight.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlRight.Controls.Add(this.cardResult);
            this.pnlRight.TabIndex = 0;
            // 
            // cardResult
            // 
            this.cardResult.Name = "cardResult";
            this.cardResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardResult.BackColor = System.Drawing.Color.White;
            this.cardResult.Controls.Add(this.lblMonthlyCaption);
            this.cardResult.Controls.Add(this.lblMonthly);
            this.cardResult.Controls.Add(this.lblDailyCaption);
            this.cardResult.Controls.Add(this.lblDaily);
            this.cardResult.Controls.Add(this.lblDaysCaption);
            this.cardResult.Controls.Add(this.lblDays);
            this.cardResult.Controls.Add(this.lblProratedCaption);
            this.cardResult.Controls.Add(this.lblProrated);
            this.cardResult.Controls.Add(this.lblDiscCaption);
            this.cardResult.Controls.Add(this.lblDisc);
            this.cardResult.Controls.Add(this.lblFeesCaption);
            this.cardResult.Controls.Add(this.lblFees);
            this.cardResult.Controls.Add(this.lblTotalCaption);
            this.cardResult.Controls.Add(this.lblTotal);
            this.cardResult.Controls.Add(this.lblResultTitle);
            this.cardResult.Controls.Add(this.lblRules);
            this.cardResult.TabIndex = 0;
            // 
            // lblMonthlyCaption
            // 
            this.lblMonthlyCaption.Name = "lblMonthlyCaption";
            this.lblMonthlyCaption.AutoSize = true;
            this.lblMonthlyCaption.Text = "Monthly fee";
            this.lblMonthlyCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblMonthlyCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMonthlyCaption.Location = new System.Drawing.Point(16, 50);
            this.lblMonthlyCaption.TabIndex = 0;
            // 
            // lblMonthly
            // 
            this.lblMonthly.Name = "lblMonthly";
            this.lblMonthly.AutoSize = true;
            this.lblMonthly.Text = "-";
            this.lblMonthly.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblMonthly.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblMonthly.Location = new System.Drawing.Point(220, 50);
            this.lblMonthly.TabIndex = 1;
            // 
            // lblDailyCaption
            // 
            this.lblDailyCaption.Name = "lblDailyCaption";
            this.lblDailyCaption.AutoSize = true;
            this.lblDailyCaption.Text = "Daily rate (fee ÷ 30)";
            this.lblDailyCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDailyCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDailyCaption.Location = new System.Drawing.Point(16, 82);
            this.lblDailyCaption.TabIndex = 2;
            // 
            // lblDaily
            // 
            this.lblDaily.Name = "lblDaily";
            this.lblDaily.AutoSize = true;
            this.lblDaily.Text = "-";
            this.lblDaily.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDaily.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblDaily.Location = new System.Drawing.Point(220, 82);
            this.lblDaily.TabIndex = 3;
            // 
            // lblDaysCaption
            // 
            this.lblDaysCaption.Name = "lblDaysCaption";
            this.lblDaysCaption.AutoSize = true;
            this.lblDaysCaption.Text = "Chargeable days";
            this.lblDaysCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDaysCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDaysCaption.Location = new System.Drawing.Point(16, 114);
            this.lblDaysCaption.TabIndex = 4;
            // 
            // lblDays
            // 
            this.lblDays.Name = "lblDays";
            this.lblDays.AutoSize = true;
            this.lblDays.Text = "-";
            this.lblDays.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDays.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblDays.Location = new System.Drawing.Point(220, 114);
            this.lblDays.TabIndex = 5;
            // 
            // lblProratedCaption
            // 
            this.lblProratedCaption.Name = "lblProratedCaption";
            this.lblProratedCaption.AutoSize = true;
            this.lblProratedCaption.Text = "Prorated amount";
            this.lblProratedCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblProratedCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblProratedCaption.Location = new System.Drawing.Point(16, 146);
            this.lblProratedCaption.TabIndex = 6;
            // 
            // lblProrated
            // 
            this.lblProrated.Name = "lblProrated";
            this.lblProrated.AutoSize = true;
            this.lblProrated.Text = "-";
            this.lblProrated.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblProrated.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblProrated.Location = new System.Drawing.Point(220, 146);
            this.lblProrated.TabIndex = 7;
            // 
            // lblDiscCaption
            // 
            this.lblDiscCaption.Name = "lblDiscCaption";
            this.lblDiscCaption.AutoSize = true;
            this.lblDiscCaption.Text = "Discount";
            this.lblDiscCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDiscCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDiscCaption.Location = new System.Drawing.Point(16, 178);
            this.lblDiscCaption.TabIndex = 8;
            // 
            // lblDisc
            // 
            this.lblDisc.Name = "lblDisc";
            this.lblDisc.AutoSize = true;
            this.lblDisc.Text = "-";
            this.lblDisc.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDisc.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblDisc.Location = new System.Drawing.Point(220, 178);
            this.lblDisc.TabIndex = 9;
            // 
            // lblFeesCaption
            // 
            this.lblFeesCaption.Name = "lblFeesCaption";
            this.lblFeesCaption.AutoSize = true;
            this.lblFeesCaption.Text = "Additional fees";
            this.lblFeesCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblFeesCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblFeesCaption.Location = new System.Drawing.Point(16, 210);
            this.lblFeesCaption.TabIndex = 10;
            // 
            // lblFees
            // 
            this.lblFees.Name = "lblFees";
            this.lblFees.AutoSize = true;
            this.lblFees.Text = "-";
            this.lblFees.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblFees.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblFees.Location = new System.Drawing.Point(220, 210);
            this.lblFees.TabIndex = 11;
            // 
            // lblTotalCaption
            // 
            this.lblTotalCaption.Name = "lblTotalCaption";
            this.lblTotalCaption.AutoSize = true;
            this.lblTotalCaption.Text = "TOTAL";
            this.lblTotalCaption.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTotalCaption.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblTotalCaption.Location = new System.Drawing.Point(16, 256);
            this.lblTotalCaption.TabIndex = 12;
            // 
            // lblTotal
            // 
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.AutoSize = true;
            this.lblTotal.Text = "-";
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 14.0F, System.Drawing.FontStyle.Bold);
            this.lblTotal.Location = new System.Drawing.Point(220, 252);
            this.lblTotal.TabIndex = 13;
            // 
            // lblResultTitle
            // 
            this.lblResultTitle.Name = "lblResultTitle";
            this.lblResultTitle.AutoSize = true;
            this.lblResultTitle.Text = "Calculation Result";
            this.lblResultTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblResultTitle.Font = new System.Drawing.Font("Segoe UI", 11.0F, System.Drawing.FontStyle.Bold);
            this.lblResultTitle.Location = new System.Drawing.Point(16, 12);
            this.lblResultTitle.TabIndex = 14;
            // 
            // lblRules
            // 
            this.lblRules.Name = "lblRules";
            this.lblRules.AutoSize = false;
            this.lblRules.Text = "Rules: daily rate = monthly fee ÷ 30 (rounded to 2 decimals); chargeable days count both the first and last date; prorated fee = daily rate × chargeable days. The displayed result is exactly what is saved on the invoice.";
            this.lblRules.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblRules.Font = new System.Drawing.Font("Segoe UI", 9.0F);
            this.lblRules.Size = new System.Drawing.Size(460, 70);
            this.lblRules.Location = new System.Drawing.Point(16, 310);
            this.lblRules.TabIndex = 15;
            // 
            // pnlLeft
            // 
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeft.Width = 540;
            this.pnlLeft.BackColor = System.Drawing.Color.White;
            this.pnlLeft.Controls.Add(this.lblFrom);
            this.pnlLeft.Controls.Add(this.dtpFrom);
            this.pnlLeft.Controls.Add(this.lblTo);
            this.pnlLeft.Controls.Add(this.dtpTo);
            this.pnlLeft.Controls.Add(this.lblPlan);
            this.pnlLeft.Controls.Add(this.cboPlan);
            this.pnlLeft.Controls.Add(this.lblDiscount);
            this.pnlLeft.Controls.Add(this.numDiscount);
            this.pnlLeft.Controls.Add(this.lblExtra);
            this.pnlLeft.Controls.Add(this.numExtra);
            this.pnlLeft.Controls.Add(this.btnCalculate);
            this.pnlLeft.Controls.Add(this.btnCreate);
            this.pnlLeft.TabIndex = 1;
            // 
            // lblFrom
            // 
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.AutoSize = true;
            this.lblFrom.Text = "Billing from";
            this.lblFrom.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblFrom.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblFrom.Location = new System.Drawing.Point(16, 24);
            this.lblFrom.TabIndex = 0;
            // 
            // dtpFrom
            // 
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFrom.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpFrom.Size = new System.Drawing.Size(160, 25);
            this.dtpFrom.Location = new System.Drawing.Point(190, 20);
            this.dtpFrom.TabIndex = 1;
            this.dtpFrom.ValueChanged += new System.EventHandler(this.Input_Changed);
            // 
            // lblTo
            // 
            this.lblTo.Name = "lblTo";
            this.lblTo.AutoSize = true;
            this.lblTo.Text = "Billing to";
            this.lblTo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTo.Location = new System.Drawing.Point(16, 62);
            this.lblTo.TabIndex = 2;
            // 
            // dtpTo
            // 
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpTo.Size = new System.Drawing.Size(160, 25);
            this.dtpTo.Location = new System.Drawing.Point(190, 58);
            this.dtpTo.TabIndex = 3;
            this.dtpTo.ValueChanged += new System.EventHandler(this.Input_Changed);
            // 
            // lblPlan
            // 
            this.lblPlan.Name = "lblPlan";
            this.lblPlan.AutoSize = true;
            this.lblPlan.Text = "Plan (monthly basis)";
            this.lblPlan.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblPlan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPlan.Location = new System.Drawing.Point(16, 100);
            this.lblPlan.TabIndex = 4;
            // 
            // cboPlan
            // 
            this.cboPlan.Name = "cboPlan";
            this.cboPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPlan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboPlan.Size = new System.Drawing.Size(300, 25);
            this.cboPlan.Location = new System.Drawing.Point(190, 96);
            this.cboPlan.TabIndex = 5;
            this.cboPlan.SelectedIndexChanged += new System.EventHandler(this.Input_Changed);
            // 
            // lblDiscount
            // 
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.AutoSize = true;
            this.lblDiscount.Text = "Discount (%)";
            this.lblDiscount.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDiscount.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDiscount.Location = new System.Drawing.Point(16, 138);
            this.lblDiscount.TabIndex = 6;
            // 
            // numDiscount
            // 
            this.numDiscount.Name = "numDiscount";
            this.numDiscount.Minimum = new decimal(new int[] {0, 0, 0, 0});
            this.numDiscount.Maximum = new decimal(new int[] {100, 0, 0, 0});
            this.numDiscount.Value = new decimal(new int[] {0, 0, 0, 0});
            this.numDiscount.DecimalPlaces = 0;
            this.numDiscount.ThousandsSeparator = true;
            this.numDiscount.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numDiscount.Size = new System.Drawing.Size(90, 25);
            this.numDiscount.Location = new System.Drawing.Point(190, 134);
            this.numDiscount.TabIndex = 7;
            this.numDiscount.ValueChanged += new System.EventHandler(this.Input_Changed);
            // 
            // lblExtra
            // 
            this.lblExtra.Name = "lblExtra";
            this.lblExtra.AutoSize = true;
            this.lblExtra.Text = "Additional fees";
            this.lblExtra.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblExtra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblExtra.Location = new System.Drawing.Point(16, 176);
            this.lblExtra.TabIndex = 8;
            // 
            // numExtra
            // 
            this.numExtra.Name = "numExtra";
            this.numExtra.Minimum = new decimal(new int[] {0, 0, 0, 0});
            this.numExtra.Maximum = new decimal(new int[] {1000000, 0, 0, 0});
            this.numExtra.Value = new decimal(new int[] {0, 0, 0, 0});
            this.numExtra.DecimalPlaces = 2;
            this.numExtra.ThousandsSeparator = true;
            this.numExtra.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.numExtra.Size = new System.Drawing.Size(140, 25);
            this.numExtra.Location = new System.Drawing.Point(190, 172);
            this.numExtra.TabIndex = 9;
            this.numExtra.ValueChanged += new System.EventHandler(this.Input_Changed);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.Size = new System.Drawing.Size(140, 40);
            this.btnCalculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalculate.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnCalculate.ForeColor = System.Drawing.Color.White;
            this.btnCalculate.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnCalculate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnCalculate.Location = new System.Drawing.Point(190, 224);
            this.btnCalculate.TabIndex = 10;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Text = "Create Invoice";
            this.btnCreate.Size = new System.Drawing.Size(160, 40);
            this.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreate.BackColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnCreate.ForeColor = System.Drawing.Color.White;
            this.btnCreate.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnCreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreate.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnCreate.UseVisualStyleBackColor = false;
            this.btnCreate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnCreate.Location = new System.Drawing.Point(340, 224);
            this.btnCreate.Enabled = false;
            this.btnCreate.TabIndex = 11;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // pnlTop
            // 
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Height = 66;
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlTop.Controls.Add(this.lblMember);
            this.pnlTop.Controls.Add(this.memberPicker);
            this.pnlTop.TabIndex = 1;
            // 
            // lblMember
            // 
            this.lblMember.Name = "lblMember";
            this.lblMember.AutoSize = true;
            this.lblMember.Text = "Member (needed to create an invoice)";
            this.lblMember.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblMember.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblMember.Location = new System.Drawing.Point(0, 0);
            this.lblMember.TabIndex = 0;
            // 
            // memberPicker
            // 
            this.memberPicker.Name = "memberPicker";
            this.memberPicker.Location = new System.Drawing.Point(0, 20);
            this.memberPicker.TabIndex = 1;
            this.memberPicker.MemberChanged += new System.EventHandler(this.memberPicker_MemberChanged);
            // 
            // ProratedForm
            // 
            this.PageTitle = "Prorated Billing";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.pnlBody);
            this.contentPanel.Controls.Add(this.pnlTop);
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlLeft.ResumeLayout(false);
            this.pnlLeft.PerformLayout();
            this.cardResult.ResumeLayout(false);
            this.cardResult.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.pnlBody.ResumeLayout(false);
            this.pnlBody.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel pnlBody;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel cardResult;
        private System.Windows.Forms.Label lblMonthlyCaption;
        private System.Windows.Forms.Label lblMonthly;
        private System.Windows.Forms.Label lblDailyCaption;
        private System.Windows.Forms.Label lblDaily;
        private System.Windows.Forms.Label lblDaysCaption;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.Label lblProratedCaption;
        private System.Windows.Forms.Label lblProrated;
        private System.Windows.Forms.Label lblDiscCaption;
        private System.Windows.Forms.Label lblDisc;
        private System.Windows.Forms.Label lblFeesCaption;
        private System.Windows.Forms.Label lblFees;
        private System.Windows.Forms.Label lblTotalCaption;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblResultTitle;
        private System.Windows.Forms.Label lblRules;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.Label lblPlan;
        private System.Windows.Forms.ComboBox cboPlan;
        private System.Windows.Forms.Label lblDiscount;
        private System.Windows.Forms.NumericUpDown numDiscount;
        private System.Windows.Forms.Label lblExtra;
        private System.Windows.Forms.NumericUpDown numExtra;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label lblMember;
        private FitZoneGym.Controls.MemberPicker memberPicker;
    }
}

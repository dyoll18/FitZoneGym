namespace FitZoneGym.Forms
{
    partial class BackupForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.tabs = new System.Windows.Forms.TabControl();
            this.tabBackup = new System.Windows.Forms.TabPage();
            this.dgvHistory = new System.Windows.Forms.DataGridView();
            this.lblHistTitle = new System.Windows.Forms.Label();
            this.pnlBackupTop = new System.Windows.Forms.Panel();
            this.lblDbCap = new System.Windows.Forms.Label();
            this.lblDbPath = new System.Windows.Forms.Label();
            this.lblBackupCap = new System.Windows.Forms.Label();
            this.txtBackupPath = new System.Windows.Forms.TextBox();
            this.btnBrowseBackup = new System.Windows.Forms.Button();
            this.btnBackupNow = new System.Windows.Forms.Button();
            this.lblRestoreCap = new System.Windows.Forms.Label();
            this.txtRestorePath = new System.Windows.Forms.TextBox();
            this.btnBrowseRestore = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.lblWarn = new System.Windows.Forms.Label();
            this.tabValidation = new System.Windows.Forms.TabPage();
            this.dgvValidation = new System.Windows.Forms.DataGridView();
            this.tabErrors = new System.Windows.Forms.TabPage();
            this.dgvErrors = new System.Windows.Forms.DataGridView();
            this.tabs.SuspendLayout();
            this.tabBackup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).BeginInit();
            this.pnlBackupTop.SuspendLayout();
            this.tabValidation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidation)).BeginInit();
            this.tabErrors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvErrors)).BeginInit();
            this.SuspendLayout();
            // 
            // tabs
            // 
            this.tabs.Name = "tabs";
            this.tabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabs.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.tabs.TabPages.Add(this.tabBackup);
            this.tabs.TabPages.Add(this.tabValidation);
            this.tabs.TabPages.Add(this.tabErrors);
            this.tabs.TabIndex = 0;
            this.tabs.SelectedIndexChanged += new System.EventHandler(this.tabs_SelectedIndexChanged);
            // 
            // tabBackup
            // 
            this.tabBackup.Name = "tabBackup";
            this.tabBackup.Text = "Backup / Restore";
            this.tabBackup.BackColor = System.Drawing.Color.White;
            this.tabBackup.Padding = new System.Windows.Forms.Padding(12, 12, 12, 12);
            this.tabBackup.UseVisualStyleBackColor = false;
            this.tabBackup.Controls.Add(this.dgvHistory);
            this.tabBackup.Controls.Add(this.lblHistTitle);
            this.tabBackup.Controls.Add(this.pnlBackupTop);
            this.tabBackup.TabIndex = 0;
            // 
            // dgvHistory
            // 
            this.dgvHistory.Name = "dgvHistory";
            this.dgvHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHistory.TabIndex = 0;
            // 
            // lblHistTitle
            // 
            this.lblHistTitle.Name = "lblHistTitle";
            this.lblHistTitle.AutoSize = false;
            this.lblHistTitle.Text = "Backup history";
            this.lblHistTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblHistTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblHistTitle.Size = new System.Drawing.Size(100, 28);
            this.lblHistTitle.Location = new System.Drawing.Point(0, 0);
            this.lblHistTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHistTitle.TabIndex = 1;
            // 
            // pnlBackupTop
            // 
            this.pnlBackupTop.Name = "pnlBackupTop";
            this.pnlBackupTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBackupTop.Height = 228;
            this.pnlBackupTop.BackColor = System.Drawing.Color.White;
            this.pnlBackupTop.Controls.Add(this.lblDbCap);
            this.pnlBackupTop.Controls.Add(this.lblDbPath);
            this.pnlBackupTop.Controls.Add(this.lblBackupCap);
            this.pnlBackupTop.Controls.Add(this.txtBackupPath);
            this.pnlBackupTop.Controls.Add(this.btnBrowseBackup);
            this.pnlBackupTop.Controls.Add(this.btnBackupNow);
            this.pnlBackupTop.Controls.Add(this.lblRestoreCap);
            this.pnlBackupTop.Controls.Add(this.txtRestorePath);
            this.pnlBackupTop.Controls.Add(this.btnBrowseRestore);
            this.pnlBackupTop.Controls.Add(this.btnRestore);
            this.pnlBackupTop.Controls.Add(this.lblWarn);
            this.pnlBackupTop.TabIndex = 2;
            // 
            // lblDbCap
            // 
            this.lblDbCap.Name = "lblDbCap";
            this.lblDbCap.AutoSize = true;
            this.lblDbCap.Text = "Database file";
            this.lblDbCap.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblDbCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDbCap.Location = new System.Drawing.Point(0, 12);
            this.lblDbCap.TabIndex = 0;
            // 
            // lblDbPath
            // 
            this.lblDbPath.Name = "lblDbPath";
            this.lblDbPath.AutoSize = true;
            this.lblDbPath.Text = "";
            this.lblDbPath.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblDbPath.Font = new System.Drawing.Font("Segoe UI", 9.0F);
            this.lblDbPath.Location = new System.Drawing.Point(160, 12);
            this.lblDbPath.TabIndex = 1;
            // 
            // lblBackupCap
            // 
            this.lblBackupCap.Name = "lblBackupCap";
            this.lblBackupCap.AutoSize = true;
            this.lblBackupCap.Text = "Backup file";
            this.lblBackupCap.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblBackupCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblBackupCap.Location = new System.Drawing.Point(0, 52);
            this.lblBackupCap.TabIndex = 2;
            // 
            // txtBackupPath
            // 
            this.txtBackupPath.Name = "txtBackupPath";
            this.txtBackupPath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBackupPath.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtBackupPath.Size = new System.Drawing.Size(440, 25);
            this.txtBackupPath.Location = new System.Drawing.Point(160, 48);
            this.txtBackupPath.TabIndex = 3;
            // 
            // btnBrowseBackup
            // 
            this.btnBrowseBackup.Name = "btnBrowseBackup";
            this.btnBrowseBackup.Text = "Browse...";
            this.btnBrowseBackup.Size = new System.Drawing.Size(100, 27);
            this.btnBrowseBackup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowseBackup.BackColor = System.Drawing.Color.White;
            this.btnBrowseBackup.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.btnBrowseBackup.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnBrowseBackup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowseBackup.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnBrowseBackup.UseVisualStyleBackColor = false;
            this.btnBrowseBackup.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.btnBrowseBackup.Location = new System.Drawing.Point(610, 47);
            this.btnBrowseBackup.TabIndex = 4;
            this.btnBrowseBackup.Click += new System.EventHandler(this.btnBrowseBackup_Click);
            // 
            // btnBackupNow
            // 
            this.btnBackupNow.Name = "btnBackupNow";
            this.btnBackupNow.Text = "Backup Now";
            this.btnBackupNow.Size = new System.Drawing.Size(140, 34);
            this.btnBackupNow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackupNow.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnBackupNow.ForeColor = System.Drawing.Color.White;
            this.btnBackupNow.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnBackupNow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBackupNow.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnBackupNow.UseVisualStyleBackColor = false;
            this.btnBackupNow.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnBackupNow.Location = new System.Drawing.Point(160, 88);
            this.btnBackupNow.TabIndex = 5;
            this.btnBackupNow.Click += new System.EventHandler(this.btnBackupNow_Click);
            // 
            // lblRestoreCap
            // 
            this.lblRestoreCap.Name = "lblRestoreCap";
            this.lblRestoreCap.AutoSize = true;
            this.lblRestoreCap.Text = "Restore from";
            this.lblRestoreCap.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblRestoreCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblRestoreCap.Location = new System.Drawing.Point(0, 142);
            this.lblRestoreCap.TabIndex = 6;
            // 
            // txtRestorePath
            // 
            this.txtRestorePath.Name = "txtRestorePath";
            this.txtRestorePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRestorePath.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtRestorePath.Size = new System.Drawing.Size(440, 25);
            this.txtRestorePath.Location = new System.Drawing.Point(160, 138);
            this.txtRestorePath.TabIndex = 7;
            // 
            // btnBrowseRestore
            // 
            this.btnBrowseRestore.Name = "btnBrowseRestore";
            this.btnBrowseRestore.Text = "Browse...";
            this.btnBrowseRestore.Size = new System.Drawing.Size(100, 27);
            this.btnBrowseRestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowseRestore.BackColor = System.Drawing.Color.White;
            this.btnBrowseRestore.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.btnBrowseRestore.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnBrowseRestore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowseRestore.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnBrowseRestore.UseVisualStyleBackColor = false;
            this.btnBrowseRestore.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.btnBrowseRestore.Location = new System.Drawing.Point(610, 137);
            this.btnBrowseRestore.TabIndex = 8;
            this.btnBrowseRestore.Click += new System.EventHandler(this.btnBrowseRestore_Click);
            // 
            // btnRestore
            // 
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Text = "Restore Backup";
            this.btnRestore.Size = new System.Drawing.Size(150, 34);
            this.btnRestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestore.BackColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.btnRestore.ForeColor = System.Drawing.Color.White;
            this.btnRestore.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnRestore.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRestore.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnRestore.UseVisualStyleBackColor = false;
            this.btnRestore.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.btnRestore.Location = new System.Drawing.Point(160, 178);
            this.btnRestore.TabIndex = 9;
            this.btnRestore.Click += new System.EventHandler(this.btnRestore_Click);
            // 
            // lblWarn
            // 
            this.lblWarn.Name = "lblWarn";
            this.lblWarn.AutoSize = true;
            this.lblWarn.Text = "Restore replaces ALL current data (a safety copy is made first).";
            this.lblWarn.ForeColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.lblWarn.Font = new System.Drawing.Font("Segoe UI", 9.0F);
            this.lblWarn.Location = new System.Drawing.Point(320, 186);
            this.lblWarn.TabIndex = 10;
            // 
            // tabValidation
            // 
            this.tabValidation.Name = "tabValidation";
            this.tabValidation.Text = "Validation Logs";
            this.tabValidation.BackColor = System.Drawing.Color.White;
            this.tabValidation.Padding = new System.Windows.Forms.Padding(12, 12, 12, 12);
            this.tabValidation.UseVisualStyleBackColor = false;
            this.tabValidation.Controls.Add(this.dgvValidation);
            this.tabValidation.TabIndex = 1;
            // 
            // dgvValidation
            // 
            this.dgvValidation.Name = "dgvValidation";
            this.dgvValidation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvValidation.TabIndex = 0;
            // 
            // tabErrors
            // 
            this.tabErrors.Name = "tabErrors";
            this.tabErrors.Text = "Error Logs";
            this.tabErrors.BackColor = System.Drawing.Color.White;
            this.tabErrors.Padding = new System.Windows.Forms.Padding(12, 12, 12, 12);
            this.tabErrors.UseVisualStyleBackColor = false;
            this.tabErrors.Controls.Add(this.dgvErrors);
            this.tabErrors.TabIndex = 2;
            // 
            // dgvErrors
            // 
            this.dgvErrors.Name = "dgvErrors";
            this.dgvErrors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvErrors.TabIndex = 0;
            // 
            // BackupForm
            // 
            this.PageTitle = "Database & Backup";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.tabs);
            ((System.ComponentModel.ISupportInitialize)(this.dgvErrors)).EndInit();
            this.tabErrors.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidation)).EndInit();
            this.tabValidation.ResumeLayout(false);
            this.pnlBackupTop.ResumeLayout(false);
            this.pnlBackupTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).EndInit();
            this.tabBackup.ResumeLayout(false);
            this.tabs.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage tabBackup;
        private System.Windows.Forms.DataGridView dgvHistory;
        private System.Windows.Forms.Label lblHistTitle;
        private System.Windows.Forms.Panel pnlBackupTop;
        private System.Windows.Forms.Label lblDbCap;
        private System.Windows.Forms.Label lblDbPath;
        private System.Windows.Forms.Label lblBackupCap;
        private System.Windows.Forms.TextBox txtBackupPath;
        private System.Windows.Forms.Button btnBrowseBackup;
        private System.Windows.Forms.Button btnBackupNow;
        private System.Windows.Forms.Label lblRestoreCap;
        private System.Windows.Forms.TextBox txtRestorePath;
        private System.Windows.Forms.Button btnBrowseRestore;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.Label lblWarn;
        private System.Windows.Forms.TabPage tabValidation;
        private System.Windows.Forms.DataGridView dgvValidation;
        private System.Windows.Forms.TabPage tabErrors;
        private System.Windows.Forms.DataGridView dgvErrors;
    }
}

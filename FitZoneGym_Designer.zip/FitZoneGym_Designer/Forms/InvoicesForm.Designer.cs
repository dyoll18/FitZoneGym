namespace FitZoneGym.Forms
{
    partial class InvoicesForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.pnlRight = new System.Windows.Forms.Panel();
            this.cardDetail = new System.Windows.Forms.Panel();
            this.dgvPayments = new System.Windows.Forms.DataGridView();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblTotals = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnVoid = new System.Windows.Forms.Button();
            this.lblPayTitle = new System.Windows.Forms.Label();
            this.dgvItems = new System.Windows.Forms.DataGridView();
            this.lblHead = new System.Windows.Forms.Label();
            this.cardList = new System.Windows.Forms.Panel();
            this.dgvInvoices = new System.Windows.Forms.DataGridView();
            this.pnlSearch = new System.Windows.Forms.Panel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblListTitle = new System.Windows.Forms.Label();
            this.pnlRight.SuspendLayout();
            this.cardDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayments)).BeginInit();
            this.pnlBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            this.cardList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoices)).BeginInit();
            this.pnlSearch.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlRight
            // 
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRight.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.pnlRight.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlRight.Controls.Add(this.cardDetail);
            this.pnlRight.TabIndex = 0;
            // 
            // cardDetail
            // 
            this.cardDetail.Name = "cardDetail";
            this.cardDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cardDetail.BackColor = System.Drawing.Color.White;
            this.cardDetail.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardDetail.Controls.Add(this.dgvPayments);
            this.cardDetail.Controls.Add(this.pnlBottom);
            this.cardDetail.Controls.Add(this.lblPayTitle);
            this.cardDetail.Controls.Add(this.dgvItems);
            this.cardDetail.Controls.Add(this.lblHead);
            this.cardDetail.TabIndex = 0;
            // 
            // dgvPayments
            // 
            this.dgvPayments.Name = "dgvPayments";
            this.dgvPayments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPayments.TabIndex = 0;
            // 
            // pnlBottom
            // 
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Height = 92;
            this.pnlBottom.BackColor = System.Drawing.Color.White;
            this.pnlBottom.Controls.Add(this.lblTotals);
            this.pnlBottom.Controls.Add(this.btnPrint);
            this.pnlBottom.Controls.Add(this.btnPreview);
            this.pnlBottom.Controls.Add(this.btnSave);
            this.pnlBottom.Controls.Add(this.btnVoid);
            this.pnlBottom.TabIndex = 1;
            // 
            // lblTotals
            // 
            this.lblTotals.Name = "lblTotals";
            this.lblTotals.AutoSize = true;
            this.lblTotals.Text = "";
            this.lblTotals.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTotals.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblTotals.Location = new System.Drawing.Point(0, 8);
            this.lblTotals.TabIndex = 0;
            // 
            // btnPrint
            // 
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Text = "Print Invoice";
            this.btnPrint.Size = new System.Drawing.Size(130, 34);
            this.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnPrint.ForeColor = System.Drawing.Color.White;
            this.btnPrint.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnPrint.UseVisualStyleBackColor = false;
            this.btnPrint.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnPrint.Location = new System.Drawing.Point(0, 44);
            this.btnPrint.Enabled = false;
            this.btnPrint.TabIndex = 1;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Text = "Print Preview";
            this.btnPreview.Size = new System.Drawing.Size(130, 34);
            this.btnPreview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPreview.BackColor = System.Drawing.Color.White;
            this.btnPreview.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.btnPreview.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnPreview.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPreview.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnPreview.UseVisualStyleBackColor = false;
            this.btnPreview.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.btnPreview.Location = new System.Drawing.Point(140, 44);
            this.btnPreview.Enabled = false;
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnSave
            // 
            this.btnSave.Name = "btnSave";
            this.btnSave.Text = "Save as Text";
            this.btnSave.Size = new System.Drawing.Size(130, 34);
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.btnSave.Location = new System.Drawing.Point(280, 44);
            this.btnSave.Enabled = false;
            this.btnSave.TabIndex = 3;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnVoid
            // 
            this.btnVoid.Name = "btnVoid";
            this.btnVoid.Text = "Void Invoice";
            this.btnVoid.Size = new System.Drawing.Size(130, 34);
            this.btnVoid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVoid.BackColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.btnVoid.ForeColor = System.Drawing.Color.White;
            this.btnVoid.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnVoid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVoid.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnVoid.UseVisualStyleBackColor = false;
            this.btnVoid.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.btnVoid.Location = new System.Drawing.Point(420, 44);
            this.btnVoid.Enabled = false;
            this.btnVoid.TabIndex = 4;
            this.btnVoid.Click += new System.EventHandler(this.btnVoid_Click);
            // 
            // lblPayTitle
            // 
            this.lblPayTitle.Name = "lblPayTitle";
            this.lblPayTitle.AutoSize = false;
            this.lblPayTitle.Text = "Payments";
            this.lblPayTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblPayTitle.Font = new System.Drawing.Font("Segoe UI", 10.0F, System.Drawing.FontStyle.Bold);
            this.lblPayTitle.Size = new System.Drawing.Size(100, 28);
            this.lblPayTitle.Location = new System.Drawing.Point(0, 0);
            this.lblPayTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPayTitle.TabIndex = 2;
            // 
            // dgvItems
            // 
            this.dgvItems.Name = "dgvItems";
            this.dgvItems.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvItems.Height = 190;
            this.dgvItems.TabIndex = 3;
            // 
            // lblHead
            // 
            this.lblHead.Name = "lblHead";
            this.lblHead.AutoSize = false;
            this.lblHead.Text = "Select an invoice to see its details.";
            this.lblHead.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblHead.Font = new System.Drawing.Font("Segoe UI", 10.0F, System.Drawing.FontStyle.Bold);
            this.lblHead.Size = new System.Drawing.Size(100, 56);
            this.lblHead.Location = new System.Drawing.Point(0, 0);
            this.lblHead.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHead.TabIndex = 4;
            // 
            // cardList
            // 
            this.cardList.Name = "cardList";
            this.cardList.Dock = System.Windows.Forms.DockStyle.Left;
            this.cardList.Width = 470;
            this.cardList.BackColor = System.Drawing.Color.White;
            this.cardList.Padding = new System.Windows.Forms.Padding(14, 14, 14, 14);
            this.cardList.Controls.Add(this.dgvInvoices);
            this.cardList.Controls.Add(this.pnlSearch);
            this.cardList.Controls.Add(this.lblListTitle);
            this.cardList.TabIndex = 1;
            // 
            // dgvInvoices
            // 
            this.dgvInvoices.Name = "dgvInvoices";
            this.dgvInvoices.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvInvoices.TabIndex = 0;
            this.dgvInvoices.SelectionChanged += new System.EventHandler(this.dgvInvoices_SelectionChanged);
            // 
            // pnlSearch
            // 
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearch.Height = 40;
            this.pnlSearch.BackColor = System.Drawing.Color.White;
            this.pnlSearch.Controls.Add(this.txtSearch);
            this.pnlSearch.Controls.Add(this.btnSearch);
            this.pnlSearch.TabIndex = 1;
            // 
            // txtSearch
            // 
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSearch.Size = new System.Drawing.Size(300, 25);
            this.txtSearch.PlaceholderText = "Invoice no., member ID or name";
            this.txtSearch.Location = new System.Drawing.Point(0, 6);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // btnSearch
            // 
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Text = "Search";
            this.btnSearch.Size = new System.Drawing.Size(90, 27);
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnSearch.Location = new System.Drawing.Point(310, 5);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblListTitle
            // 
            this.lblListTitle.Name = "lblListTitle";
            this.lblListTitle.AutoSize = false;
            this.lblListTitle.Text = "Invoices";
            this.lblListTitle.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.lblListTitle.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblListTitle.Size = new System.Drawing.Size(100, 30);
            this.lblListTitle.Location = new System.Drawing.Point(0, 0);
            this.lblListTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblListTitle.TabIndex = 2;
            // 
            // InvoicesForm
            // 
            this.PageTitle = "Invoice & Billing";
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.contentPanel.Controls.Add(this.pnlRight);
            this.contentPanel.Controls.Add(this.cardList);
            this.pnlSearch.ResumeLayout(false);
            this.pnlSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoices)).EndInit();
            this.cardList.ResumeLayout(false);
            this.cardList.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayments)).EndInit();
            this.cardDetail.ResumeLayout(false);
            this.cardDetail.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.Panel cardDetail;
        private System.Windows.Forms.DataGridView dgvPayments;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblTotals;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnVoid;
        private System.Windows.Forms.Label lblPayTitle;
        private System.Windows.Forms.DataGridView dgvItems;
        private System.Windows.Forms.Label lblHead;
        private System.Windows.Forms.Panel cardList;
        private System.Windows.Forms.DataGridView dgvInvoices;
        private System.Windows.Forms.Panel pnlSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblListTitle;
    }
}

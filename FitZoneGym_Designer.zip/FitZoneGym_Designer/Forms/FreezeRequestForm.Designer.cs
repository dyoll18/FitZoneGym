namespace FitZoneGym.Forms
{
    partial class FreezeRequestForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.lblMember = new System.Windows.Forms.Label();
            this.memberPicker = new FitZoneGym.Controls.MemberPicker();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblFrom = new System.Windows.Forms.Label();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.lblTo = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.lblReason = new System.Windows.Forms.Label();
            this.txtReason = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMember
            // 
            this.lblMember.Name = "lblMember";
            this.lblMember.AutoSize = true;
            this.lblMember.Text = "Member";
            this.lblMember.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblMember.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblMember.Location = new System.Drawing.Point(20, 16);
            this.lblMember.TabIndex = 0;
            // 
            // memberPicker
            // 
            this.memberPicker.Name = "memberPicker";
            this.memberPicker.Location = new System.Drawing.Point(20, 38);
            this.memberPicker.TabIndex = 1;
            this.memberPicker.MemberChanged += new System.EventHandler(this.memberPicker_MemberChanged);
            // 
            // lblInfo
            // 
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.AutoSize = false;
            this.lblInfo.Text = "Search and select a member.";
            this.lblInfo.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblInfo.Size = new System.Drawing.Size(680, 44);
            this.lblInfo.Location = new System.Drawing.Point(20, 82);
            this.lblInfo.TabIndex = 2;
            // 
            // lblFrom
            // 
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.AutoSize = true;
            this.lblFrom.Text = "Freeze from";
            this.lblFrom.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblFrom.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblFrom.Location = new System.Drawing.Point(20, 138);
            this.lblFrom.TabIndex = 3;
            // 
            // dtpFrom
            // 
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFrom.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpFrom.Size = new System.Drawing.Size(160, 25);
            this.dtpFrom.Location = new System.Drawing.Point(160, 134);
            this.dtpFrom.TabIndex = 4;
            // 
            // lblTo
            // 
            this.lblTo.Name = "lblTo";
            this.lblTo.AutoSize = true;
            this.lblTo.Text = "Freeze to";
            this.lblTo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblTo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTo.Location = new System.Drawing.Point(20, 176);
            this.lblTo.TabIndex = 5;
            // 
            // dtpTo
            // 
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpTo.Size = new System.Drawing.Size(160, 25);
            this.dtpTo.Location = new System.Drawing.Point(160, 172);
            this.dtpTo.TabIndex = 6;
            // 
            // lblReason
            // 
            this.lblReason.Name = "lblReason";
            this.lblReason.AutoSize = true;
            this.lblReason.Text = "Reason *";
            this.lblReason.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.lblReason.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblReason.Location = new System.Drawing.Point(20, 214);
            this.lblReason.TabIndex = 7;
            // 
            // txtReason
            // 
            this.txtReason.Name = "txtReason";
            this.txtReason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReason.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtReason.Size = new System.Drawing.Size(520, 70);
            this.txtReason.Multiline = true;
            this.txtReason.Location = new System.Drawing.Point(160, 210);
            this.txtReason.TabIndex = 8;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Text = "Submit Request";
            this.btnSubmit.Size = new System.Drawing.Size(140, 34);
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(30, 111, 240);
            this.btnSubmit.Location = new System.Drawing.Point(420, 346);
            this.btnSubmit.TabIndex = 9;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Size = new System.Drawing.Size(120, 34);
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.BackColor = System.Drawing.Color.White;
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55);
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(214, 221, 232);
            this.btnCancel.Location = new System.Drawing.Point(570, 346);
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.TabIndex = 10;
            // 
            // FreezeRequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(720, 400);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.BackColor = System.Drawing.Color.White;
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.Text = "New Freeze Request";
            this.AcceptButton = this.btnSubmit;
            this.CancelButton = this.btnCancel;
            this.Controls.Add(this.lblMember);
            this.Controls.Add(this.memberPicker);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblFrom);
            this.Controls.Add(this.dtpFrom);
            this.Controls.Add(this.lblTo);
            this.Controls.Add(this.dtpTo);
            this.Controls.Add(this.lblReason);
            this.Controls.Add(this.txtReason);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnCancel);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblMember;
        private FitZoneGym.Controls.MemberPicker memberPicker;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.TextBox txtReason;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnCancel;
    }
}

namespace FitZoneGym.Forms
{
    /// <summary>Screen 16 - Logout confirmation.</summary>
    public class LogoutDialog : Form
    {
        public LogoutDialog()
        {
            Text = "Confirm Logout";
            ClientSize = new Size(380, 210);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.White;
            Font = Ui.Base;

            var title = new Label { Text = "Confirm Logout", Font = Ui.Bold(15f), ForeColor = Ui.Navy, AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Left = 0, Top = 30, Width = 380, Height = 36 };
            var msg = new Label { Text = "Are you sure you want to logout?", ForeColor = Ui.Text, AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Left = 0, Top = 76, Width = 380, Height = 28 };
            var yes = Ui.Primary("Yes", null, 130); yes.Left = 50; yes.Top = 130; yes.Height = 40; yes.DialogResult = DialogResult.Yes;
            var no = Ui.Secondary("No", null, 130); no.Left = 200; no.Top = 130; no.Height = 40; no.DialogResult = DialogResult.No;
            Controls.AddRange(new Control[] { title, msg, yes, no });
            AcceptButton = yes; CancelButton = no;
        }
    }
}

using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 1 - Login.</summary>
    public class LoginForm : Form
    {
        private readonly TextBox _user = Ui.Input(300);
        private readonly TextBox _pass = Ui.Input(300);
        private readonly CheckBox _remember = new CheckBox { Text = "Remember me", AutoSize = true, Font = Ui.Base };
        private readonly Label _message = new Label { AutoSize = false, Height = 36, Width = 300, ForeColor = Ui.Red, Font = Ui.Base };
        private readonly Button _login;
        private readonly System.Windows.Forms.Timer _lock = new System.Windows.Forms.Timer { Interval = 1000 };
        private int _failures, _lockSeconds;

        private static string RememberFile
        {
            get
            {
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FitZoneGym");
                Directory.CreateDirectory(dir);
                return Path.Combine(dir, "last_user.txt");
            }
        }

        public LoginForm()
        {
            Text = "FITZONE GYM - Login";
            ClientSize = new Size(820, 470);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Font = Ui.Base;
            BackColor = Color.White;

            // Left brand panel
            var left = new Panel { Left = 0, Top = 0, Width = 340, Height = 470, BackColor = Ui.Navy };
            var brand = new Label { Text = "FITZONE", ForeColor = Color.White, Font = new Font("Segoe UI", 30f, FontStyle.Bold), AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Left = 0, Top = 140, Width = 340, Height = 60 };
            var gym = new Label { Text = "G Y M", ForeColor = Color.FromArgb(120, 170, 255), Font = new Font("Segoe UI", 16f, FontStyle.Bold), AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Left = 0, Top = 198, Width = 340, Height = 34 };
            var tag = new Label { Text = "STRONGER TODAY,\nHEALTHIER TOMORROW", ForeColor = Color.White, Font = Ui.Bold(10.5f), AutoSize = false, TextAlign = ContentAlignment.MiddleCenter, Left = 0, Top = 260, Width = 340, Height = 50 };
            left.Controls.AddRange(new Control[] { brand, gym, tag });

            // Right form
            int x = 400;
            var title = new Label { Text = "Login", Font = Ui.Bold(20f), ForeColor = Ui.Navy, Left = x, Top = 50, AutoSize = true };
            var sub = new Label { Text = "Welcome back! Please login to your account.", ForeColor = Ui.Muted, Left = x, Top = 96, AutoSize = true };
            var ulabel = new Label { Text = "Username", Font = Ui.Bold(9.5f), Left = x, Top = 140, AutoSize = true };
            _user.Left = x; _user.Top = 164;
            var plabel = new Label { Text = "Password", Font = Ui.Bold(9.5f), Left = x, Top = 204, AutoSize = true };
            _pass.Left = x; _pass.Top = 228; _pass.UseSystemPasswordChar = true;
            var show = new CheckBox { Text = "Show", AutoSize = true, Left = x + 306, Top = 230, Font = Ui.Base };
            show.CheckedChanged += (s, e) => _pass.UseSystemPasswordChar = !show.Checked;

            _remember.Left = x; _remember.Top = 268;
            _message.Left = x; _message.Top = 296;

            _login = Ui.Primary("Login", (s, e) => DoLogin(), 300);
            _login.Left = x; _login.Top = 338; _login.Height = 40;
            var cancel = Ui.Secondary("Cancel", (s, e) => { DialogResult = DialogResult.Cancel; Close(); }, 300);
            cancel.Left = x; cancel.Top = 386; cancel.Height = 40;

            Controls.AddRange(new Control[] { left, title, sub, ulabel, _user, plabel, _pass, show, _remember, _message, _login, cancel });
            AcceptButton = _login;
            CancelButton = cancel;

            _lock.Tick += (s, e) =>
            {
                _lockSeconds--;
                if (_lockSeconds <= 0) { _lock.Stop(); _login.Enabled = true; _message.Text = ""; _failures = 0; }
                else _message.Text = "Too many failed attempts. Try again in " + _lockSeconds + "s.";
            };

            try { if (File.Exists(RememberFile)) { _user.Text = File.ReadAllText(RememberFile).Trim(); _remember.Checked = _user.Text.Length > 0; } } catch { }
            Shown += (s, e) => { if (_user.Text.Length > 0) _pass.Focus(); else _user.Focus(); };
        }

        private void DoLogin()
        {
            _message.Text = "";
            try
            {
                AuthService.Login(_user.Text, _pass.Text);
                try
                {
                    if (_remember.Checked) File.WriteAllText(RememberFile, _user.Text.Trim());
                    else if (File.Exists(RememberFile)) File.Delete(RememberFile);
                }
                catch { }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (ValidationException ex)
            {
                _message.Text = ex.Message;
                _pass.Clear();
                _pass.Focus();
                if (++_failures >= 5) { _lockSeconds = 30; _login.Enabled = false; _lock.Start(); }
            }
            catch (Exception ex)
            {
                Audit.Error("Error", ex.ToString());
                _message.Text = "Could not sign in: " + ex.Message;
            }
        }
    }
}

using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>Screen 4 - Add / Edit Member.</summary>
    public class MemberEditForm : Form
    {
        private readonly string _memberId;       // null when adding
        private readonly TextBox _name = Ui.Input(), _contact = Ui.Input(), _email = Ui.Input(), _address = Ui.Input(), _notes = Ui.Input();
        private readonly ComboBox _gender = Ui.Combo(220, "", "Male", "Female", "Other");
        private readonly DateTimePicker _birth = Ui.DatePicker(DateTime.Today.AddYears(-25));
        private readonly ComboBox _status = Ui.Combo(220, "Active", "Inactive");
        private readonly ComboBox _plan = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Font = Ui.Base };
        private readonly DateTimePicker _start = Ui.DatePicker();
        private readonly ErrorProvider _err = new ErrorProvider();
        private DataTable _plans;

        public MemberEditForm(string memberId = null)
        {
            _memberId = memberId;
            Text = memberId == null ? "Add Member" : "Edit Member - " + memberId;
            ClientSize = new Size(560, memberId == null ? 560 : 500);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.White;
            Font = Ui.Base;

            _birth.ShowCheckBox = true; _birth.Checked = false;
            _address.Multiline = true; _notes.Multiline = true;

            var form = new FormPanel(140) { Left = 20, Top = 16, Width = 520 };
            form.AddRow("Full name *", _name);
            form.AddRow("Contact number *", _contact);
            form.AddRow("Email", _email);
            form.AddRow("Gender", _gender);
            form.AddRow("Date of birth", _birth);
            form.AddRow("Address", _address, 60);
            form.AddRow("Notes", _notes, 60);

            if (memberId != null) form.AddRow("Account status", _status);
            else
            {
                _plans = PlanService.List(true);
                _plan.Items.Add("(none - register membership later)");
                foreach (DataRow r in _plans.Rows)
                    _plan.Items.Add(Db.S(r["PlanName"]) + "  -  " + Ui.Money(Db.ToDec(r["Fee"])) + " / " + Db.I(r["DurationMonths"]) + " mo");
                _plan.SelectedIndex = 0;
                form.AddRow("Membership plan", _plan);
                form.AddRow("Start date", _start);
            }
            Controls.Add(form);

            var save = Ui.Primary("Save", (s, e) => Save(), 120);
            var cancel = Ui.Secondary("Cancel", (s, e) => { DialogResult = DialogResult.Cancel; Close(); }, 120);
            save.Left = ClientSize.Width - 270; save.Top = ClientSize.Height - 54;
            cancel.Left = ClientSize.Width - 140; cancel.Top = ClientSize.Height - 54;
            Controls.Add(save); Controls.Add(cancel);
            AcceptButton = save; CancelButton = cancel;

            if (memberId != null) Load_();
        }

        private void Load_()
        {
            var m = MemberService.Get(_memberId);
            if (m == null) { Ui.Warn("This member no longer exists."); DialogResult = DialogResult.Cancel; return; }
            _name.Text = m.FullName; _contact.Text = m.ContactNumber; _email.Text = m.Email;
            _gender.SelectedItem = string.IsNullOrEmpty(m.Gender) ? "" : m.Gender;
            if (m.BirthDate.HasValue) { _birth.Value = m.BirthDate.Value; _birth.Checked = true; }
            _address.Text = m.Address; _notes.Text = m.Notes; _status.SelectedItem = m.AccountStatus;
        }

        private void Save()
        {
            _err.Clear();
            bool ok = true;
            if (string.IsNullOrWhiteSpace(_name.Text)) { _err.SetError(_name, "Full name is required."); ok = false; }
            if (string.IsNullOrWhiteSpace(_contact.Text)) { _err.SetError(_contact, "Contact number is required."); ok = false; }
            if (!ok) return;

            var m = new Member
            {
                MemberId = _memberId,
                FullName = _name.Text, ContactNumber = _contact.Text, Email = _email.Text,
                Gender = Convert.ToString(_gender.SelectedItem), Address = _address.Text, Notes = _notes.Text,
                BirthDate = _birth.Checked ? _birth.Value.Date : (DateTime?)null,
                AccountStatus = _memberId == null ? "Active" : Convert.ToString(_status.SelectedItem),
            };

            bool saved = Ui.Run(() =>
            {
                if (_memberId == null)
                {
                    string id = MemberService.Add(m);
                    string msg = "Member saved with ID " + id + ".";
                    if (_plan.SelectedIndex > 0)
                    {
                        int planId = Db.I(_plans.Rows[_plan.SelectedIndex - 1]["PlanID"]);
                        string inv = MembershipService.Register(id, planId, _start.Value.Date, 0m, 0m, "Cash", null);
                        msg += "\nMembership registered and invoice " + inv + " created (unpaid).";
                    }
                    Ui.Info(msg);
                }
                else
                {
                    MemberService.Update(m);
                    Ui.Info("Member updated.");
                }
            });
            if (saved) { DialogResult = DialogResult.OK; Close(); }
        }
    }
}

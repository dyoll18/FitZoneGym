using FitZoneGym.Controls;
using FitZoneGym.Services;

namespace FitZoneGym.Forms
{
    /// <summary>
    /// Reusable main window: sidebar + header, with each screen loaded as a UserControl into the central panel.
    /// Menu entries are hidden when the user lacks permission, and every service re-checks the permission in code.
    /// </summary>
    public class MainForm : Form
    {
        private readonly Panel _host = new Panel { Dock = DockStyle.Fill, BackColor = Ui.Bg };
        private readonly Dictionary<string, Button> _navButtons = new Dictionary<string, Button>();
        private readonly AppUser _user = Session.Current;
        private string _current;

        private record NavItem(string Key, string Text, Func<bool> Visible, Func<ViewBase> Create);

        public MainForm()
        {
            Text = "FITZONE GYM - Membership Management System";
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(1150, 700);
            Font = Ui.Base;
            BackColor = Ui.Bg;

            var items = new List<NavItem>
            {
                new NavItem("dash", "Dashboard", () => true, () => new DashboardView(Navigate)),
                new NavItem("members", "Members", () => _user.Can(Perm.ViewMembers), () => new MembersView()),
                new NavItem("plans", "Membership Plans", () => _user.Can(Perm.ManagePlans) || _user.Can(Perm.ViewMembers), () => new PlansView()),
                new NavItem("reg", "Registration & Renewal", () => _user.Can(Perm.RegisterMembers), () => new RegistrationView()),
                new NavItem("freeze", "Freeze Management", () => _user.Can(Perm.ApproveFreeze) || _user.Can(Perm.SubmitFreeze), () => new FreezeView()),
                new NavItem("react", "Reactivation", () => _user.Can(Perm.Reactivate), () => new ReactivationView()),
                new NavItem("prorate", "Prorated Billing", () => _user.Can(Perm.RecordPayments), () => new ProratedView()),
                new NavItem("pay", "Payments", () => _user.Can(Perm.RecordPayments), () => new PaymentsView()),
                new NavItem("inv", "Invoices", () => _user.Can(Perm.ViewInvoices), () => new InvoicesView()),
                new NavItem("reports", "Reports", () => _user.Can(Perm.ViewReports), () => new ReportsView()),
                new NavItem("staff", "Users & Staff", () => _user.Can(Perm.ManageStaff), () => new StaffView()),
                new NavItem("settings", "Settings", () => _user.Can(Perm.ManageSettings), () => new SettingsView()),
                new NavItem("backup", "Database & Backup", () => _user.Can(Perm.Backup) || _user.Can(Perm.Restore), () => new BackupView(OnRestored)),
            };

            // ---- sidebar
            var sidebar = new Panel { Dock = DockStyle.Left, Width = 230, BackColor = Ui.Navy };
            var navPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, BackColor = Ui.Navy, Padding = new Padding(0, 6, 0, 0) };
            foreach (var item in items.Where(i => i.Visible()))
            {
                var b = new Button
                {
                    Text = "   " + item.Text, Width = 230, Height = 42, TextAlign = ContentAlignment.MiddleLeft,
                    FlatStyle = FlatStyle.Flat, ForeColor = Color.White, BackColor = Ui.Navy, Font = new Font("Segoe UI", 10f),
                    Margin = new Padding(0), Cursor = Cursors.Hand, UseVisualStyleBackColor = false,
                };
                b.FlatAppearance.BorderSize = 0;
                b.FlatAppearance.MouseOverBackColor = Ui.NavyLight;
                var captured = item;
                b.Click += (s, e) => ShowView(captured);
                _navButtons[item.Key] = b;
                navPanel.Controls.Add(b);
            }
            var logout = new Button
            {
                Text = "   Logout", Width = 230, Height = 46, TextAlign = ContentAlignment.MiddleLeft, FlatStyle = FlatStyle.Flat,
                ForeColor = Color.White, BackColor = Color.FromArgb(140, 30, 40), Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Dock = DockStyle.Bottom, Cursor = Cursors.Hand, UseVisualStyleBackColor = false,
            };
            logout.FlatAppearance.BorderSize = 0;
            logout.Click += (s, e) => DoLogout();

            var logo = new Label
            {
                Text = "FITZONE GYM", ForeColor = Color.White, Font = new Font("Segoe UI", 15f, FontStyle.Bold),
                Dock = DockStyle.Top, Height = 64, TextAlign = ContentAlignment.MiddleCenter, BackColor = Ui.Navy,
            };
            sidebar.Controls.Add(navPanel);   // Fill first
            sidebar.Controls.Add(logout);
            sidebar.Controls.Add(logo);

            // ---- user strip
            var strip = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = Ui.Navy };
            var who = new Label
            {
                Text = _user.FullName + "  (" + _user.Role + ")   |   " + DateTime.Today.ToString("MMM d, yyyy"),
                ForeColor = Color.White, Dock = DockStyle.Right, AutoSize = false, Width = 480, TextAlign = ContentAlignment.MiddleRight, Padding = new Padding(0, 0, 14, 0),
            };
            strip.Controls.Add(who);

            Controls.Add(_host);   // Fill first, then edge-docked controls
            Controls.Add(strip);
            Controls.Add(sidebar);

            Shown += (s, e) => ShowView(items[0]);
            _items = items;
        }

        private readonly List<NavItem> _items;

        private void Navigate(string key)
        {
            var item = _items.FirstOrDefault(i => i.Key == key && i.Visible());
            if (item != null) ShowView(item);
        }

        private void ShowView(NavItem item)
        {
            ViewBase view = null;
            if (!Ui.Run(() => view = item.Create())) return;

            foreach (Control old in _host.Controls.Cast<Control>().ToList()) { _host.Controls.Remove(old); old.Dispose(); }
            _host.Controls.Add(view);
            _current = item.Key;
            foreach (var kv in _navButtons)
            {
                kv.Value.BackColor = kv.Key == _current ? Ui.Blue : Ui.Navy;
            }
        }

        private void DoLogout()
        {
            using var dlg = new LogoutDialog();
            if (dlg.ShowDialog(this) != DialogResult.Yes) return;
            AuthService.Logout();
            DialogResult = DialogResult.Retry; // Program.cs shows the login screen again
            Close();
        }

        /// <summary>After a restore the account list may have changed, so the user must sign in again.</summary>
        private void OnRestored()
        {
            Ui.Info("The database was restored. Please sign in again.");
            AuthService.Logout();
            DialogResult = DialogResult.Retry;
            Close();
        }
    }
}

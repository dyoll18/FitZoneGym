# FITZONE GYM - Membership Management System (C# WinForms)

## Open and run
1. Install Visual Studio 2022 with the **".NET desktop development"** workload (.NET 8 SDK).
2. In Visual Studio choose File > Open > Project/Solution and pick `FitZoneGym.csproj`. NuGet restores `Microsoft.Data.Sqlite` automatically.
3. Press **F5**. The SQLite database is created on first run at `%LocalAppData%\FitZoneGym\fitzone.db`.

## Default logins (change these passwords after first sign-in)
| Role | Username | Password |
|---|---|---|
| Administrator | admin | Admin@123 |
| Staff | staff1 | Staff@123 |
| Cashier | cashier1 | Cashier@123 |

## Structure
- `Data/`      Db (ADO.NET helpers, transactions), Schema (tables, constraints, seed data), Security (PBKDF2)
- `Models/`    Member, MembershipPlan, Membership, FreezeRequest, Invoice, Payment, AppUser/Session, Perm
- `Services/`  Member, Plan, Membership (register/renew/freeze/reactivate), Billing, Payment, Report, Staff, Backup, Auth, Audit, Settings
- `Forms/`     LoginForm, MainForm (sidebar + content panel), LogoutDialog, MemberEditForm
- `Controls/`  One UserControl per screen (Dashboard, Members, Plans, Registration, Freeze, Reactivation, Prorated, Payments, Invoices, Reports, Staff, Settings, Backup)

## Policies chosen (the spec says the gym must define these)
- Term end = start + N months - 1 day (inclusive). Chargeable days count both first and last date.
- Prorated fee = round(monthly fee / 30, 2) x chargeable days (fixed 30-day basis).
- Renewal on/before (expiry + grace days) continues from the day after expiry; later renewals start on the renewal date.
- Freeze approval takes effect immediately; expiration moves by the freeze days (if "full extension" is on).
  Reactivating early gives back unused days. Rejected requests never change dates.
- Revenue = payments received in the period. Unpaid invoices are not revenue.
- Payments are separate rows; overpayment, zero/negative amounts and paid/voided invoices are rejected.
- Invoices are voided (admin, only if no payments), never deleted. Plans are deactivated, not deleted.
- Discounts above the "max discount without admin" setting require an administrator.
- No online payment gateway: payments are recorded by staff only.

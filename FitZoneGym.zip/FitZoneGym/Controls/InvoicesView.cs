using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 11 - Invoice and Billing.</summary>
    public class InvoicesView : ViewBase
    {
        private readonly TextBox _search = Ui.Input(300);
        private readonly DataGridView _list = Ui.Grid(), _items = Ui.Grid(), _payments = Ui.Grid();
        private readonly Label _head = Ui.Label("Select an invoice to see its details.", 10f, true, Ui.Navy);
        private readonly Label _totals = Ui.Label("", 10.5f, true);
        private readonly Button _print, _preview, _save, _void;
        private BillingService.InvoiceDetail _detail;

        public InvoicesView() : base("Invoice & Billing")
        {
            _search.PlaceholderText = "Invoice no., member ID or name";
            _search.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Reload(); } };
            _list.SelectionChanged += (s, e) => ShowDetail();

            _print = Ui.Primary("Print Invoice", (s, e) => Output(0), 130);
            _preview = Ui.Secondary("Print Preview", (s, e) => Output(1), 130);
            _save = Ui.Secondary("Save as Text", (s, e) => Output(2), 130);
            _void = Ui.Danger("Void Invoice", (s, e) => VoidInvoice(), 130);
            _void.Visible = Session.Current.Can(Perm.ManageSettings);
            foreach (var b in new[] { _print, _preview, _save, _void }) b.Enabled = false;

            var (listCard, listBody) = MakeCard("Invoices");
            var listLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Color.White };
            listLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            listLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            listLayout.Controls.Add(Ui.Row(_search, Ui.Primary("Search", (s, e) => Reload(), 90)), 0, 0);
            listLayout.Controls.Add(_list, 0, 1);
            listBody.Controls.Add(listLayout);

            var detail = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 6, BackColor = Color.White, Padding = new Padding(14), Margin = new Padding(0, 0, 0, 12) };
            detail.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            detail.RowStyles.Add(new RowStyle(SizeType.Percent, 40));
            detail.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            detail.RowStyles.Add(new RowStyle(SizeType.Percent, 34));
            detail.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            detail.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _head.MaximumSize = new Size(560, 0);
            detail.Controls.Add(_head, 0, 0);
            detail.Controls.Add(_items, 0, 1);
            detail.Controls.Add(Ui.Label("Payments", 10f, true, Ui.Navy), 0, 2);
            detail.Controls.Add(_payments, 0, 3);
            detail.Controls.Add(_totals, 0, 4);
            detail.Controls.Add(Ui.Row(_print, _preview, _save, _void), 0, 5);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Ui.Bg };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
            layout.Controls.Add(listCard, 0, 0);
            layout.Controls.Add(detail, 1, 0);
            Content.Controls.Add(layout);
            Reload();
        }

        private int SelectedId => _list.CurrentRow == null ? 0 : Db.I(_list.CurrentRow.Cells["InvoiceID"].Value);

        private void Reload()
        {
            int keep = SelectedId;
            Ui.Run(() =>
            {
                var t = BillingService.ListInvoices(_search.Text);
                Ui.Bind(_list, t, new[] { "InvoiceID", "MemberID", "Kind" }, new[] { "TotalDue", "Paid" }, new[] { "InvoiceDate" });
                _list.Columns["InvoiceNo"].HeaderText = "Invoice"; _list.Columns["FullName"].HeaderText = "Member";
                _list.Columns["InvoiceDate"].HeaderText = "Date"; _list.Columns["TotalDue"].HeaderText = "Total";
                if (keep != 0)
                    foreach (DataGridViewRow r in _list.Rows)
                        if (Db.I(r.Cells["InvoiceID"].Value) == keep) { _list.CurrentCell = r.Cells["InvoiceNo"]; break; }
                ShowDetail();
            });
        }

        private void ShowDetail()
        {
            _detail = null;
            foreach (var b in new[] { _print, _preview, _save, _void }) b.Enabled = false;
            _items.DataSource = null; _payments.DataSource = null; _totals.Text = "";
            if (SelectedId == 0) { _head.Text = "Select an invoice to see its details."; return; }
            Ui.Run(() =>
            {
                _detail = BillingService.GetDetail(SelectedId);
                var h = _detail.Header;
                _head.Text = "Invoice " + Db.S(h["InvoiceNo"]) + "  |  " + Db.S(h["FullName"]) + " (" + Db.S(h["MemberID"]) + ")\n" +
                             Db.S(h["Kind"]) + "  |  " + Ui.Date(Db.ToDate(h["InvoiceDate"])) + "  |  Status: " + _detail.Status();
                Ui.Bind(_items, _detail.Items, null, new[] { "UnitPrice", "Discount" });
                Ui.Bind(_payments, _detail.Payments, null, new[] { "Amount" }, new[] { "PaymentDate" });
                _totals.Text = "Total " + Ui.Money(_detail.Total) + "    Paid " + Ui.Money(_detail.Paid) + "    Balance " + Ui.Money(_detail.Balance);
                _print.Enabled = _preview.Enabled = _save.Enabled = true;
                _void.Enabled = _detail.Status() == "Unpaid";
            });
        }

        private void Output(int mode)
        {
            if (_detail == null) return;
            Ui.Run(() =>
            {
                string text = InvoicePrinter.BuildText(_detail);
                if (mode == 2)
                {
                    using var dlg = new SaveFileDialog { Filter = "Text file (*.txt)|*.txt", FileName = Db.S(_detail.Header["InvoiceNo"]) + ".txt" };
                    if (dlg.ShowDialog() == DialogResult.OK) { File.WriteAllText(dlg.FileName, text); Ui.Info("Saved to " + dlg.FileName); }
                }
                else InvoicePrinter.Print(text, mode == 1);
            });
        }

        private void VoidInvoice()
        {
            if (_detail == null) return;
            string reason = Ui.Prompt("Void invoice", "Reason for voiding invoice " + Db.S(_detail.Header["InvoiceNo"]) + " (required):");
            if (reason == null) return;
            if (Ui.Run(() => BillingService.Void(SelectedId, reason))) Reload();
        }
    }
}

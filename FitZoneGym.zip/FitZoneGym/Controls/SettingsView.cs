using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 14 - Settings (gym information and policies).</summary>
    public class SettingsView : ViewBase
    {
        private readonly TextBox _name = Ui.Input(), _address = Ui.Input(), _contact = Ui.Input(), _email = Ui.Input();
        private readonly NumericUpDown _maxFreeze = Ui.Number(1, 365, 30), _minFreeze = Ui.Number(1, 365, 1);
        private readonly NumericUpDown _notice = Ui.Number(1, 90, 7), _grace = Ui.Number(0, 90, 3);
        private readonly NumericUpDown _reactFee = Ui.Number(0, 100000, 0, 2, 140), _maxDisc = Ui.Number(0, 100, 20);
        private readonly CheckBox _fullExt = new CheckBox { Text = "Approved freezes extend the expiration date by the full freeze days", AutoSize = true };
        private readonly CheckBox _refReq = new CheckBox { Text = "Require a reference number for non-cash payments", AutoSize = true };

        public SettingsView() : base("Settings")
        {
            var save = Ui.Primary("Save Settings", (s, e) => Save(), 160); save.Height = 40;

            var gym = new FormPanel(170) { Dock = DockStyle.Top };
            gym.AddRow("Gym name", _name); gym.AddRow("Address", _address); gym.AddRow("Contact number", _contact); gym.AddRow("Email", _email);

            var pol = new FormPanel(230) { Dock = DockStyle.Top };
            pol.AddRow("Maximum freeze days", _maxFreeze);
            pol.AddRow("Minimum freeze days", _minFreeze);
            pol.AddRow("Renewal notice (days before expiry)", _notice);
            pol.AddRow("Renewal grace period (days)", _grace);
            pol.AddRow("Default reactivation fee", _reactFee);
            pol.AddRow("Max discount without admin (%)", _maxDisc);
            pol.AddRow("", _fullExt);
            pol.AddRow("", _refReq);

            var (gymCard, gymBody) = MakeCard("Gym Information");
            gymBody.Controls.Add(gym);
            var (polCard, polBody) = MakeCard("Membership & Billing Policies");
            polBody.Controls.Add(pol);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Ui.Bg };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(gymCard, 0, 0);
            layout.Controls.Add(polCard, 1, 0);
            layout.Controls.Add(Ui.Row(save), 0, 1); layout.SetColumnSpan(layout.GetControlFromPosition(0, 1), 2);
            Content.Controls.Add(layout);
            LoadValues();
        }

        private void LoadValues()
        {
            _name.Text = Settings.Get("GymName"); _address.Text = Settings.Get("GymAddress");
            _contact.Text = Settings.Get("GymContact"); _email.Text = Settings.Get("GymEmail");
            _maxFreeze.Value = Clamp(Settings.GetInt("MaxFreezeDays", 30), _maxFreeze);
            _minFreeze.Value = Clamp(Settings.GetInt("MinFreezeDays", 1), _minFreeze);
            _notice.Value = Clamp(Settings.GetInt("RenewalNoticeDays", 7), _notice);
            _grace.Value = Clamp(Settings.GetInt("GracePeriodDays", 3), _grace);
            _reactFee.Value = Math.Min(Settings.GetDecimal("ReactivationFee", 0m), _reactFee.Maximum);
            _maxDisc.Value = Math.Min(Settings.GetDecimal("MaxStaffDiscountPercent", 20m), _maxDisc.Maximum);
            _fullExt.Checked = Settings.GetBool("FullFreezeExtension", true);
            _refReq.Checked = Settings.GetBool("RequireReferenceForNonCash", true);
        }

        private static decimal Clamp(int v, NumericUpDown n) => Math.Max(n.Minimum, Math.Min(n.Maximum, v));

        private void Save()
        {
            bool ok = Ui.Run(() =>
            {
                Session.Require(Perm.ManageSettings);
                if (string.IsNullOrWhiteSpace(_name.Text)) throw new ValidationException("Gym name is required.");
                if (_minFreeze.Value > _maxFreeze.Value) throw new ValidationException("Minimum freeze days cannot exceed the maximum.");

                using var s = new DbSession(true);
                void Put(string k, string v) => Settings.Set(s, k, v);
                Put("GymName", _name.Text.Trim()); Put("GymAddress", _address.Text.Trim());
                Put("GymContact", _contact.Text.Trim()); Put("GymEmail", _email.Text.Trim());
                Put("MaxFreezeDays", ((int)_maxFreeze.Value).ToString()); Put("MinFreezeDays", ((int)_minFreeze.Value).ToString());
                Put("RenewalNoticeDays", ((int)_notice.Value).ToString()); Put("GracePeriodDays", ((int)_grace.Value).ToString());
                Put("ReactivationFee", _reactFee.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
                Put("MaxStaffDiscountPercent", _maxDisc.Value.ToString(System.Globalization.CultureInfo.InvariantCulture));
                Put("FullFreezeExtension", _fullExt.Checked ? "true" : "false");
                Put("RequireReferenceForNonCash", _refReq.Checked ? "true" : "false");
                Audit.Log(s, "Settings updated");
                s.Commit();
            });
            if (ok) Ui.Info("Settings saved.");
        }
    }
}

using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 8 - Reactivation.</summary>
    public class ReactivationView : ViewBase
    {
        private readonly MemberPicker _picker = new MemberPicker();
        private readonly Label _details = Ui.Label("Search for a member with a frozen membership.", 10f, false, Ui.Text);
        private readonly DateTimePicker _date = Ui.DatePicker();
        private readonly NumericUpDown _fee = Ui.Number(0, 1000000, 0, 2, 140);
        private readonly Label _newExp = Ui.Label("-", 10f, true, Ui.Navy);
        private readonly TextBox _notes = Ui.Input();
        private readonly Button _go;
        private MembershipService.ReactivationInfo _info;

        public ReactivationView() : base("Reactivation")
        {
            _fee.Value = Settings.GetDecimal("ReactivationFee", 0m);
            _notes.Multiline = true;
            _go = Ui.Success("Reactivate Membership", (s, e) => Submit(), 220); _go.Height = 40; _go.Enabled = false;
            _picker.MemberChanged += (s, e) => Selected();
            _date.ValueChanged += (s, e) => Recalc();

            var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(16), AutoScroll = true };
            var form = new FormPanel(190) { Dock = DockStyle.Top };
            _details.MaximumSize = new Size(760, 0);
            form.AddRow("Frozen membership", _details);
            form.AddRow("Reactivation date", _date);
            form.AddRow("New expiration date", _newExp);
            form.AddRow("Reactivation fee (optional)", _fee);
            form.AddRow("Reason / notes", _notes, 70);
            var buttons = Ui.Row(_go); buttons.Dock = DockStyle.Top; buttons.Padding = new Padding(190, 10, 0, 0);
            card.Controls.Add(buttons);   // Top docks: later-added is outermost, so add buttons first
            card.Controls.Add(form);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Ui.Bg };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.Controls.Add(Ui.Field("Member search", _picker), 0, 0);
            layout.Controls.Add(Ui.Label("Only frozen memberships with an approved freeze can be reactivated. Unused extension days are returned.", 9f, false, Ui.Muted), 0, 1);
            layout.Controls.Add(card, 0, 2);
            Content.Controls.Add(layout);
        }

        private void Selected()
        {
            _info = null; _go.Enabled = false; _newExp.Text = "-";
            string id = _picker.SelectedMemberId;
            if (id == null) { _details.Text = "Search for a member with a frozen membership."; return; }
            try
            {
                _info = MembershipService.FindReactivatable(id);
                var m = MemberService.Get(id);
                var plan = PlanService.Get(_info.Membership.PlanId);
                _details.Text = m.FullName + " (" + id + ") - " + plan.PlanName + "\nFreeze period: " + Ui.Date(_info.FreezeStart) + " to " + Ui.Date(_info.FreezeEnd) +
                                " (" + _info.ExtensionDays + " extension day(s) granted)\nCurrent expiration: " + Ui.Date(_info.Membership.ExpirationDate);
                _go.Enabled = Session.Current.Can(Perm.Reactivate);
                Recalc();
            }
            catch (ValidationException ex) { _details.Text = ex.Message; }
            catch (Exception ex) { _details.Text = "Could not load: " + ex.Message; }
        }

        private void Recalc()
        {
            if (_info == null) return;
            _newExp.Text = Ui.Date(MembershipService.NewExpirationOnReactivation(_info, _date.Value.Date));
        }

        private void Submit()
        {
            string id = _picker.SelectedMemberId;
            if (id == null || _info == null) { Ui.Warn("Select a member with a frozen membership."); return; }
            if (!Ui.Confirm("Reactivate this membership?\nNew expiration date: " + _newExp.Text)) return;
            if (!Ui.Run(() => MembershipService.Reactivate(id, _date.Value.Date, _fee.Value, _notes.Text))) return;
            Ui.Info("Membership reactivated." + (_fee.Value > 0 ? "\nA reactivation invoice for " + Ui.Money(_fee.Value) + " was created (see Payments)." : ""));
            _notes.Clear();
            _picker.Reload(id);
            Selected();
        }
    }
}

using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 15 - Database &amp; Backup (backup, restore, validation and error logs).</summary>
    public class BackupView : ViewBase
    {
        private readonly Action _onRestored;
        private readonly TextBox _backupPath = Ui.Input(420), _restorePath = Ui.Input(420);
        private readonly DataGridView _history = Ui.Grid(), _validation = Ui.Grid(), _errors = Ui.Grid();
        private readonly TabControl _tabs = new TabControl { Dock = DockStyle.Fill, Font = Ui.Base };

        public BackupView(Action onRestored) : base("Database & Backup")
        {
            _onRestored = onRestored;
            _backupPath.Text = Path.Combine(BackupService.DefaultFolder, BackupService.SuggestFileName());

            var canBackup = Session.Current.Can(Perm.Backup);
            var canRestore = Session.Current.Can(Perm.Restore);

            var t1 = new TabPage("Backup / Restore") { BackColor = Color.White, Padding = new Padding(12) };
            var browseB = Ui.Secondary("Browse...", (s, e) => BrowseBackup(), 100);
            var backupNow = Ui.Primary("Backup Now", (s, e) => DoBackup(), 140); backupNow.Enabled = canBackup;
            var browseR = Ui.Secondary("Browse...", (s, e) => BrowseRestore(), 100);
            var restore = Ui.Danger("Restore Backup", (s, e) => DoRestore(), 150); restore.Enabled = canRestore;

            var form = new FormPanel(150) { Dock = DockStyle.Top };
            form.AddRow("Database file", Ui.Label(Db.FilePath, 9f, false, Ui.Muted));
            form.AddRow("Backup file", Ui.Row(_backupPath, browseB));
            form.AddRow("", Ui.Row(backupNow));
            form.AddRow("Restore from", Ui.Row(_restorePath, browseR));
            form.AddRow("", Ui.Row(restore, Ui.Label("Restore replaces ALL current data (a safety copy is made first).", 9f, false, Ui.Red)));
            var histTitle = new Label { Text = "Backup history", Dock = DockStyle.Top, Height = 28, Font = Ui.Bold(10.5f), ForeColor = Ui.Navy };
            var holder = new Panel { Dock = DockStyle.Fill };
            holder.Controls.Add(_history);
            t1.Controls.Add(holder);
            t1.Controls.Add(histTitle);
            t1.Controls.Add(form);

            var t2 = new TabPage("Validation Logs") { BackColor = Color.White, Padding = new Padding(10) };
            t2.Controls.Add(_validation);
            var t3 = new TabPage("Error Logs") { BackColor = Color.White, Padding = new Padding(10) };
            t3.Controls.Add(_errors);
            _tabs.TabPages.AddRange(new[] { t1, t2, t3 });
            _tabs.SelectedIndexChanged += (s, e) => LoadLogs();
            Content.Controls.Add(_tabs);
            LoadLogs();
        }

        private void LoadLogs()
        {
            Ui.Run(() =>
            {
                Ui.Bind(_history, BackupService.BackupLog());
                Ui.Bind(_validation, BackupService.ErrorLog("Validation"));
                Ui.Bind(_errors, BackupService.ErrorLog("Error"));
            });
        }

        private void BrowseBackup()
        {
            using var dlg = new SaveFileDialog { Filter = "FITZONE backup (*.db)|*.db", FileName = Path.GetFileName(_backupPath.Text), InitialDirectory = BackupService.DefaultFolder };
            if (dlg.ShowDialog() == DialogResult.OK) _backupPath.Text = dlg.FileName;
        }

        private void BrowseRestore()
        {
            using var dlg = new OpenFileDialog { Filter = "FITZONE backup (*.db)|*.db|All files (*.*)|*.*", InitialDirectory = BackupService.DefaultFolder };
            if (dlg.ShowDialog() == DialogResult.OK) _restorePath.Text = dlg.FileName;
        }

        private void DoBackup()
        {
            if (Ui.Run(() => BackupService.Backup(_backupPath.Text)))
            {
                Ui.Info("Backup created:\n" + _backupPath.Text);
                _backupPath.Text = Path.Combine(BackupService.DefaultFolder, BackupService.SuggestFileName());
                LoadLogs();
            }
        }

        private void DoRestore()
        {
            if (!Ui.Run(() => BackupService.ValidateBackup(_restorePath.Text))) return;   // stop and show the problem
            if (!Ui.Confirm("Restore this backup?\n\n" + _restorePath.Text + "\n\nAll current data will be replaced. You will be signed out.")) return;
            if (Ui.Run(() => BackupService.Restore(_restorePath.Text))) _onRestored();
        }
    }
}

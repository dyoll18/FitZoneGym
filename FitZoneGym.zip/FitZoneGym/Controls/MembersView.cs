using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Forms;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 3 - Member Management.</summary>
    public class MembersView : ViewBase
    {
        private readonly TextBox _search = Ui.Input(320);
        private readonly ComboBox _filter = Ui.Combo(170, "All", "Active", "Frozen", "Expired", "Pending", "No Membership", "Inactive Accounts");
        private readonly DataGridView _grid = Ui.Grid();
        private readonly Label _count = Ui.Label("", 9.5f, false, Ui.Muted);
        private readonly Button _toggle;

        public MembersView() : base("Members")
        {
            bool canEdit = Session.Current.Can(Perm.RegisterMembers);
            if (canEdit) Actions.Controls.Add(Ui.Primary("+ Add Member", (s, e) => AddMember(), 130));
            Actions.Controls.Add(Ui.Secondary("Export CSV", (s, e) => Ui.ExportCsv(_grid, "members"), 110));

            _search.PlaceholderText = "Search by name, member ID, or contact number";
            _search.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Reload(); } };
            _filter.SelectedIndexChanged += (s, e) => Reload();

            var edit = Ui.Primary("View / Edit", (s, e) => EditSelected(), 120);
            _toggle = Ui.Secondary("Deactivate", (s, e) => ToggleSelected(), 120);
            edit.Enabled = canEdit; _toggle.Enabled = canEdit;
            _grid.SelectionChanged += (s, e) => UpdateToggleText();
            _grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && canEdit) EditSelected(); };

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Ui.Bg };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(Ui.Row(Ui.Field("Search", _search), Ui.Field("Membership status", _filter),
                                       Ui.Primary("Search", (s, e) => Reload(), 100)), 0, 0);
            layout.Controls.Add(_grid, 0, 1);
            layout.Controls.Add(Ui.Row(edit, _toggle, _count), 0, 2);
            Content.Controls.Add(layout);
            Reload();
        }

        private string SelectedId => _grid.CurrentRow == null ? null : Db.S(_grid.CurrentRow.Cells["MemberID"].Value);

        private void Reload()
        {
            string keep = SelectedId;
            Ui.Run(() =>
            {
                var t = MemberService.Search(_search.Text, Convert.ToString(_filter.SelectedItem));
                Ui.PrettyDates(t, "ExpirationDate");
                _grid.DataSource = t;
                foreach (var hide in new[] { "MembershipID", "StoredStatus", "StartDate" })
                    if (_grid.Columns.Contains(hide)) _grid.Columns[hide].Visible = false;
                Rename("MemberID", "Member ID"); Rename("FullName", "Name"); Rename("ContactNumber", "Contact");
                Rename("AccountStatus", "Account"); Rename("PlanName", "Plan"); Rename("ExpirationDate", "Expires");
                Rename("MembershipStatus", "Membership");
                _count.Text = "   Total: " + t.Rows.Count + " member(s)";
                if (keep != null)
                    foreach (DataGridViewRow r in _grid.Rows)
                        if (Db.S(r.Cells["MemberID"].Value) == keep) { _grid.CurrentCell = r.Cells[1]; break; }
                UpdateToggleText();
            });
        }

        private void Rename(string col, string header) { if (_grid.Columns.Contains(col)) _grid.Columns[col].HeaderText = header; }

        private void UpdateToggleText()
        {
            if (_grid.CurrentRow == null) return;
            _toggle.Text = Db.S(_grid.CurrentRow.Cells["AccountStatus"].Value) == "Active" ? "Deactivate" : "Activate";
        }

        private void AddMember()
        {
            using var f = new MemberEditForm();
            if (f.ShowDialog(FindForm()) == DialogResult.OK) Reload();
        }

        private void EditSelected()
        {
            if (SelectedId == null) { Ui.Info("Select a member first."); return; }
            using var f = new MemberEditForm(SelectedId);
            if (f.ShowDialog(FindForm()) == DialogResult.OK) Reload();
        }

        private void ToggleSelected()
        {
            string id = SelectedId;
            if (id == null) { Ui.Info("Select a member first."); return; }
            bool activate = _toggle.Text == "Activate";
            if (!Ui.Confirm((activate ? "Activate " : "Deactivate ") + id + "?\nMembership and billing history are kept.")) return;
            if (Ui.Run(() => MemberService.SetAccountStatus(id, activate))) Reload();
        }
    }
}

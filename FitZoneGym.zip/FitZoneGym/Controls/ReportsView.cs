using System.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 12 - Reports.</summary>
    public class ReportsView : ViewBase
    {
        private readonly ComboBox _type = Ui.Combo(240, ReportService.Types);
        private readonly DateTimePicker _from = Ui.DatePicker(new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1));
        private readonly DateTimePicker _to = Ui.DatePicker(DateTime.Today);
        private readonly DataGridView _grid = Ui.Grid();
        private readonly Label _summary = Ui.Label("Choose a report and date range, then click Generate.", 10f, true, Ui.Navy);

        public ReportsView() : base("Reports")
        {
            Actions.Controls.Add(Ui.Secondary("Export CSV", (s, e) => Ui.ExportCsv(_grid, ((string)_type.SelectedItem).Replace(' ', '_')), 110));

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Ui.Bg };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var go = Ui.Primary("Generate Report", (s, e) => Generate(), 150);
            go.Margin = new Padding(0, 18, 0, 0);
            layout.Controls.Add(Ui.Row(Ui.Field("Report type", _type), Ui.Field("From", _from), Ui.Field("To", _to), go), 0, 0);
            layout.Controls.Add(_grid, 0, 1);
            layout.Controls.Add(_summary, 0, 2);
            Content.Controls.Add(layout);
        }

        private void Generate()
        {
            Ui.Run(() =>
            {
                var r = ReportService.Generate((string)_type.SelectedItem, _from.Value.Date, _to.Value.Date);
                string[] dates = { "Date", "Start", "Expiration", "Previous Expiry", "New Expiry", "Requested", "From", "To" };
                string[] money = { "Amount", "Charged", "Paid", "Balance", "Total Due", "Fee", "Prorated", "Discount", "Fees", "Total" };
                Ui.Bind(_grid, r.Data, null, money, dates);
                _summary.Text = r.Summary + (r.Data.Rows.Count == 0 ? "   (no records in this period)" : "");
            });
        }
    }
}

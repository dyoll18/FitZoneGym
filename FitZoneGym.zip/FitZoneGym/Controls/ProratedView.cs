using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 9 - Prorated Billing and Fee Calculation.</summary>
    public class ProratedView : ViewBase
    {
        private readonly MemberPicker _picker = new MemberPicker();
        private readonly ComboBox _plan = Ui.Combo(260);
        private readonly DateTimePicker _from = Ui.DatePicker(DateTime.Today), _to = Ui.DatePicker(DateTime.Today.AddDays(9));
        private readonly NumericUpDown _disc = Ui.Number(0, 100, 0, 0, 90);
        private readonly NumericUpDown _extra = Ui.Number(0, 1000000, 0, 2, 140);
        private readonly Label _rMonthly = Value(), _rDaily = Value(), _rDays = Value(), _rProrated = Value(), _rDisc = Value(), _rExtra = Value(), _rTotal = Value(true);
        private readonly Button _create;
        private readonly DataTable _plans = PlanService.List(true);
        private ProratedResult _last;

        private static Label Value(bool big = false) => Ui.Label("-", big ? 14f : 10.5f, true, big ? Ui.Blue : Ui.Text);

        public ProratedView() : base("Prorated Billing")
        {
            foreach (DataRow r in _plans.Rows)
                _plan.Items.Add(Db.S(r["PlanName"]) + "  (" + Ui.Money(Db.ToDec(r["Fee"])) + " / " + Db.I(r["DurationMonths"]) + " mo)");
            if (_plan.Items.Count > 0) _plan.SelectedIndex = 0;

            _picker.MemberChanged += (s, e) => SelectCurrentPlan();
            foreach (Control c in new Control[] { _plan, _from, _to, _disc, _extra })
            {
                if (c is ComboBox cb) cb.SelectedIndexChanged += (s, e) => Reset();
                else if (c is DateTimePicker dp) dp.ValueChanged += (s, e) => Reset();
                else if (c is NumericUpDown nd) nd.ValueChanged += (s, e) => Reset();
            }

            var calc = Ui.Primary("Calculate", (s, e) => Calculate(), 140); calc.Height = 40;
            _create = Ui.Success("Create Invoice", (s, e) => CreateInvoice(), 160); _create.Height = 40; _create.Enabled = false;

            var left = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(16), Margin = new Padding(0, 0, 12, 0), AutoScroll = true };
            var form = new FormPanel(150) { Dock = DockStyle.Top };
            form.AddRow("Billing from", _from);
            form.AddRow("Billing to", _to);
            form.AddRow("Plan (monthly basis)", _plan);
            form.AddRow("Discount (%)", _disc);
            form.AddRow("Additional fees", _extra);
            var buttons = Ui.Row(calc, _create); buttons.Dock = DockStyle.Top; buttons.Padding = new Padding(0, 12, 0, 0);
            left.Controls.Add(buttons);
            left.Controls.Add(form);

            var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(16), AutoScroll = true };
            var res = new FormPanel(170) { Dock = DockStyle.Top };
            res.AddRow("Monthly fee", _rMonthly);
            res.AddRow("Daily rate (fee ÷ 30)", _rDaily);
            res.AddRow("Chargeable days", _rDays);
            res.AddRow("Prorated amount", _rProrated);
            res.AddRow("Discount", _rDisc);
            res.AddRow("Additional fees", _rExtra);
            res.AddRow("TOTAL", _rTotal);
            var rules = Ui.Label("Rules: daily rate = monthly fee ÷ 30 (rounded to 2 decimals); chargeable days count both the first and last date; " +
                                 "prorated fee = daily rate × chargeable days. The displayed result is exactly what is saved on the invoice.", 9f, false, Ui.Muted);
            rules.MaximumSize = new Size(420, 0); rules.Dock = DockStyle.Top;
            right.Controls.Add(rules);
            right.Controls.Add(res);
            var title = new Label { Text = "Calculation Result", Dock = DockStyle.Top, Height = 28, Font = Ui.Bold(11f), ForeColor = Ui.Navy };
            right.Controls.Add(title);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Ui.Bg };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var pick = Ui.Field("Member (needed to create an invoice)", _picker);
            layout.Controls.Add(pick, 0, 0); layout.SetColumnSpan(pick, 2);
            layout.Controls.Add(left, 0, 1);
            layout.Controls.Add(right, 1, 1);
            Content.Controls.Add(layout);
        }

        private void SelectCurrentPlan()
        {
            string id = _picker.SelectedMemberId;
            if (id == null) return;
            var cur = MembershipService.Latest(id);
            if (cur == null) return;
            for (int i = 0; i < _plans.Rows.Count; i++)
                if (Db.I(_plans.Rows[i]["PlanID"]) == cur.PlanId) { _plan.SelectedIndex = i; break; }
        }

        private void Reset()
        {
            _last = null; _create.Enabled = false;
            foreach (var l in new[] { _rMonthly, _rDaily, _rDays, _rProrated, _rDisc, _rExtra, _rTotal }) l.Text = "-";
        }

        private MembershipPlan Plan() => _plan.SelectedIndex < 0 ? null : PlanService.FromRow(_plans.Rows[_plan.SelectedIndex]);

        private void Calculate()
        {
            var plan = Plan();
            if (plan == null) { Ui.Warn("Select a plan."); return; }
            ProratedResult r = null;
            if (!Ui.Run(() => r = BillingService.Calculate(plan.MonthlyEquivalent, _from.Value.Date, _to.Value.Date, _disc.Value, _extra.Value))) return;
            _last = r;
            _rMonthly.Text = Ui.Money(r.MonthlyFee); _rDaily.Text = Ui.Money(r.DailyRate);
            _rDays.Text = r.ChargeableDays + " day(s)"; _rProrated.Text = Ui.Money(r.ProratedAmount);
            _rDisc.Text = "-" + Ui.Money(r.Discount); _rExtra.Text = Ui.Money(r.AdditionalFees); _rTotal.Text = Ui.Money(r.Total);
            _create.Enabled = Session.Current.Can(Perm.RecordPayments);
        }

        private void CreateInvoice()
        {
            if (_last == null) { Ui.Warn("Calculate first."); return; }
            string id = _picker.SelectedMemberId;
            if (id == null) { Ui.Warn("Select the member to bill."); return; }
            var plan = Plan();
            if (!Ui.Confirm("Create an invoice for " + Ui.Money(_last.Total) + " for member " + id + "?")) return;
            string no = null;
            if (!Ui.Run(() => no = BillingService.CreateProratedInvoice(id, plan.MonthlyEquivalent, _from.Value.Date, _to.Value.Date, _disc.Value, _extra.Value, plan.PlanName))) return;
            Ui.Info("Invoice " + no + " created. Record payments on the Payments screen.");
            Reset();
        }
    }
}

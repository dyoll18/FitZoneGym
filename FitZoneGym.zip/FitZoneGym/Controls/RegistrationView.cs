using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 6 - Registration &amp; Renewal.</summary>
    public class RegistrationView : ViewBase
    {
        private readonly MemberPicker _picker = new MemberPicker();
        private readonly RadioButton _rbNew = new RadioButton { Text = "New Registration", Appearance = Appearance.Button, AutoSize = false, Width = 160, Height = 32, TextAlign = ContentAlignment.MiddleCenter, FlatStyle = FlatStyle.Flat };
        private readonly RadioButton _rbRenew = new RadioButton { Text = "Renew Membership", Appearance = Appearance.Button, AutoSize = false, Width = 160, Height = 32, TextAlign = ContentAlignment.MiddleCenter, FlatStyle = FlatStyle.Flat };
        private readonly ComboBox _plan = Ui.Combo(260);
        private readonly DateTimePicker _date = Ui.DatePicker();
        private readonly NumericUpDown _disc = Ui.Number(0, 100, 0, 0, 90);
        private readonly NumericUpDown _pay = Ui.Number(0, 10000000, 0, 2, 140);
        private readonly ComboBox _method = Ui.Combo(160, PaymentService.Methods);
        private readonly TextBox _ref = Ui.Input(160);
        private readonly Label _dateLabel = Ui.Label("Start date");
        private readonly Label _info = Ui.Label("Search and select a member to begin.", 9.5f, false, Ui.Muted);
        private readonly Label _summary = Ui.Label("", 10f, true, Ui.Navy);
        private readonly DataGridView _history = Ui.Grid();
        private readonly Button _go;
        private DataTable _plans;
        private readonly bool _canPay = Session.Current.Can(Perm.RecordPayments);

        public RegistrationView() : base("Registration & Renewal")
        {
            _plans = PlanService.List(true);
            foreach (DataRow r in _plans.Rows)
                _plan.Items.Add(Db.S(r["PlanName"]) + " (" + Db.I(r["DurationMonths"]) + " mo, " + Ui.Money(Db.ToDec(r["Fee"])) + ")");
            if (_plan.Items.Count > 0) _plan.SelectedIndex = 0;

            _rbNew.Checked = true;
            foreach (var rb in new[] { _rbNew, _rbRenew })
            {
                rb.FlatAppearance.BorderColor = Ui.Border;
                rb.CheckedChanged += (s, e) => ModeChanged();
            }
            _picker.MemberChanged += (s, e) => MemberChanged();
            _plan.SelectedIndexChanged += (s, e) => Preview();
            _date.ValueChanged += (s, e) => Preview();
            _disc.ValueChanged += (s, e) => Preview();
            _go = Ui.Success("Register Membership", (s, e) => Submit(), 220); _go.Height = 40;

            var form = new FormPanel(150) { Dock = DockStyle.Top };
            form.AddRow("Plan", _plan);
            form.AddRow("Date", Ui.Row(_date, _dateLabel));
            form.AddRow("Discount (%)", _disc);
            if (_canPay)
            {
                form.AddRow("Initial payment", _pay);
                form.AddRow("Payment method", _method);
                form.AddRow("Reference no.", _ref);
            }
            form.AddRow("", _summary);

            var left = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(14), AutoScroll = true };
            left.Controls.Add(Ui.Row(_go));
            left.Controls[0].Dock = DockStyle.Bottom;
            left.Controls.Add(form);

            var (rightCard, rightBody) = MakeCard("Renewal History");
            rightBody.Controls.Add(_history);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3, BackColor = Ui.Bg };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var top = Ui.Row(_rbNew, _rbRenew); top.Margin = new Padding(0, 0, 0, 8);
            layout.Controls.Add(top, 0, 0); layout.SetColumnSpan(top, 2);
            var pickerRow = Ui.Row(Ui.Field("Member search", _picker)); pickerRow.Margin = new Padding(0, 0, 0, 6);
            layout.Controls.Add(pickerRow, 0, 1); layout.SetColumnSpan(pickerRow, 2);
            var leftHost = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 12, 12) };
            leftHost.Controls.Add(left);
            var infoPanel = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.White, Padding = new Padding(14, 8, 14, 4) };
            infoPanel.Controls.Add(_info);
            _info.MaximumSize = new Size(420, 0);
            var rightHost = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Ui.Bg, Margin = new Padding(0) };
            rightHost.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
            rightHost.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            rightHost.Controls.Add(infoPanel, 0, 0);
            rightHost.Controls.Add(rightCard, 0, 1);
            layout.Controls.Add(leftHost, 0, 2);
            layout.Controls.Add(rightHost, 1, 2);
            Content.Controls.Add(layout);

            if (_plan.Items.Count == 0) Ui.Warn("There are no active membership plans. Add a plan first.");
            ModeChanged();
        }

        private bool IsRenew => _rbRenew.Checked;

        private void ModeChanged()
        {
            _rbNew.BackColor = _rbNew.Checked ? Ui.Blue : Color.White; _rbNew.ForeColor = _rbNew.Checked ? Color.White : Ui.Text;
            _rbRenew.BackColor = _rbRenew.Checked ? Ui.Blue : Color.White; _rbRenew.ForeColor = _rbRenew.Checked ? Color.White : Ui.Text;
            _go.Text = IsRenew ? "Process Renewal" : "Register Membership";
            _dateLabel.Text = IsRenew ? "(renewal date)" : "(start date)";
            Preview();
        }

        private void MemberChanged()
        {
            string id = _picker.SelectedMemberId;
            _history.DataSource = null;
            if (id == null) { _info.Text = "Search and select a member to begin."; _summary.Text = ""; return; }

            Ui.Run(() =>
            {
                var cur = MembershipService.Latest(id);
                if (cur == null)
                {
                    _info.Text = "No membership yet - use New Registration.";
                    _rbNew.Checked = true;
                }
                else
                {
                    var plan = PlanService.Get(cur.PlanId);
                    _info.Text = "Current plan: " + plan.PlanName + "   |   Status: " + cur.State + "\nExpiration: " + Ui.Date(cur.ExpirationDate);
                    _rbRenew.Checked = true;
                }
                var hist = MembershipService.RenewalHistory(id);
                Ui.Bind(_history, hist, null, new[] { "Charged", "Paid" }, new[] { "TransactionDate", "PreviousExpiration", "NewExpiration" });
                Preview();
            });
        }

        private int SelectedPlanId => _plan.SelectedIndex < 0 ? 0 : Db.I(_plans.Rows[_plan.SelectedIndex]["PlanID"]);

        private void Preview()
        {
            if (_plan.SelectedIndex < 0) { _summary.Text = ""; return; }
            try
            {
                var plan = PlanService.FromRow(_plans.Rows[_plan.SelectedIndex]);
                DateTime start, exp;
                string note = "";
                if (IsRenew && _picker.SelectedMemberId != null)
                {
                    var p = MembershipService.PreviewRenewal(_picker.SelectedMemberId, plan.PlanId, _date.Value.Date);
                    start = p.NewStart; exp = p.NewExpiration;
                    note = p.ExtendsFromPrevious ? "continues from previous expiry" : "starts on renewal date (grace period passed)";
                }
                else
                {
                    start = _date.Value.Date; exp = Membership.CalcExpiration(start, plan.DurationMonths);
                }
                decimal disc = BillingService.DiscountAmount(plan.Fee, _disc.Value);
                _summary.Text = "Term: " + Ui.Date(start) + " to " + Ui.Date(exp) + (note == "" ? "" : "  (" + note + ")") +
                                "\nFee " + Ui.Money(plan.Fee) + "  -  Discount " + Ui.Money(disc) + "  =  Total " + Ui.Money(plan.Fee - disc);
            }
            catch (Exception ex) { _summary.Text = ex.Message; }
        }

        private void Submit()
        {
            string id = _picker.SelectedMemberId;
            if (id == null) { Ui.Warn("Search for and select a member first."); return; }
            if (SelectedPlanId == 0) { Ui.Warn("Select a membership plan."); return; }

            decimal pay = _canPay ? _pay.Value : 0m;
            string method = Convert.ToString(_method.SelectedItem), reference = _ref.Text;
            string invoiceNo = null;
            bool ok = Ui.Run(() =>
            {
                invoiceNo = IsRenew
                    ? MembershipService.Renew(id, SelectedPlanId, _date.Value.Date, _disc.Value, pay, method, reference)
                    : MembershipService.Register(id, SelectedPlanId, _date.Value.Date, _disc.Value, pay, method, reference);
            });
            if (!ok) return;

            Ui.Info((IsRenew ? "Membership renewed." : "Membership registered.") + "\nInvoice " + invoiceNo + " was created" +
                    (pay > 0m ? " with an initial payment of " + Ui.Money(pay) + "." : " (unpaid)."));
            _pay.Value = 0; _ref.Clear();
            _picker.Reload(id);
            MemberChanged();
        }
    }
}

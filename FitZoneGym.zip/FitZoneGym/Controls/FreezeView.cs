using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 7 - Freeze Management (review, approve and reject; new requests via dialog).</summary>
    public class FreezeView : ViewBase
    {
        private static readonly string[] Tabs = { "Pending", "Approved", "Completed", "Rejected" };
        private readonly RadioButton[] _tabs = new RadioButton[4];
        private readonly DataGridView _grid = Ui.Grid();
        private readonly Button _approve, _reject;
        private string _status = "Pending";

        public FreezeView() : base("Freeze Management")
        {
            if (Session.Current.Can(Perm.SubmitFreeze))
                Actions.Controls.Add(Ui.Primary("+ New Freeze Request", (s, e) => NewRequest(), 180));

            var tabRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, BackColor = Ui.Bg, Margin = new Padding(0, 0, 0, 8) };
            for (int i = 0; i < Tabs.Length; i++)
            {
                var rb = new RadioButton { Appearance = Appearance.Button, AutoSize = false, Width = 140, Height = 32, TextAlign = ContentAlignment.MiddleCenter, FlatStyle = FlatStyle.Flat, Tag = Tabs[i] };
                rb.FlatAppearance.BorderColor = Ui.Border;
                rb.CheckedChanged += (s, e) =>
                {
                    var b = (RadioButton)s;
                    b.BackColor = b.Checked ? Ui.Blue : Color.White; b.ForeColor = b.Checked ? Color.White : Ui.Text;
                    if (b.Checked) { _status = (string)b.Tag; Reload(); }
                };
                _tabs[i] = rb;
                tabRow.Controls.Add(rb);
            }

            bool canDecide = Session.Current.Can(Perm.ApproveFreeze);
            _approve = Ui.Success("Approve", (s, e) => Decide(true), 110);
            _reject = Ui.Danger("Reject", (s, e) => Decide(false), 110);
            _approve.Enabled = canDecide; _reject.Enabled = canDecide;
            var note = Ui.Label(canDecide
                ? "Approval takes effect immediately: the membership becomes Frozen and the expiration date moves by the freeze days (policy)."
                : "Only authorized users can approve or reject requests.", 9f, false, Ui.Muted);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Ui.Bg };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(tabRow, 0, 0);
            layout.Controls.Add(_grid, 0, 1);
            layout.Controls.Add(Ui.Row(_approve, _reject, note), 0, 2);
            Content.Controls.Add(layout);

            _tabs[0].Checked = true;
            UpdateButtons();
            _grid.SelectionChanged += (s, e) => UpdateButtons();
        }

        private void UpdateButtons()
        {
            bool pending = _status == "Pending" && _grid.CurrentRow != null && Session.Current.Can(Perm.ApproveFreeze);
            _approve.Visible = _reject.Visible = pending;
        }

        private void Reload()
        {
            Ui.Run(() =>
            {
                for (int i = 0; i < Tabs.Length; i++)
                    _tabs[i].Text = Tabs[i] + " (" + MembershipService.FreezeList(Tabs[i]).Rows.Count + ")";
                var t = MembershipService.FreezeList(_status);
                Ui.Bind(_grid, t, new[] { "FreezeID" }, null, new[] { "RequestDate", "StartDate", "EndDate" });
                _grid.Columns["MemberID"].HeaderText = "Member ID"; _grid.Columns["FullName"].HeaderText = "Name";
                _grid.Columns["RequestDate"].HeaderText = "Requested"; _grid.Columns["StartDate"].HeaderText = "From"; _grid.Columns["EndDate"].HeaderText = "To";
                UpdateButtons();
            });
        }

        private int SelectedId => _grid.CurrentRow == null ? 0 : Db.I(_grid.CurrentRow.Cells["FreezeID"].Value);

        private void Decide(bool approve)
        {
            int id = SelectedId;
            if (id == 0) { Ui.Info("Select a request first."); return; }
            if (approve)
            {
                if (!Ui.Confirm("Approve this freeze request?\nThe membership will be frozen and its expiration date adjusted per policy.")) return;
                if (Ui.Run(() => MembershipService.ApproveFreeze(id, null))) Reload();
            }
            else
            {
                string reason = Ui.Prompt("Reject freeze request", "Reason for rejecting (required):");
                if (reason == null) return;
                if (Ui.Run(() => MembershipService.RejectFreeze(id, reason))) Reload();
            }
        }

        private void NewRequest()
        {
            using var f = new FreezeRequestForm();
            if (f.ShowDialog(FindForm()) == DialogResult.OK) { _tabs[0].Checked = true; Reload(); }
        }
    }

    public class FreezeRequestForm : Form
    {
        private readonly MemberPicker _picker = new MemberPicker();
        private readonly Label _info = Ui.Label("Search and select a member.", 9.5f, false, Ui.Muted);
        private readonly DateTimePicker _from = Ui.DatePicker(DateTime.Today), _to = Ui.DatePicker(DateTime.Today.AddDays(9));
        private readonly TextBox _reason = Ui.Input();
        private Membership _ms;

        public FreezeRequestForm()
        {
            Text = "New Freeze Request";
            ClientSize = new Size(720, 400);
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent; BackColor = Color.White; Font = Ui.Base;

            _reason.Multiline = true;
            var pick = Ui.Field("Member", _picker); pick.Left = 20; pick.Top = 14;
            _picker.MemberChanged += (s, e) => Selected();
            _info.Left = 20; _info.Top = 78; _info.MaximumSize = new Size(680, 0);

            var form = new FormPanel(140) { Left = 20, Top = 120, Width = 680 };
            form.AddRow("Freeze from", _from);
            form.AddRow("Freeze to", _to);
            form.AddRow("Reason *", _reason, 70);
            Controls.AddRange(new Control[] { pick, _info, form });

            var save = Ui.Primary("Submit Request", (s, e) => Save(), 140); save.Left = 420; save.Top = 346;
            var cancel = Ui.Secondary("Cancel", (s, e) => { DialogResult = DialogResult.Cancel; Close(); }, 120); cancel.Left = 570; cancel.Top = 346;
            Controls.Add(save); Controls.Add(cancel);
            AcceptButton = save; CancelButton = cancel;
        }

        private void Selected()
        {
            _ms = null;
            string id = _picker.SelectedMemberId;
            if (id == null) { _info.Text = "Search and select a member."; return; }
            _ms = MembershipService.Latest(id);
            if (_ms == null) { _info.Text = "This member has no membership."; return; }
            int max = Services.Settings.GetInt("MaxFreezeDays", 30);
            _info.Text = "Membership status: " + _ms.State + "  |  Expires: " + Ui.Date(_ms.ExpirationDate) +
                         "\nPolicy: maximum freeze " + max + " days; only active memberships can be frozen.";
        }

        private void Save()
        {
            if (_ms == null) { Ui.Warn("Select a member with a membership first."); return; }
            if (Ui.Run(() => MembershipService.RequestFreeze(_ms.MembershipId, _from.Value.Date, _to.Value.Date, _reason.Text)))
            {
                Ui.Info("Freeze request submitted and is now Pending.");
                DialogResult = DialogResult.OK; Close();
            }
        }
    }
}

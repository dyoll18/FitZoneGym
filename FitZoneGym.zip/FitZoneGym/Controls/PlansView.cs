using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 5 - Membership Plan Management (with its add/edit dialog).</summary>
    public class PlansView : ViewBase
    {
        private readonly DataGridView _grid = Ui.Grid();
        private readonly Button _toggle;
        private readonly bool _canManage = Session.Current.Can(Perm.ManagePlans);

        public PlansView() : base("Membership Plans")
        {
            if (_canManage) Actions.Controls.Add(Ui.Primary("+ Add Plan", (s, e) => Edit(null), 120));

            var edit = Ui.Primary("Edit", (s, e) => Edit(Selected()), 100);
            _toggle = Ui.Secondary("Deactivate", (s, e) => Toggle(), 120);
            edit.Enabled = _canManage; _toggle.Enabled = _canManage;
            _grid.SelectionChanged += (s, e) => { if (_grid.CurrentRow != null) _toggle.Text = Db.S(_grid.CurrentRow.Cells["Status"].Value) == "Active" ? "Deactivate" : "Activate"; };
            _grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0 && _canManage) Edit(Selected()); };

            var note = Ui.Label("Plans used by existing memberships are deactivated rather than deleted, so history stays intact.", 9f, false, Ui.Muted);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Ui.Bg };
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(_grid, 0, 0);
            layout.Controls.Add(Ui.Row(edit, _toggle, note), 0, 1);
            Content.Controls.Add(layout);
            Reload();
        }

        private void Reload()
        {
            Ui.Run(() =>
            {
                var t = PlanService.List(false);
                t.Columns.Add("Status", typeof(string));
                foreach (DataRow r in t.Rows) r["Status"] = Db.I(r["IsActive"]) == 1 ? "Active" : "Inactive";
                _grid.DataSource = t;
                foreach (var h in new[] { "PlanID", "IsActive" }) _grid.Columns[h].Visible = false;
                _grid.Columns["PlanName"].HeaderText = "Plan Name";
                _grid.Columns["DurationMonths"].HeaderText = "Duration (months)";
                _grid.Columns["Fee"].DefaultCellStyle.Format = Ui.MoneyFormat;
                _grid.Columns["Fee"].HeaderText = "Fee";
            });
        }

        private MembershipPlan Selected() => _grid.CurrentRow == null ? null : PlanService.Get(Db.I(_grid.CurrentRow.Cells["PlanID"].Value));

        private void Edit(MembershipPlan plan)
        {
            if (plan == null && _grid.CurrentRow != null) { /* adding */ }
            using var f = new PlanEditForm(plan);
            if (f.ShowDialog(FindForm()) == DialogResult.OK) Reload();
        }

        private void Toggle()
        {
            var p = Selected();
            if (p == null) { Ui.Info("Select a plan first."); return; }
            if (Ui.Run(() => PlanService.SetActive(p.PlanId, !p.IsActive))) Reload();
        }
    }

    public class PlanEditForm : Form
    {
        private readonly MembershipPlan _plan;
        private readonly TextBox _name = Ui.Input(), _desc = Ui.Input();
        private readonly NumericUpDown _months = Ui.Number(1, 60, 1);
        private readonly NumericUpDown _fee = Ui.Number(0, 1000000, 0, 2, 160);

        public PlanEditForm(MembershipPlan plan)
        {
            _plan = plan ?? new MembershipPlan();
            Text = plan == null ? "Add Plan" : "Edit Plan";
            ClientSize = new Size(460, 270);
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent; BackColor = Color.White; Font = Ui.Base;

            _desc.Multiline = true;
            var form = new FormPanel(130) { Left = 20, Top = 16, Width = 420 };
            form.AddRow("Plan name *", _name);
            form.AddRow("Duration (months) *", _months);
            form.AddRow("Fee *", _fee);
            form.AddRow("Description", _desc, 60);
            Controls.Add(form);

            if (plan != null) { _name.Text = plan.PlanName; _months.Value = plan.DurationMonths; _fee.Value = plan.Fee; _desc.Text = plan.Description; }

            var save = Ui.Primary("Save", (s, e) => Save(), 110); save.Left = 220; save.Top = 216;
            var cancel = Ui.Secondary("Cancel", (s, e) => { DialogResult = DialogResult.Cancel; Close(); }, 110); cancel.Left = 340; cancel.Top = 216;
            Controls.Add(save); Controls.Add(cancel);
            AcceptButton = save; CancelButton = cancel;
        }

        private void Save()
        {
            _plan.PlanName = _name.Text; _plan.DurationMonths = (int)_months.Value; _plan.Fee = _fee.Value; _plan.Description = _desc.Text;
            if (Ui.Run(() => PlanService.Save(_plan))) { DialogResult = DialogResult.OK; Close(); }
        }
    }
}

using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 10 - Payment Management.</summary>
    public class PaymentsView : ViewBase
    {
        private readonly MemberPicker _picker = new MemberPicker();
        private readonly ComboBox _invoice = Ui.Combo(420);
        private readonly Label _prev = Ui.Label("-", 10.5f, true), _total = Ui.Label("-", 10.5f, true), _after = Ui.Label("-", 10.5f, true, Ui.Blue);
        private readonly NumericUpDown _amount = Ui.Number(0, 10000000, 0, 2, 160);
        private readonly ComboBox _method = Ui.Combo(180, PaymentService.Methods);
        private readonly DateTimePicker _date = Ui.DatePicker();
        private readonly TextBox _ref = Ui.Input(220);
        private readonly DataGridView _history = Ui.Grid();
        private readonly Button _pay;
        private DataTable _open = new DataTable();
        private bool _busy;

        public PaymentsView() : base("Payments")
        {
            _picker.MemberChanged += (s, e) => LoadInvoices();
            _invoice.SelectedIndexChanged += (s, e) => ShowInvoice();
            _amount.ValueChanged += (s, e) => UpdateAfter();
            _pay = Ui.Success("Process Payment", (s, e) => Process(), 200); _pay.Height = 40; _pay.Enabled = false;

            var form = new FormPanel(150) { Dock = DockStyle.Top };
            form.AddRow("Invoice", _invoice);
            form.AddRow("Total amount", _total);
            form.AddRow("Previous balance", _prev);
            form.AddRow("Payment amount", _amount);
            form.AddRow("Payment method", _method);
            form.AddRow("Payment date", _date);
            form.AddRow("Reference no.", _ref);
            form.AddRow("Remaining balance", _after);
            var buttons = Ui.Row(_pay); buttons.Dock = DockStyle.Top; buttons.Padding = new Padding(0, 12, 0, 0);
            var left = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(16), Margin = new Padding(0, 0, 12, 0), AutoScroll = true };
            left.Controls.Add(buttons);
            left.Controls.Add(form);

            var (histCard, histBody) = MakeCard("Payment History (selected invoice)");
            histBody.Controls.Add(_history);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2, BackColor = Ui.Bg };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var pick = Ui.Field("Member search", _picker);
            layout.Controls.Add(pick, 0, 0); layout.SetColumnSpan(pick, 2);
            layout.Controls.Add(left, 0, 1);
            layout.Controls.Add(histCard, 1, 1);
            Content.Controls.Add(layout);
        }

        private void LoadInvoices()
        {
            _invoice.Items.Clear(); _open = new DataTable(); _history.DataSource = null; ShowInvoice();
            string id = _picker.SelectedMemberId;
            if (id == null) return;
            Ui.Run(() =>
            {
                _open = PaymentService.OpenInvoices(id);
                foreach (DataRow r in _open.Rows)
                {
                    decimal bal = Db.ToDec(r["TotalDue"]) - Db.ToDec(r["Paid"]);
                    _invoice.Items.Add(Db.S(r["InvoiceNo"]) + "  -  balance " + Ui.Money(bal) + "  (" + Db.S(r["Status"]) + ")");
                }
                if (_open.Rows.Count > 0) _invoice.SelectedIndex = 0;
                else Ui.Info("This member has no unpaid invoices.");
            });
        }

        private DataRow Current => _invoice.SelectedIndex < 0 || _invoice.SelectedIndex >= _open.Rows.Count ? null : _open.Rows[_invoice.SelectedIndex];
        private decimal Balance => Current == null ? 0m : Db.ToDec(Current["TotalDue"]) - Db.ToDec(Current["Paid"]);

        private void ShowInvoice()
        {
            var r = Current;
            _pay.Enabled = r != null;
            if (r == null) { _total.Text = _prev.Text = _after.Text = "-"; _history.DataSource = null; return; }
            _total.Text = Ui.Money(Db.ToDec(r["TotalDue"]));
            _prev.Text = Ui.Money(Balance);
            _amount.Value = Math.Min(Balance, _amount.Maximum);
            Ui.Run(() => Ui.Bind(_history, PaymentService.History(Db.I(r["InvoiceID"])), new[] { "PaymentID" }, new[] { "Amount" }, new[] { "PaymentDate" }));
            UpdateAfter();
        }

        private void UpdateAfter()
        {
            if (Current == null) return;
            decimal after = Balance - _amount.Value;
            _after.Text = after < 0 ? "Exceeds balance!" : Ui.Money(after);
            _after.ForeColor = after < 0 ? Ui.Red : Ui.Blue;
        }

        private void Process()
        {
            if (_busy) return;      // guards against double-clicks / duplicate submissions
            var r = Current;
            if (r == null) { Ui.Warn("Select an invoice."); return; }
            var p = new Payment { InvoiceId = Db.I(r["InvoiceID"]), Amount = _amount.Value, Method = Convert.ToString(_method.SelectedItem), PaymentDate = _date.Value.Date, ReferenceNumber = _ref.Text };
            if (!Ui.Confirm("Record a " + Ui.Money(p.Amount) + " payment (" + p.Method + ") for invoice " + Db.S(r["InvoiceNo"]) + "?")) return;

            _busy = true; _pay.Enabled = false;
            try
            {
                decimal remaining = 0m;
                if (!Ui.Run(() => remaining = PaymentService.Record(p))) return;
                Ui.Info(remaining == 0m ? "Payment recorded. The invoice is now PAID in full." : "Payment recorded. Remaining balance: " + Ui.Money(remaining));
                _ref.Clear();
                string memberId = _picker.SelectedMemberId;
                LoadInvoices();
            }
            finally { _busy = false; _pay.Enabled = Current != null; }
        }
    }
}

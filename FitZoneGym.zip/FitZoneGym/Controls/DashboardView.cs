using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Simple GDI+ donut chart (no external chart library needed).</summary>
    public class DonutChart : Control
    {
        public int Total { get; set; }
        public (string Label, int Value, Color Color)[] Slices { get; set; } = Array.Empty<(string, int, Color)>();

        public DonutChart() { DoubleBuffered = true; BackColor = Color.White; }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int size = Math.Min(Width, Height) - 20;
            if (size < 40) return;
            var rect = new Rectangle(10, (Height - size) / 2, size, size);
            int sum = Slices.Sum(s => s.Value);
            float start = -90f;
            using (var track = new Pen(Color.FromArgb(230, 234, 242), 22))
                g.DrawEllipse(track, rect.X + 11, rect.Y + 11, rect.Width - 22, rect.Height - 22);
            if (sum > 0)
                foreach (var s in Slices)
                {
                    if (s.Value <= 0) continue;
                    float sweep = 360f * s.Value / sum;
                    using var pen = new Pen(s.Color, 22);
                    g.DrawArc(pen, rect.X + 11, rect.Y + 11, rect.Width - 22, rect.Height - 22, start, Math.Max(sweep - 1.5f, 0.5f));
                    start += sweep;
                }
            using var big = new Font("Segoe UI", 20f, FontStyle.Bold);
            using var small = new Font("Segoe UI", 8.5f);
            var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            g.DrawString(Total.ToString(), big, new SolidBrush(Ui.Navy), new RectangleF(rect.X, rect.Y + rect.Height / 2f - 20, rect.Width, 30), sf);
            g.DrawString("Total Members", small, new SolidBrush(Ui.Muted), new RectangleF(rect.X, rect.Y + rect.Height / 2f + 8, rect.Width, 20), sf);

            // legend
            int lx = rect.Right + 20, ly = rect.Y + 20;
            foreach (var s in Slices)
            {
                using (var br = new SolidBrush(s.Color)) g.FillEllipse(br, lx, ly + 3, 10, 10);
                g.DrawString(s.Label + ": " + s.Value + (Total > 0 ? " (" + (100 * s.Value / Total) + "%)" : ""), Font, new SolidBrush(Ui.Text), lx + 16, ly);
                ly += 26;
            }
        }
    }

    /// <summary>Screen 2 - Dashboard.</summary>
    public class DashboardView : ViewBase
    {
        public DashboardView(Action<string> navigate) : base("Dashboard")
        {
            var members = MemberService.Lookup("");
            int total = 0, active = 0, frozen = 0, expired = 0;
            foreach (DataRow r in members.Rows)
            {
                if (Db.S(r["AccountStatus"]) != "Active") continue;
                total++;
                switch (Db.S(r["MembershipStatus"]))
                {
                    case "Active": active++; break;
                    case "Frozen": frozen++; break;
                    case "Expired": expired++; break;
                }
            }

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 3, BackColor = Ui.Bg };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 55));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 45));

            // summary cards
            var cards = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1, Margin = new Padding(0, 0, 0, 12) };
            for (int i = 0; i < 4; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            cards.Controls.Add(StatCard("Total Members", total, Ui.Blue), 0, 0);
            cards.Controls.Add(StatCard("Active", active, Ui.Green), 1, 0);
            cards.Controls.Add(StatCard("Frozen", frozen, Ui.Orange), 2, 0);
            cards.Controls.Add(StatCard("Expired", expired, Ui.Red), 3, 0);
            root.Controls.Add(cards, 0, 0);
            root.SetColumnSpan(cards, 2);

            // membership status chart
            var (chartCard, chartBody) = MakeCard("Membership Status");
            chartBody.Controls.Add(new DonutChart
            {
                Dock = DockStyle.Fill, Total = total,
                Slices = new[] { ("Active", active, Ui.Green), ("Frozen", frozen, Ui.Orange), ("Expired", expired, Ui.Red) },
            });
            root.Controls.Add(chartCard, 0, 1);

            // upcoming expirations (within 30 days)
            int window = Settings.GetInt("RenewalNoticeDays", 7);
            var (expCard, expBody) = MakeCard("Upcoming Expirations (next " + window + " days)");
            var expGrid = Ui.Grid();
            var upcoming = new DataTable();
            upcoming.Columns.Add("Member ID"); upcoming.Columns.Add("Name"); upcoming.Columns.Add("Plan");
            upcoming.Columns.Add("Expires"); upcoming.Columns.Add("Days Left", typeof(int));
            foreach (DataRow r in members.Rows)
            {
                if (Db.S(r["MembershipStatus"]) != "Active") continue;
                var exp = Db.ToDate(r["ExpirationDate"]);
                int left = (exp - DateTime.Today).Days;
                if (left < 0 || left > window) continue;
                upcoming.Rows.Add(r["MemberID"], r["FullName"], r["PlanName"], Ui.Date(exp), left);
            }
            var view = upcoming.DefaultView; view.Sort = "[Days Left] ASC";
            expGrid.DataSource = view;
            var viewAll = new LinkLabel { Text = "View all members", Dock = DockStyle.Bottom, Height = 22, TextAlign = ContentAlignment.MiddleRight };
            viewAll.LinkClicked += (s, e) => navigate("members");
            expBody.Controls.Add(expGrid);
            if (Session.Current.Can(Perm.ViewMembers)) expBody.Controls.Add(viewAll);
            root.Controls.Add(expCard, 1, 1);

            // recent activity
            var (actCard, actBody) = MakeCard("Recent Activity");
            var actGrid = Ui.Grid();
            Ui.Bind(actGrid, StaffService.RecentActivity(8));
            actBody.Controls.Add(actGrid);
            root.Controls.Add(actCard, 0, 2);
            root.SetColumnSpan(actCard, 2);

            Content.Controls.Add(root);
        }

        private static Control StatCard(string caption, int value, Color color)
        {
            var p = new Panel { Dock = DockStyle.Fill, BackColor = color, Margin = new Padding(0, 0, 12, 0), Padding = new Padding(16, 12, 8, 8) };
            var num = new Label { Text = value.ToString(), Font = new Font("Segoe UI", 28f, FontStyle.Bold), ForeColor = Color.White, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            var cap = new Label { Text = caption, Font = Ui.Bold(10.5f), ForeColor = Color.White, Dock = DockStyle.Top, Height = 24 };
            p.Controls.Add(num);
            p.Controls.Add(cap);
            return p;
        }
    }
}

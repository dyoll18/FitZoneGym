namespace FitZoneGym.Controls
{
    /// <summary>Common frame for every screen: title bar (with an action area) above a content panel.</summary>
    public abstract class ViewBase : UserControl
    {
        protected readonly Label TitleLabel;
        protected readonly FlowLayoutPanel Actions;
        protected readonly Panel Content;

        protected ViewBase(string title)
        {
            Dock = DockStyle.Fill;
            BackColor = Ui.Bg;
            Font = Ui.Base;

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Ui.Bg };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 56));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, BackColor = Color.White, Padding = new Padding(18, 8, 18, 8) };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            TitleLabel = new Label { Text = title, Font = Ui.Bold(15f), ForeColor = Ui.Navy, AutoSize = true, Anchor = AnchorStyles.Left };
            Actions = new FlowLayoutPanel { AutoSize = true, WrapContents = false, FlowDirection = FlowDirection.LeftToRight, Anchor = AnchorStyles.Right, BackColor = Color.Transparent };
            header.Controls.Add(TitleLabel, 0, 0);
            header.Controls.Add(Actions, 1, 0);

            Content = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16), BackColor = Ui.Bg };
            root.Controls.Add(header, 0, 0);
            root.Controls.Add(Content, 0, 1);
            Controls.Add(root);
        }

        /// <summary>Convenience: a white card panel with a heading, returned with a body area to fill.</summary>
        protected static (Panel card, Panel body) MakeCard(string heading)
        {
            var card = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(14), Margin = new Padding(0, 0, 12, 12) };
            var body = new Panel { Dock = DockStyle.Fill, BackColor = Color.White };
            var title = new Label { Text = heading, Dock = DockStyle.Top, Height = 30, Font = Ui.Bold(10.5f), ForeColor = Ui.Navy };
            card.Controls.Add(body);   // Fill first, then the edge-docked heading
            card.Controls.Add(title);
            return (card, body);
        }
    }
}

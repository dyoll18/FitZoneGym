using System.Data;
using FitZoneGym.Data;
using FitZoneGym.Services;

namespace FitZoneGym.Controls
{
    /// <summary>Screen 13 - Users and Staff Management (accounts, role permissions, activity log).</summary>
    public class StaffView : ViewBase
    {
        private readonly TabControl _tabs = new TabControl { Dock = DockStyle.Fill, Font = Ui.Base };
        private readonly DataGridView _staff = Ui.Grid(), _log = Ui.Grid();
        private readonly ComboBox _role = Ui.Combo(180, "Staff", "Cashier");
        private readonly CheckedListBox _perms = new CheckedListBox { Dock = DockStyle.Fill, CheckOnClick = true, BorderStyle = BorderStyle.None, Font = Ui.Base };

        public StaffView() : base("Users & Staff")
        {
            Actions.Controls.Add(Ui.Primary("+ Add Staff", (s, e) => AddEdit(0), 120));

            // --- accounts tab
            var t1 = new TabPage("Staff Accounts") { BackColor = Color.White, Padding = new Padding(10) };
            var edit = Ui.Primary("Edit / Reset Password", (s, e) => AddEdit(SelectedId), 180);
            var l1 = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Color.White };
            l1.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); l1.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            l1.Controls.Add(_staff, 0, 0); l1.Controls.Add(Ui.Row(edit), 0, 1);
            t1.Controls.Add(l1);
            _staff.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) AddEdit(SelectedId); };

            // --- permissions tab
            var t2 = new TabPage("Roles & Permissions") { BackColor = Color.White, Padding = new Padding(10) };
            foreach (var g in Perm.Grantable) _perms.Items.Add(g.Label);
            _role.SelectedIndexChanged += (s, e) => LoadPerms();
            var save = Ui.Primary("Save Permissions", (s, e) => SavePerms(), 160);
            var note = Ui.Label("Administrators always have every permission. Managing staff, settings, backup and restore are administrator-only.", 9f, false, Ui.Muted);
            var l2 = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Color.White };
            l2.RowStyles.Add(new RowStyle(SizeType.AutoSize)); l2.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); l2.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            l2.Controls.Add(Ui.Row(Ui.Field("Role", _role), note), 0, 0);
            l2.Controls.Add(_perms, 0, 1);
            l2.Controls.Add(Ui.Row(save), 0, 2);
            t2.Controls.Add(l2);

            // --- activity tab
            var t3 = new TabPage("Activity Logs") { BackColor = Color.White, Padding = new Padding(10) };
            t3.Controls.Add(_log);

            _tabs.TabPages.AddRange(new[] { t1, t2, t3 });
            _tabs.SelectedIndexChanged += (s, e) => { if (_tabs.SelectedIndex == 2) LoadLog(); };
            Content.Controls.Add(_tabs);
            LoadStaff();
            LoadPerms();
        }

        private int SelectedId => _staff.CurrentRow == null ? 0 : Db.I(_staff.CurrentRow.Cells["UserID"].Value);

        private void LoadStaff()
        {
            Ui.Run(() =>
            {
                Ui.Bind(_staff, StaffService.List(), new[] { "UserID" });
                _staff.Columns["FullName"].HeaderText = "Name";
            });
        }

        private void LoadLog() => Ui.Run(() => Ui.Bind(_log, StaffService.ActivityLog()));

        private void LoadPerms()
        {
            var granted = StaffService.GetPermissions((string)_role.SelectedItem);
            for (int i = 0; i < Perm.Grantable.Length; i++) _perms.SetItemChecked(i, granted.Contains(Perm.Grantable[i].Key));
        }

        private void SavePerms()
        {
            var chosen = new List<string>();
            for (int i = 0; i < Perm.Grantable.Length; i++) if (_perms.GetItemChecked(i)) chosen.Add(Perm.Grantable[i].Key);
            if (Ui.Run(() => StaffService.SavePermissions((string)_role.SelectedItem, chosen)))
                Ui.Info("Permissions saved. Users must sign in again for changes to apply to their session.");
        }

        private void AddEdit(int userId)
        {
            using var f = new StaffEditForm(userId == 0 ? null : _staff.CurrentRow);
            if (f.ShowDialog(FindForm()) == DialogResult.OK) LoadStaff();
        }
    }

    public class StaffEditForm : Form
    {
        private readonly int _userId;
        private readonly TextBox _user = Ui.Input(), _name = Ui.Input(), _pass = Ui.Input();
        private readonly ComboBox _role = Ui.Combo(220, StaffService.Roles);
        private readonly CheckBox _active = new CheckBox { Text = "Account is active", Checked = true, AutoSize = true };

        public StaffEditForm(DataGridViewRow row)
        {
            _userId = row == null ? 0 : Db.I(row.Cells["UserID"].Value);
            Text = _userId == 0 ? "Add Staff" : "Edit Staff";
            ClientSize = new Size(460, 300);
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent; BackColor = Color.White; Font = Ui.Base;
            _pass.UseSystemPasswordChar = true;

            var form = new FormPanel(140) { Left = 20, Top = 16, Width = 420 };
            form.AddRow("Username *", _user);
            form.AddRow("Full name *", _name);
            form.AddRow("Role *", _role);
            form.AddRow(_userId == 0 ? "Password *" : "New password", _pass);
            form.AddRow("", _active);
            Controls.Add(form);
            if (_userId != 0)
            {
                _user.Text = Db.S(row.Cells["Username"].Value); _user.ReadOnly = true;
                _name.Text = Db.S(row.Cells["FullName"].Value);
                _role.SelectedItem = Db.S(row.Cells["Role"].Value);
                _active.Checked = Db.S(row.Cells["Status"].Value) == "Active";
                var hint = Ui.Label("Leave the password blank to keep the current one.", 9f, false, Ui.Muted); hint.Left = 160; hint.Top = 218;
                Controls.Add(hint);
            }
            else
            {
                var hint = Ui.Label("Min. 8 characters, with letters and numbers.", 9f, false, Ui.Muted); hint.Left = 160; hint.Top = 218;
                Controls.Add(hint);
            }

            var save = Ui.Primary("Save", (s, e) => Save(), 110); save.Left = 220; save.Top = 250;
            var cancel = Ui.Secondary("Cancel", (s, e) => { DialogResult = DialogResult.Cancel; Close(); }, 110); cancel.Left = 340; cancel.Top = 250;
            Controls.Add(save); Controls.Add(cancel);
            AcceptButton = save; CancelButton = cancel;
        }

        private void Save()
        {
            string role = Convert.ToString(_role.SelectedItem);
            bool ok = Ui.Run(() =>
            {
                if (_userId == 0) StaffService.Add(_user.Text, _name.Text, role, _pass.Text, _active.Checked);
                else StaffService.Update(_userId, _name.Text, role, _active.Checked, _pass.Text);
            });
            if (ok) { DialogResult = DialogResult.OK; Close(); }
        }
    }
}

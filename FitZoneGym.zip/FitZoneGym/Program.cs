using FitZoneGym.Data;
using FitZoneGym.Forms;

namespace FitZoneGym
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            try
            {
                Schema.EnsureCreated();
            }
            catch (Exception ex)
            {
                MessageBox.Show("The database could not be opened or created.\n\n" + ex.Message,
                    "FITZONE GYM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Login -> main window -> (logout returns to login, close exits).
            while (true)
            {
                using (var login = new LoginForm())
                {
                    if (login.ShowDialog() != DialogResult.OK) break;
                }
                using (var main = new MainForm())
                {
                    var result = main.ShowDialog();
                    if (result != DialogResult.Retry) break; // Retry == user logged out
                }
            }
        }
    }
}
